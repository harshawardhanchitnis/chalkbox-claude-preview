# Deployment

Nothing here has been executed yet — this is the runbook for the integration
phase.

## 1. Database

Supabase dashboard → **SQL Editor**. Run each file in
`supabase/migrations/` **in numerical order**, 001 first.

| File | What it does |
|---|---|
| `001_extensions.sql` | vector, pg_trgm, pgcrypto |
| `002_profiles_settings.sql` | profiles, settings, new-user trigger |
| `003_curriculum.sql` | sources, chunks, outcomes, `match_curriculum()` |
| `004_lesson_plans.sql` | plans, versions, generation audit, quota function |
| `005_teach_reflections.sql` | teach sessions, reflections, action items |
| `006_sharing_community.sql` | shares, publications, `get_shared_plan()` |
| `007_analytics_notifications.sql` | events, notifications, `teacher_analytics()` |
| `008_rls_policies.sql` | **the security boundary — do not skip** |
| `009_grants.sql` | explicit grants; why the client can read anything |

**Before 001**: Database → Extensions → enable `vector`.

**After 008**: every table in the Table Editor must show a shield icon. If any
does not, stop.

**Rollback**: these migrations only create objects. To start over on a project
with no real data, run `drop schema public cascade; create schema public;`
then re-run from 001. Do not do this once real teacher data exists.

## 2. Edge Function

```bash
supabase functions deploy lesson-ai --project-ref <ref>
```

Secrets (Edge Functions → Secrets). Only the first is private:

```
GEMINI_API_KEY=
GEMINI_MODEL=gemini-3.7-flash
GEMINI_EMBEDDING_MODEL=gemini-embedding-001
GEMINI_EMBEDDING_DIMENSIONS=768
AI_DAILY_LIMIT_TEACHER=25
AI_DAILY_LIMIT_DEMO=5
```

`SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` are injected automatically.

## 3. Curriculum

Run the ingestion script locally with the service key in your shell (never
committed). It embeds each passage once and writes vectors to `curriculum_chunks`.

## 4. Frontend

Cloudflare Pages, connected to `main`:

```
Build command:  pnpm build
Output:         dist
Root:           /
Node:           22
```

Environment variables (both public):

```
VITE_SUPABASE_URL=
VITE_SUPABASE_PUBLISHABLE_KEY=
VITE_APP_ENV=production
VITE_DEMO_ENABLED=true
```

`public/_redirects` handles SPA routing. `public/_headers` carries CSP and
security headers.

## 5. After the URL exists

- Supabase → Authentication → URL Configuration → Site URL + redirect URLs
- Cloudflare → Turnstile → new Managed widget for the hostname
- Site key → `VITE_TURNSTILE_SITE_KEY` in Pages
- Secret key → Supabase → Authentication → Bot and Abuse Protection

Turnstile matters here specifically because anonymous sign-ins are enabled for
Demo Mode, and anonymous auth plus a free AI quota is otherwise abusable.

## 6. Admin

Register through the deployed app, confirm the email, find the user UUID in
Authentication → Users, then promote via SQL:

```sql
update profiles set role = 'admin' where id = '<uuid>';
```

There are no hard-coded admin credentials anywhere in the application.
