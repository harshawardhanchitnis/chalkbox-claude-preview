# ChalkBox — build status

Generated at the end of the first implementation session.

## Done and verified

| Area | State | Evidence |
|---|---|---|
| Workspace, pnpm, TypeScript strict | done | `pnpm install` clean, `tsc -p packages/contracts` clean |
| Shared contracts package | done | Zod schemas for plan, brief, API union, permissions |
| **Constraint solver** | done, tested | 10 tests across 60 duration/class combinations |
| **Readiness checks** | done, tested | 8 tests including Devanagari script detection |
| SQL migrations 001–009 | written | extensions, identity, curriculum + hybrid RRF retrieval, plans, teaching, sharing, analytics, RLS, grants |
| Edge Function `lesson-ai` | written | auth, quota, retrieval, generation, one repair pass, audit |

## Not yet built

Frontend application (routes, design system, wizard, editor, Teach Mode, PDF,
library, offline sync, community, admin, analytics), demo fixtures, E2E tests,
CI, Cloudflare deployment.

## Action required from you

1. **Change one Supabase secret.** `GEMINI_EMBEDDING_MODEL` is currently
   `gemini-embedding-2`. That is the multimodal model; it returns a single
   aggregated embedding for multiple inputs, which breaks per-chunk retrieval.
   Set it to `gemini-embedding-001`. The Edge Function already falls back
   defensively, but the secret should be corrected.

2. **Run the migrations.** Supabase dashboard → SQL Editor → paste each file in
   `supabase/migrations/` in numerical order, 001 first. Do not skip 008 or 009;
   008 is the security boundary and 009 is why the client can read anything.

3. **Verify RLS is on.** After running 008, Table Editor should show a shield
   on every table. If any table lacks it, stop and tell me.

## Security notes

- No secret is present anywhere in this repository.
- `GEMINI_API_KEY` is read only inside the Edge Function runtime.
- `generation_runs` is revoked from `authenticated`, so the browser cannot
  forge records to reset its own daily quota.
- `plan_shares` is never publicly selectable; public reads go through the
  `get_shared_plan()` SECURITY DEFINER function, so tokens cannot be enumerated.
- Teaching outcomes are aggregate counts only, with a CHECK constraint that
  they never exceed attendance. No per-student rows exist anywhere in the schema.
