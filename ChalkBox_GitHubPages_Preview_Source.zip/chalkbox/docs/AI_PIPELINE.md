# The AI pipeline

## Request path

```
brief → constraints → retrieval → generation → readiness → (repair) → plan
```

Every stage is in `supabase/functions/_shared/pipeline.ts`, written as a flat
sequence of named steps so it can be read top to bottom.

### 1. Constraints (deterministic, no model)

`buildConstraintPlan(duration, grades)` produces the timetable. Multigrade
shape:

```
[ shared anchor ] [ focus class A ] [ focus class B ] … [ shared wrap ]
```

The anchor is one activity every class does together — same context, different
depth of question. It settles the room before the rotation and is why a
multigrade lesson feels like one lesson rather than three colliding.

`findAttentionConflicts()` then asserts no non-shared window demands direct
instruction of two classes. The solver already guarantees this; the assertion
makes a regression loud instead of silent.

### 2. Retrieval

Hybrid, via the `match_curriculum` SQL function:

- **Dense**: pgvector cosine over 768-dim embeddings
- **Sparse**: Postgres full-text — catches exact chapter names and numerals
- **Fusion**: Reciprocal Rank Fusion, k=60

RRF rather than a cross-encoder reranker, for the same reason embeddings are
API-based: a reranker is another ~2GB model to host and buys very little over a
corpus of a few thousand passages.

Embedding happens **once, offline, at ingest**. At query time only a single
short string is embedded, so the Edge runtime never holds a model.

If retrieval returns nothing and a chapter filter was set, the query widens to
the whole pack rather than handing the model nothing.

### 3. Generation

Gemini with `responseJsonSchema`. The schema in `_shared/json-schema.ts` is flat
and inlined because Gemini rejects `$defs`/`$ref` indirection and
`additionalProperties`.

The model produces **content only**. Identity, ownership, status and readiness
are assigned by our code, so the model can never declare a plan ready.

### 4. Readiness

Eight deterministic checks in `packages/contracts/src/readiness.ts`:

| Check | Catches |
|---|---|
| `placeholder_text` | "TBD", bracketed placeholders |
| `duration_mismatch` / `overlapping_steps` | a timeline that does not fill the period |
| `attention_conflict` | two classes needing the teacher at once |
| `material_unavailable` | projector, printer, lab apparatus |
| `too_few_objectives` / `objective_unassessed` | goals nothing checks |
| `multigrade_missing` / `track_missing` | a class in the room with no track |
| `wrong_script` | English written under a Hindi label (Devanagari ratio < 50%) |
| `fabricated_citation` | a citation to a passage never supplied |

Score = `100 − 20×errors − 5×warnings`. It counts kept guarantees. It
explicitly does not judge teaching quality, and the interface says so.

### 5. Repair

**One** attempt, not a loop. The original request plus the rejected answer plus
the named problems are replayed. A model that cannot fix a materials violation
on the second try will not fix it on the fifth, and the teacher is waiting.

The repair is kept only if it has fewer blocking errors than the original.

## Quota and cost

Counted server-side from `generation_runs`, which authenticated clients cannot
write. Demo (anonymous) users get `AI_DAILY_LIMIT_DEMO`; registered teachers get
`AI_DAILY_LIMIT_TEACHER`. Quota exhaustion returns an honest, actionable message.

## Error handling

`_shared/errors.ts` maps every failure to a teacher-facing message that never
leaks provider details, keys or stack traces. A failed generation is never
replaced with a canned lesson presented as live output.
