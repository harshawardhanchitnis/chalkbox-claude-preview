# Test plan

## Actually run (see INTEGRATION_STATUS.md for output)

| Suite | Count | Covers |
|---|---|---|
| `constraints.test.ts` | 10 | solver across 60 duration/class combinations |
| `readiness.test.ts` | 8 | each validator, including Devanagari detection |
| `plan-time.test.ts` | 9 | timeline reflow, rebalance, move, add, remove |
| `sync.test.ts` | 4 | offline conflict detection |
| `readiness-integration.test.ts` | 6 | fixtures pass the same checks as live plans |

The fixture suite caught a real bug during this build: single-class fixtures
generated one objective where the schema requires two. Fixed in the generator.

## Written, needs a browser runner

`tests/e2e/demo-journey.spec.ts` — landing → demo → multigrade plan → reload
persistence → offline open → privacy page.
`tests/e2e/accessibility.spec.ts` — heading structure, accessible names.

Both run against the production build with **no backend**, so CI needs no
secrets. Run with `pnpm e2e`.

## Needs the hosted project

- RLS: teacher A cannot read teacher B's plans
- Anonymous demo user cannot exceed `AI_DAILY_LIMIT_DEMO`
- `generation_runs` insert rejected for `authenticated`
- Share token resolves via `get_shared_plan()`; revoked token returns nothing
- Real Gemini generation against the live corpus

## Manual checklist

320px viewport · keyboard-only through the full journey · screen-reader
landmarks · Hindi shaping in print · slow 3G · installed PWA · offline/reconnect.
