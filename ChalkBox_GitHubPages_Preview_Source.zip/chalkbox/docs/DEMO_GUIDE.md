# Demo guide

Two minutes. No account, no setup, works offline.

## The point

One candle, one glass, three classes. Grade 6 sees that air contains oxygen.
Grade 7 sees that respiration consumes it. Grade 8 sees that combustion needs
oxygen plus ignition temperature. One demonstration, three depths — which is
exactly what a one-teacher middle school needs and exactly what a general
chatbot will not produce.

## Run

1. **Landing → "Try it now"**. No sign-up. Fixtures load into IndexedDB.

2. **Dashboard.** The Demo Mode banner is visible; every metric is labelled
   *Demo data*. Point out the metrics are derived from the stored records, not
   hard-coded — delete the fixtures and they read zero.

3. **Open "Air, Burning and Breathing — one candle, three classes".**

4. **The lesson rail** (right on desktop, below on mobile). Time runs down,
   one column per class. Read across any row: only one column is ever solid.
   That is the single-teacher guarantee, drawn. Amber = whole room together.

5. **Tap between Class 6 / 7 / 8.** Each has its own track and its own
   independent work for the windows where the teacher is elsewhere.

6. **The checks panel.** Score, grounding badge, passage count. Open it — the
   last line says plainly that these checks cannot judge teaching quality.

7. **Change a step's duration.** The timeline reflows and the progress bar
   turns red. Tap **Fit to 40 min**. Checks re-run live.

8. **Teach.** Full-screen, timer, per-class switching, blackboard prompt,
   arrow keys. Finish → aggregate outcomes only, never a student's name.

9. **Print.** Browser print dialog → Save as PDF. Devanagari renders because
   the fonts are already loaded. One class per page.

10. **Offline.** Turn off Wi-Fi. Reload. Everything still opens.

## Worth saying out loud

- Hindi output is real Devanagari, not Roman transliteration, and a
  script-ratio validator rejects English written under a Hindi label.
- Ungrounded plans are labelled ungrounded rather than passed off as sourced.
- The AI never declares a plan ready — our code does, after eight checks.
