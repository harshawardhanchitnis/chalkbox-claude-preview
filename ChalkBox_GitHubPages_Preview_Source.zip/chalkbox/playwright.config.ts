import { defineConfig, devices } from "@playwright/test";

/**
 * E2E configuration.
 *
 * Runs against the production build with no backend configured, which is
 * exactly the Demo Mode path a judge takes. Everything these specs cover works
 * without Supabase, so CI needs no secrets.
 */
export default defineConfig({
  testDir: "./tests/e2e",
  fullyParallel: true,
  retries: process.env.CI ? 1 : 0,
  reporter: process.env.CI ? "github" : "list",
  use: { baseURL: "http://localhost:4173", trace: "on-first-retry" },
  projects: [
    { name: "desktop", use: { ...devices["Desktop Chrome"] } },
    { name: "mobile", use: { ...devices["Pixel 7"] } },
  ],
  webServer: {
    command: "pnpm preview --port 4173",
    port: 4173,
    reuseExistingServer: !process.env.CI,
  },
});
