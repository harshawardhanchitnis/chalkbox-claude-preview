import js from "@eslint/js";
import globals from "globals";

export default [
  { ignores: ["dist", "node_modules", "supabase/functions/**"] },
  {
    files: ["**/*.{ts,tsx}"],
    languageOptions: {
      ecmaVersion: 2022,
      globals: { ...globals.browser, ...globals.node },
    },
    rules: { ...js.configs.recommended.rules, "no-undef": "off", "no-unused-vars": "off" },
  },
];
