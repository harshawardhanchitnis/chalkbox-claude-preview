import { z } from "zod";

/**
 * The lesson plan contract.
 *
 * This file is the centre of ChalkBox. The Edge Function asks Gemini for
 * exactly this shape, the validators check this shape, Postgres stores it as
 * JSONB, and the editor renders it. Because contracts live in a shared
 * workspace package, the browser and the Deno edge runtime cannot drift apart.
 *
 * Keeping a plan as a typed object rather than prose is what makes the rest of
 * the product possible: you cannot verify that a lesson fits in forty minutes,
 * or that it only uses chalk and bottle caps, if the lesson is a paragraph.
 */

export const SCHEMA_VERSION = 1;

export const gradeLevelSchema = z
  .number()
  .int()
  .min(1)
  .max(10)
  .describe("Indian school class, 1 to 10.");

export const outputLanguageSchema = z.enum(["en", "hi", "en-hi"]);
export const subjectSchema = z.enum([
  "science",
  "mathematics",
  "social-science",
  "english",
  "hindi",
  "evs",
  "custom",
]);
export const curriculumBoardSchema = z.enum(["cbse-ncert", "state-board", "custom"]);
export const connectivitySchema = z.enum(["online", "intermittent", "offline-classroom"]);
export const planStatusSchema = z.enum(["draft", "ready", "taught", "archived"]);
export const planVisibilitySchema = z.enum(["private", "unlisted", "community"]);
export const groundingLevelSchema = z.enum(["grounded", "partial", "ungrounded"]);

export const learnerNeedSchema = z.enum([
  "mixed-ability",
  "language-support",
  "remedial-support",
  "advanced-learners",
  "large-class",
  "multigrade",
]);

export const accessibilityNeedSchema = z.enum([
  "visual-support",
  "hearing-support",
  "mobility-support",
  "reading-support",
  "attention-support",
]);

/* ------------------------------------------------------------------ brief */

export const planBriefSchema = z.object({
  freeText: z.string().max(2000).optional(),
  board: curriculumBoardSchema.default("cbse-ncert"),
  stateBoard: z.string().max(80).optional(),
  grades: z.array(gradeLevelSchema).min(1).max(4),
  subject: subjectSchema,
  customSubject: z.string().max(60).optional(),
  topic: z.string().min(2).max(160),
  chapter: z.string().max(160).optional(),
  lessonDate: z.string().optional(),
  durationMinutes: z.number().int().min(20).max(90),
  outputLanguage: outputLanguageSchema,
  classSize: z.number().int().min(1).max(100),
  connectivity: connectivitySchema.default("intermittent"),
  availableResources: z.array(z.string().max(80)).max(40),
  priorKnowledge: z.string().max(600).optional(),
  desiredGoals: z.array(z.string().max(300)).max(8).default([]),
  learnerNeeds: z.array(learnerNeedSchema).default([]),
  accessibilityNeeds: z.array(accessibilityNeedSchema).default([]),
  additionalInstructions: z.string().max(800).optional(),
});

export type PlanBrief = z.infer<typeof planBriefSchema>;

/* ------------------------------------------------------------- plan parts */

export const learningObjectiveSchema = z.object({
  id: z.string(),
  statement: z.string().min(4).max(400),
  successCriteria: z.array(z.string().max(300)).min(1).max(5),
  cognitiveLevel: z.enum(["remember", "understand", "apply", "analyse", "evaluate", "create"]),
});

export const materialItemSchema = z.object({
  id: z.string(),
  name: z.string().max(120),
  quantity: z.string().max(60).optional(),
  source: z.enum(["school", "household", "optional"]),
  alternative: z.string().max(200).optional(),
});

export const lessonStepKindSchema = z.enum([
  "hook",
  "diagnostic",
  "explanation",
  "modelling",
  "guided-practice",
  "activity",
  "independent-practice",
  "assessment",
  "closure",
  "transition",
]);

/**
 * Where the single teacher physically is during a step.
 *
 * In a multigrade room the scarce resource is not time, it is the teacher.
 * Every step declares which grades hold the teacher's attention so the
 * scheduler can guarantee no two grades need direct instruction at once.
 */
export const attentionSchema = z.enum(["direct", "circulating", "independent"]);

export const lessonStepSchema = z.object({
  id: z.string(),
  order: z.number().int().min(0),
  kind: lessonStepKindSchema,
  title: z.string().max(140),
  startMinute: z.number().int().min(0).max(240),
  durationMinutes: z.number().int().min(1).max(90),
  gradeFocus: z.array(gradeLevelSchema).default([]),
  attention: attentionSchema.default("direct"),
  teacherActions: z.array(z.string().max(600)).min(1).max(8),
  studentActions: z.array(z.string().max(600)).min(1).max(8),
  materialIds: z.array(z.string()).default([]),
  objectiveIds: z.array(z.string()).default([]),
  checkForUnderstanding: z.string().max(500).optional(),
  boardPrompt: z.string().max(900).optional(),
  supportAdaptation: z.string().max(500).optional(),
  extensionAdaptation: z.string().max(500).optional(),
});

export const multigradeTrackSchema = z.object({
  grade: gradeLevelSchema,
  objectiveIds: z.array(z.string()).default([]),
  independentTasks: z.array(z.string().max(500)).min(1).max(6),
  directInstructionWindows: z
    .array(z.object({ startMinute: z.number().int(), durationMinutes: z.number().int() }))
    .default([]),
  assessmentPrompt: z.string().max(400).optional(),
});

export const differentiationPlanSchema = z.object({
  support: z.array(z.string().max(400)).default([]),
  core: z.array(z.string().max(400)).default([]),
  extension: z.array(z.string().max(400)).default([]),
  multigrade: z
    .object({
      anchorActivity: z.string().max(800),
      sharedInstruction: z.array(z.string().max(400)).default([]),
      tracks: z.array(multigradeTrackSchema).default([]),
      peerSupport: z.array(z.string().max(400)).default([]),
      transitionCues: z.array(z.string().max(300)).default([]),
    })
    .optional(),
  accessibility: z.array(z.string().max(400)).default([]),
  languageScaffolds: z.array(z.string().max(400)).default([]),
});

export const assessmentQuestionSchema = z.object({
  id: z.string(),
  type: z.enum(["multiple-choice", "short-answer", "oral", "observation", "exit-ticket"]),
  prompt: z.string().max(600),
  options: z.array(z.string().max(300)).max(6).optional(),
  correctAnswer: z.string().max(600),
  explanation: z.string().max(700),
  difficulty: z.enum(["support", "core", "challenge"]),
  objectiveIds: z.array(z.string()).default([]),
  gradeFocus: z.array(gradeLevelSchema).default([]),
});

export const rubricCriterionSchema = z.object({
  id: z.string(),
  criterion: z.string().max(240),
  emerging: z.string().max(300),
  developing: z.string().max(300),
  secure: z.string().max(300),
});

export const assessmentPlanSchema = z.object({
  diagnosticQuestions: z.array(assessmentQuestionSchema).max(5).default([]),
  formativeChecks: z.array(z.string().max(400)).default([]),
  exitTicket: z.array(assessmentQuestionSchema).max(5).default([]),
  questionBank: z.array(assessmentQuestionSchema).max(15).default([]),
  rubric: z.array(rubricCriterionSchema).max(5).default([]),
});

export const boardFrameSchema = z.object({
  id: z.string(),
  order: z.number().int().min(0),
  title: z.string().max(160),
  content: z.array(z.string().max(400)).min(1).max(12),
  revealAtStepId: z.string().optional(),
});

export const sourceCitationSchema = z.object({
  id: z.string(),
  sourceId: z.string(),
  chunkId: z.string(),
  label: z.string().max(220),
  locator: z.string().max(120).optional(),
  excerpt: z.string().max(300),
});

export const lessonPlanContentSchema = z.object({
  overview: z.string().min(20).max(1200),
  curriculumAlignment: z.array(z.string().max(300)).default([]),
  objectives: z.array(learningObjectiveSchema).min(2).max(6),
  prerequisites: z.array(z.string().max(300)).default([]),
  vocabulary: z
    .array(z.object({ term: z.string().max(120), meaning: z.string().max(400) }))
    .max(12)
    .default([]),
  misconceptions: z
    .array(z.object({ misconception: z.string().max(400), response: z.string().max(500) }))
    .max(8)
    .default([]),
  materials: z.array(materialItemSchema).max(20).default([]),
  preparation: z.array(z.string().max(400)).max(8).default([]),
  timeline: z.array(lessonStepSchema).min(3).max(16),
  differentiation: differentiationPlanSchema,
  assessment: assessmentPlanSchema,
  boardPlan: z.array(boardFrameSchema).max(8).default([]),
  homeworkOrExtension: z.array(z.string().max(400)).max(5).default([]),
  safetyNotes: z.array(z.string().max(400)).default([]),
  inclusionNotes: z.array(z.string().max(400)).default([]),
  reflectionPrompts: z.array(z.string().max(300)).max(5).default([]),
  citations: z.array(sourceCitationSchema).max(12).default([]),
});

export type LessonPlanContent = z.infer<typeof lessonPlanContentSchema>;
export type LessonStep = z.infer<typeof lessonStepSchema>;
export type LearningObjective = z.infer<typeof learningObjectiveSchema>;
export type AssessmentQuestion = z.infer<typeof assessmentQuestionSchema>;
export type DifferentiationPlan = z.infer<typeof differentiationPlanSchema>;
export type SourceCitation = z.infer<typeof sourceCitationSchema>;
export type MaterialItem = z.infer<typeof materialItemSchema>;
export type BoardFrame = z.infer<typeof boardFrameSchema>;
export type Attention = z.infer<typeof attentionSchema>;
export type GradeLevel = z.infer<typeof gradeLevelSchema>;
export type OutputLanguage = z.infer<typeof outputLanguageSchema>;
export type Subject = z.infer<typeof subjectSchema>;
export type LearnerNeed = z.infer<typeof learnerNeedSchema>;

/* -------------------------------------------------------------- readiness */

export const readinessIssueSchema = z.object({
  code: z.string(),
  severity: z.enum(["info", "warning", "error"]),
  section: z.string(),
  message: z.string(),
  suggestedAction: z.string(),
});

export const planReadinessSchema = z.object({
  score: z.number().min(0).max(100),
  issues: z.array(readinessIssueSchema),
  checkedAt: z.string(),
});

export type ReadinessIssue = z.infer<typeof readinessIssueSchema>;
export type PlanReadiness = z.infer<typeof planReadinessSchema>;

/* ------------------------------------------------------------------ plan */

export const lessonPlanSchema = z.object({
  id: z.string(),
  ownerId: z.string().nullable(),
  originPlanId: z.string().nullable().optional(),
  currentVersionId: z.string().nullable().optional(),
  title: z.string().max(220),
  status: planStatusSchema,
  visibility: planVisibilitySchema,
  brief: planBriefSchema,
  content: lessonPlanContentSchema,
  groundingLevel: groundingLevelSchema,
  readiness: planReadinessSchema,
  tags: z.array(z.string().max(40)).default([]),
  isFavourite: z.boolean().default(false),
  isPinnedOffline: z.boolean().default(false),
  schemaVersion: z.number().int().default(SCHEMA_VERSION),
  versionNumber: z.number().int().default(1),
  generationRunId: z.string().nullable().optional(),
  lastTaughtAt: z.string().nullable().optional(),
  archivedAt: z.string().nullable().optional(),
  createdAt: z.string(),
  updatedAt: z.string(),
});

export type LessonPlan = z.infer<typeof lessonPlanSchema>;

/**
 * The schema Gemini is asked to fill.
 *
 * Deliberately narrower than the stored plan: the model produces content only.
 * Identity, ownership, status and readiness are assigned by our own code, so
 * the model can never claim a plan is ready or attribute it to a user.
 */
export const generatedPlanSchema = z.object({
  title: z.string().max(220),
  content: lessonPlanContentSchema,
});

export type GeneratedPlan = z.infer<typeof generatedPlanSchema>;
