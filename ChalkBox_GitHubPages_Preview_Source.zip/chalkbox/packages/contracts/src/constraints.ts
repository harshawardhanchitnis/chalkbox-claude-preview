import type { GradeLevel } from "./lesson-plan.schema.ts";

/**
 * The constraint solver.
 *
 * This is the step that separates ChalkBox from a chatbot with a good prompt.
 *
 * Before any text is generated we compute a *skeleton*: how the minutes divide,
 * which grade holds the teacher's attention in each window, and what the other
 * grades do while they wait. Gemini is then asked to fill that skeleton in, not
 * to invent it.
 *
 * Doing it this way means the hard guarantee -- one teacher cannot instruct two
 * groups at once -- is enforced by arithmetic rather than by hoping the model
 * remembered. It also means a plan can be regenerated in a different language
 * without the schedule shifting underneath the teacher.
 *
 * Pure functions, no I/O, no model. Fully unit-testable.
 */

// Attention is defined once, in lesson-plan.schema.ts, and re-used here.
import type { Attention } from "./lesson-plan.schema.ts";
export type { Attention };

export interface ConstraintWindow {
  startMinute: number;
  durationMinutes: number;
  label: string;
  /** grade -> where the teacher is during this window */
  attention: Record<number, Attention>;
  /** true when the whole room works as one group */
  shared: boolean;
  note: string;
}

export interface ConstraintPlan {
  durationMinutes: number;
  grades: GradeLevel[];
  mode: "single" | "multi";
  anchorMinutes: number;
  windows: ConstraintWindow[];
  warnings: string[];
}

const SHARED_ANCHOR = "Shared anchor activity";
const SHARED_WRAP = "Shared check and wrap up";

/**
 * Proportions of a lesson given to each phase in single-grade mode.
 *
 * Tuned so a 40-minute period -- the most common in Indian government schools
 * -- lands on whole numbers. Teacher feedback should move these, not intuition.
 */
const SINGLE_SHAPE: Array<{ label: string; fraction: number; attention: Attention }> = [
  { label: "Hook and recall", fraction: 0.125, attention: "direct" },
  { label: "Teach the new idea", fraction: 0.3, attention: "direct" },
  { label: "Guided activity", fraction: 0.25, attention: "direct" },
  { label: "Independent practice", fraction: 0.2, attention: "circulating" },
  { label: "Check and wrap up", fraction: 0.125, attention: "direct" },
];

/** Distribute minutes across a shape without losing any to rounding. */
function splitMinutes(total: number, fractions: number[]): number[] {
  const out = fractions.map((f) => Math.max(1, Math.round(total * f)));
  const drift = total - out.reduce((a, b) => a + b, 0);
  if (drift !== 0) {
    // Push rounding drift into the longest block so short blocks stay clean.
    let longest = 0;
    for (let i = 1; i < out.length; i += 1) if (out[i] > out[longest]) longest = i;
    out[longest] = Math.max(1, out[longest] + drift);
  }
  return out;
}

function buildSingleGrade(duration: number, grade: GradeLevel): ConstraintWindow[] {
  const minutes = splitMinutes(
    duration,
    SINGLE_SHAPE.map((s) => s.fraction),
  );
  const windows: ConstraintWindow[] = [];
  let cursor = 0;
  SINGLE_SHAPE.forEach((phase, i) => {
    windows.push({
      startMinute: cursor,
      durationMinutes: minutes[i],
      label: phase.label,
      attention: { [grade]: phase.attention },
      shared: false,
      note: "",
    });
    cursor += minutes[i];
  });
  return windows;
}

/**
 * Build a rotation in which exactly one grade is taught at a time.
 *
 *   [ anchor ] [ focus g1 ] [ focus g2 ] ... [ shared wrap ]
 *
 * The anchor is one activity every grade does together -- same context,
 * different depth of question. It buys the teacher a settled room before the
 * rotation begins, and it is the reason a multigrade lesson feels like one
 * lesson rather than three lessons colliding in the same room.
 */
function buildMultiGrade(
  duration: number,
  grades: GradeLevel[],
): { windows: ConstraintWindow[]; anchorMinutes: number; warnings: string[] } {
  const warnings: string[] = [];
  const n = grades.length;

  let anchor = Math.max(4, Math.round(duration * 0.2));
  const wrap = Math.max(3, Math.round(duration * 0.1));
  let rotation = duration - anchor - wrap;

  const MIN_FOCUS = 5;
  if (rotation < n * MIN_FOCUS) {
    // Not enough time to give each grade a real turn. Shrink the anchor first,
    // then warn honestly rather than emitting two-minute teaching slots.
    const needed = n * MIN_FOCUS;
    const borrow = Math.min(anchor - 4, needed - rotation);
    anchor -= borrow;
    rotation += borrow;
    if (rotation < needed) {
      warnings.push(
        `${duration} minutes is tight for ${n} grades. Each grade gets under ${MIN_FOCUS} minutes of direct teaching. Consider a longer period, or splitting this across two days.`,
      );
    }
  }

  const perFocus = Math.max(3, Math.floor(rotation / n));
  const leftover = rotation - perFocus * n;

  const windows: ConstraintWindow[] = [];
  let cursor = 0;

  const allDirect: Record<number, Attention> = {};
  grades.forEach((g) => {
    allDirect[g] = "direct";
  });

  windows.push({
    startMinute: cursor,
    durationMinutes: anchor,
    label: SHARED_ANCHOR,
    attention: { ...allDirect },
    shared: true,
    note: "One activity, one context, every grade together. Differentiate by the depth of question asked, not by giving different work.",
  });
  cursor += anchor;

  grades.forEach((grade, i) => {
    const minutes = perFocus + (i === 0 ? leftover : 0);
    const attention: Record<number, Attention> = {};
    grades.forEach((g) => {
      attention[g] = g === grade ? "direct" : "independent";
    });
    const others = grades.filter((g) => g !== grade);
    windows.push({
      startMinute: cursor,
      durationMinutes: minutes,
      label: `Focus teaching - Class ${grade}`,
      attention,
      shared: false,
      note: `Class ${grade} has the teacher. Class ${others.join(" and ")} must be doing work that needs no new explanation and no new materials.`,
    });
    cursor += minutes;
  });

  windows.push({
    startMinute: cursor,
    durationMinutes: duration - cursor,
    label: SHARED_WRAP,
    attention: { ...allDirect },
    shared: true,
    note: "One closing question per grade, asked aloud to the whole room.",
  });

  return { windows, anchorMinutes: anchor, warnings };
}

export function buildConstraintPlan(
  durationMinutes: number,
  rawGrades: GradeLevel[],
): ConstraintPlan {
  const grades = [...new Set(rawGrades)].sort((a, b) => a - b) as GradeLevel[];
  if (grades.length === 0) throw new Error("At least one class is required.");
  if (durationMinutes < 20) throw new Error("Lessons shorter than 20 minutes are not supported.");

  if (grades.length === 1) {
    return {
      durationMinutes,
      grades,
      mode: "single",
      anchorMinutes: 0,
      windows: buildSingleGrade(durationMinutes, grades[0]),
      warnings: [],
    };
  }

  const { windows, anchorMinutes, warnings } = buildMultiGrade(durationMinutes, grades);
  return { durationMinutes, grades, mode: "multi", anchorMinutes, windows, warnings };
}

/**
 * Safety net: no non-shared window may demand direct instruction of two grades.
 *
 * The solver already guarantees this. The check exists so a regression is loud
 * rather than silent, and so the same rule can be re-run against a plan Gemini
 * returned.
 */
export function findAttentionConflicts(plan: ConstraintPlan): string[] {
  const problems: string[] = [];
  for (const w of plan.windows) {
    if (w.shared) continue;
    const direct = Object.entries(w.attention)
      .filter(([, a]) => a === "direct")
      .map(([g]) => Number(g));
    if (direct.length > 1) {
      problems.push(
        `Minutes ${w.startMinute}-${w.startMinute + w.durationMinutes}: classes ${direct.join(", ")} all need the teacher at once.`,
      );
    }
  }
  return problems;
}

/** Total minutes must equal the requested lesson length, exactly. */
export function totalMinutes(plan: ConstraintPlan): number {
  return plan.windows.reduce((sum, w) => sum + w.durationMinutes, 0);
}

/** Render the skeleton as instructions the model must follow verbatim. */
export function constraintPromptBlock(plan: ConstraintPlan): string {
  const lines: string[] = [
    `Lesson length: ${plan.durationMinutes} minutes.`,
    `Classes in the room: ${plan.grades.join(", ")}.`,
    "",
    "TIMETABLE YOU MUST FOLLOW EXACTLY. Do not change, merge, reorder or add time windows.",
  ];
  for (const w of plan.windows) {
    lines.push(
      `  ${w.startMinute}-${w.startMinute + w.durationMinutes} min | ${w.label} (${w.durationMinutes} min)`,
    );
    for (const grade of plan.grades) {
      lines.push(`      Class ${grade}: teacher is ${w.attention[grade]}`);
    }
    if (w.note) lines.push(`      note: ${w.note}`);
  }
  return lines.join("\n");
}
