export type UserRole = "teacher" | "admin";

export type Permission =
  | "plan:create"
  | "plan:read-own"
  | "plan:update-own"
  | "plan:delete-own"
  | "plan:share-own"
  | "community:submit"
  | "community:clone"
  | "curriculum:manage"
  | "publication:moderate"
  | "analytics:read-own"
  | "analytics:read-system";

const TEACHER: Permission[] = [
  "plan:create", "plan:read-own", "plan:update-own", "plan:delete-own",
  "plan:share-own", "community:submit", "community:clone", "analytics:read-own",
];

export const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  teacher: TEACHER,
  admin: [...TEACHER, "curriculum:manage", "publication:moderate", "analytics:read-system"],
};

export function can(role: UserRole | null | undefined, permission: Permission): boolean {
  if (!role) return false;
  return ROLE_PERMISSIONS[role].includes(permission);
}
