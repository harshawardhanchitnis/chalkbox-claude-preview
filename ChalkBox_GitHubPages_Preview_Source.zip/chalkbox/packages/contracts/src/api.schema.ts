import { z } from "zod";
import { generatedPlanSchema, planBriefSchema, planReadinessSchema, groundingLevelSchema, lessonPlanContentSchema } from "./lesson-plan.schema.ts";

/** The action union accepted by the single `lesson-ai` Edge Function. */
export const lessonAIActionSchema = z.enum([
  "parse-brief",
  "generate-plan",
  "regenerate-section",
  "generate-assessment",
  "admin-health",
]);
export type LessonAIAction = z.infer<typeof lessonAIActionSchema>;

export const parseBriefRequestSchema = z.object({
  action: z.literal("parse-brief"),
  schemaVersion: z.number().int(),
  freeText: z.string().min(10).max(2000),
  idempotencyKey: z.string().max(80),
});

export const generatePlanRequestSchema = z.object({
  action: z.literal("generate-plan"),
  schemaVersion: z.number().int(),
  brief: planBriefSchema,
  idempotencyKey: z.string().max(80),
});

export const regenerateSectionRequestSchema = z.object({
  action: z.literal("regenerate-section"),
  schemaVersion: z.number().int(),
  brief: planBriefSchema,
  section: z.enum([
    "overview", "objectives", "timeline", "differentiation",
    "assessment", "boardPlan", "materials", "homeworkOrExtension",
  ]),
  currentContent: lessonPlanContentSchema,
  teacherInstruction: z.string().max(500).optional(),
  idempotencyKey: z.string().max(80),
});

export const lessonAIRequestSchema = z.discriminatedUnion("action", [
  parseBriefRequestSchema,
  generatePlanRequestSchema,
  regenerateSectionRequestSchema,
  z.object({ action: z.literal("generate-assessment"), schemaVersion: z.number().int(), brief: planBriefSchema, currentContent: lessonPlanContentSchema, idempotencyKey: z.string().max(80) }),
  z.object({ action: z.literal("admin-health"), schemaVersion: z.number().int() }),
]);
export type LessonAIRequest = z.infer<typeof lessonAIRequestSchema>;

export const aiErrorCodeSchema = z.enum([
  "unauthenticated", "forbidden", "rate_limited", "quota_exceeded",
  "invalid_request", "invalid_model_output", "repair_failed",
  "no_curriculum_match", "upstream_unavailable", "timeout", "internal",
]);
export type AIErrorCode = z.infer<typeof aiErrorCodeSchema>;

export const generatePlanResponseSchema = z.object({
  ok: z.literal(true),
  plan: generatedPlanSchema,
  readiness: planReadinessSchema,
  groundingLevel: groundingLevelSchema,
  constraint: z.unknown(),
  meta: z.object({
    generationRunId: z.string(),
    model: z.string(),
    promptVersion: z.string(),
    latencyMs: z.number(),
    repairUsed: z.boolean(),
    passagesUsed: z.number(),
    remainingQuota: z.number(),
  }),
});

export const aiErrorResponseSchema = z.object({
  ok: z.literal(false),
  code: aiErrorCodeSchema,
  message: z.string(),
  retryable: z.boolean(),
  remainingQuota: z.number().optional(),
});

export type AIErrorResponse = z.infer<typeof aiErrorResponseSchema>;
export type GeneratePlanResponse = z.infer<typeof generatePlanResponseSchema>;
