import { describe, expect, it } from "vitest";
import {
  buildConstraintPlan,
  constraintPromptBlock,
  findAttentionConflicts,
  totalMinutes,
} from "../constraints";
import type { GradeLevel } from "../lesson-plan.schema";

const DURATIONS = [20, 25, 30, 35, 40, 45, 50, 60, 75, 90];
const GRADE_SETS: GradeLevel[][] = [[6], [3], [6, 7], [6, 7, 8], [3, 4, 5], [5, 6, 7, 8]];

describe("constraint solver", () => {
  it("always allocates exactly the requested minutes", () => {
    for (const duration of DURATIONS) {
      for (const grades of GRADE_SETS) {
        const plan = buildConstraintPlan(duration, grades);
        expect(totalMinutes(plan), `${duration}min ${grades}`).toBe(duration);
      }
    }
  });

  it("never schedules two classes for direct instruction at once", () => {
    for (const duration of DURATIONS) {
      for (const grades of GRADE_SETS) {
        const plan = buildConstraintPlan(duration, grades);
        expect(findAttentionConflicts(plan), `${duration}min ${grades}`).toEqual([]);
      }
    }
  });

  it("produces contiguous windows with no gaps or overlaps", () => {
    for (const duration of DURATIONS) {
      for (const grades of GRADE_SETS) {
        const plan = buildConstraintPlan(duration, grades);
        let cursor = 0;
        for (const w of plan.windows) {
          expect(w.startMinute).toBe(cursor);
          expect(w.durationMinutes).toBeGreaterThan(0);
          cursor += w.durationMinutes;
        }
      }
    }
  });

  it("gives every class its own focus window in multigrade mode", () => {
    const plan = buildConstraintPlan(40, [6, 7, 8]);
    for (const grade of [6, 7, 8]) {
      const focus = plan.windows.find(
        (w) => !w.shared && w.attention[grade] === "direct",
      );
      expect(focus, `class ${grade} has no focus window`).toBeDefined();
    }
  });

  it("opens and closes a multigrade lesson with the whole room together", () => {
    const plan = buildConstraintPlan(40, [6, 7, 8]);
    expect(plan.windows[0].shared).toBe(true);
    expect(plan.windows[plan.windows.length - 1].shared).toBe(true);
    expect(plan.anchorMinutes).toBeGreaterThan(0);
  });

  it("uses a single track and no anchor for one class", () => {
    const plan = buildConstraintPlan(40, [6]);
    expect(plan.mode).toBe("single");
    expect(plan.anchorMinutes).toBe(0);
    expect(plan.warnings).toEqual([]);
  });

  it("warns rather than inventing two-minute teaching slots when time is tight", () => {
    const plan = buildConstraintPlan(20, [5, 6, 7, 8]);
    expect(plan.warnings.length).toBeGreaterThan(0);
    expect(totalMinutes(plan)).toBe(20);
    expect(findAttentionConflicts(plan)).toEqual([]);
  });

  it("deduplicates and sorts the classes it is given", () => {
    const plan = buildConstraintPlan(40, [8, 6, 6, 7] as GradeLevel[]);
    expect(plan.grades).toEqual([6, 7, 8]);
  });

  it("rejects impossible input instead of guessing", () => {
    expect(() => buildConstraintPlan(40, [])).toThrow();
    expect(() => buildConstraintPlan(5, [6])).toThrow();
  });

  it("renders a prompt block naming every class in every window", () => {
    const block = constraintPromptBlock(buildConstraintPlan(40, [6, 7, 8]));
    expect(block).toContain("Class 6");
    expect(block).toContain("Class 7");
    expect(block).toContain("Class 8");
    expect(block).toContain("TIMETABLE YOU MUST FOLLOW EXACTLY");
  });
});
