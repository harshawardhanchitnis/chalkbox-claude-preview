import { describe, expect, it } from "vitest";
import { buildConstraintPlan } from "../constraints.ts";
import { evaluateReadiness, hasBlockingIssues } from "../readiness.ts";
import type { LessonPlanContent, PlanBrief } from "../lesson-plan.schema.ts";

const brief: PlanBrief = {
  board: "cbse-ncert", grades: [6, 7, 8], subject: "science",
  topic: "Air and burning", durationMinutes: 40, outputLanguage: "en",
  classSize: 42, connectivity: "intermittent",
  availableResources: ["Blackboard and chalk", "Candle", "Glass tumbler", "Matchbox"],
  desiredGoals: [], learnerNeeds: ["multigrade"], accessibilityNeeds: [],
};

const constraint = buildConstraintPlan(40, [6, 7, 8]);

function baseContent(): LessonPlanContent {
  const windows = constraint.windows;
  return {
    overview: "A shared candle-and-jar demonstration taught at three depths across classes 6, 7 and 8.",
    curriculumAlignment: [],
    objectives: [
      { id: "o1", statement: "Show that air contains oxygen", successCriteria: ["States that the flame goes out"], cognitiveLevel: "understand" },
      { id: "o2", statement: "Explain that burning needs oxygen", successCriteria: ["Names the three conditions"], cognitiveLevel: "apply" },
    ],
    prerequisites: [], vocabulary: [], misconceptions: [],
    materials: [
      { id: "m1", name: "Candle", source: "school" },
      { id: "m2", name: "Glass tumbler", source: "school" },
    ],
    preparation: [],
    timeline: windows.map((w, i) => ({
      id: `s${i + 1}`, order: i, kind: "activity" as const, title: w.label,
      startMinute: w.startMinute, durationMinutes: w.durationMinutes,
      gradeFocus: Object.entries(w.attention).filter(([, a]) => a === "direct").map(([g]) => Number(g)) as never,
      attention: w.shared ? ("direct" as const) : (Object.values(w.attention).includes("direct") ? ("direct" as const) : ("independent" as const)),
      teacherActions: ["Light the candle and cover it"], studentActions: ["Watch and count"],
      materialIds: ["m1", "m2"], objectiveIds: i === 0 ? ["o1"] : ["o2"],
    })),
    differentiation: {
      support: [], core: [], extension: [],
      multigrade: {
        anchorActivity: "Light a candle, cover it with a glass, and ask every class what they saw.",
        sharedInstruction: [], peerSupport: [], transitionCues: [],
        tracks: [6, 7, 8].map((g) => ({ grade: g as never, objectiveIds: ["o1"], independentTasks: ["Draw the jar"], directInstructionWindows: [] })),
      },
      accessibility: [], languageScaffolds: [],
    },
    assessment: {
      diagnosticQuestions: [], formativeChecks: [],
      exitTicket: [{ id: "q1", type: "exit-ticket", prompt: "Why did the flame stop?", correctAnswer: "Oxygen was used up", explanation: "Burning consumes oxygen", difficulty: "core", objectiveIds: ["o1", "o2"], gradeFocus: [] }],
      questionBank: [], rubric: [],
    },
    boardPlan: [], homeworkOrExtension: [], safetyNotes: [], inclusionNotes: [],
    reflectionPrompts: [], citations: [],
  };
}

describe("readiness checks", () => {
  it("passes a well-formed multigrade plan", () => {
    const r = evaluateReadiness({ content: baseContent(), constraint, brief, suppliedChunkIds: [] });
    expect(hasBlockingIssues(r), JSON.stringify(r.issues, null, 2)).toBe(false);
    expect(r.score).toBeGreaterThan(80);
  });

  it("catches a timeline that does not fill the lesson", () => {
    const content = baseContent();
    content.timeline[0].durationMinutes += 5;
    const r = evaluateReadiness({ content, constraint, brief, suppliedChunkIds: [] });
    expect(r.issues.some((i) => i.code === "duration_mismatch")).toBe(true);
  });

  it("rejects equipment a low-resource classroom will not have", () => {
    const content = baseContent();
    content.materials.push({ id: "m3", name: "Digital projector", source: "school" });
    const r = evaluateReadiness({ content, constraint, brief, suppliedChunkIds: [] });
    expect(r.issues.some((i) => i.code === "material_unavailable")).toBe(true);
    expect(hasBlockingIssues(r)).toBe(true);
  });

  it("catches a missing multigrade track", () => {
    const content = baseContent();
    content.differentiation.multigrade!.tracks = content.differentiation.multigrade!.tracks.filter((t) => t.grade !== 8);
    const r = evaluateReadiness({ content, constraint, brief, suppliedChunkIds: [] });
    expect(r.issues.some((i) => i.code === "track_missing")).toBe(true);
  });

  it("catches placeholder text", () => {
    const content = baseContent();
    content.overview = "TODO: write the overview here";
    const r = evaluateReadiness({ content, constraint, brief, suppliedChunkIds: [] });
    expect(r.issues.some((i) => i.code === "placeholder_text")).toBe(true);
  });

  it("catches a fabricated citation", () => {
    const content = baseContent();
    content.citations = [{ id: "c1", sourceId: "s", chunkId: "not-a-real-chunk", label: "Made up", excerpt: "x" }];
    const r = evaluateReadiness({ content, constraint, brief, suppliedChunkIds: ["real-chunk-1"] });
    expect(r.issues.some((i) => i.code === "fabricated_citation")).toBe(true);
  });

  it("catches English written under a Hindi label", () => {
    const content = baseContent();
    const r = evaluateReadiness({
      content, constraint,
      brief: { ...brief, outputLanguage: "hi" },
      suppliedChunkIds: [],
    });
    expect(r.issues.some((i) => i.code === "wrong_script")).toBe(true);
  });

  it("accepts genuine Devanagari for a Hindi plan", () => {
    const content = baseContent();
    content.overview = "इस पाठ में हम मोमबत्ती और गिलास की सहायता से हवा में ऑक्सीजन की उपस्थिति दिखाएँगे।";
    content.timeline.forEach((s) => { s.teacherActions = ["मोमबत्ती जलाइए और गिलास से ढकिए"]; });
    const r = evaluateReadiness({
      content, constraint,
      brief: { ...brief, outputLanguage: "hi" },
      suppliedChunkIds: [],
    });
    expect(r.issues.some((i) => i.code === "wrong_script")).toBe(false);
  });
});
