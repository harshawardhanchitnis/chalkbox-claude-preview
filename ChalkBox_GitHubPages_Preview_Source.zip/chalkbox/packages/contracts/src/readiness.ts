import {
  type ConstraintPlan,
  findAttentionConflicts,
} from "./constraints.ts";
import type { LessonPlanContent, PlanBrief, ReadinessIssue, PlanReadiness } from "./lesson-plan.schema.ts";

/**
 * Deterministic readiness checks.
 *
 * These run on every generated plan before a teacher sees it. Each check maps
 * to a promise the product makes. The score is not a judgement of teaching
 * quality -- it counts how many of our own guarantees the plan actually keeps,
 * and it is labelled that way in the interface.
 */

const PLACEHOLDER = /\b(lorem ipsum|tbd|todo|xxx+|placeholder|insert .{0,20}here|\[.{0,30}\])/i;

/**
 * Equipment that keeps appearing in generated plans and does not exist in the
 * rooms ChalkBox targets. Checked against declared material names, not prose,
 * because "draw a picture of a computer" is a perfectly good activity.
 */
const UNAVAILABLE = [
  "projector", "smartboard", "smart board", "computer", "laptop", "tablet",
  "printer", "printout", "print-out", "photocopy", "xerox", "internet",
  "youtube", "microscope", "laboratory", "lab equipment", "beaker",
  "test tube", "graph paper", "geometry box", "calculator",
];

function issue(
  code: string,
  severity: ReadinessIssue["severity"],
  section: string,
  message: string,
  suggestedAction: string,
): ReadinessIssue {
  return { code, severity, section, message, suggestedAction };
}

function normalise(text: string): string {
  return text.normalize("NFKC").toLowerCase().trim();
}

export function checkPlaceholders(content: LessonPlanContent): ReadinessIssue[] {
  const out: ReadinessIssue[] = [];
  const blob = JSON.stringify(content);
  if (PLACEHOLDER.test(blob)) {
    out.push(
      issue(
        "placeholder_text",
        "error",
        "overview",
        "The plan contains placeholder text instead of real content.",
        "Regenerate the affected section.",
      ),
    );
  }
  return out;
}

export function checkTiming(
  content: LessonPlanContent,
  constraint: ConstraintPlan,
): ReadinessIssue[] {
  const out: ReadinessIssue[] = [];
  const total = content.timeline.reduce((s, step) => s + step.durationMinutes, 0);

  if (total !== constraint.durationMinutes) {
    out.push(
      issue(
        "duration_mismatch",
        "error",
        "timeline",
        `The timeline totals ${total} minutes but the lesson is ${constraint.durationMinutes} minutes.`,
        `Adjust step durations so they add up to ${constraint.durationMinutes}.`,
      ),
    );
  }

  const sorted = [...content.timeline].sort((a, b) => a.startMinute - b.startMinute);
  let cursor = 0;
  for (const step of sorted) {
    if (step.startMinute < cursor) {
      out.push(
        issue(
          "overlapping_steps",
          "error",
          "timeline",
          `"${step.title}" starts at minute ${step.startMinute}, overlapping the previous step.`,
          "Move the step or shorten the one before it.",
        ),
      );
    }
    cursor = step.startMinute + step.durationMinutes;
  }

  const boundaries = new Set(constraint.windows.map((w) => w.startMinute));
  for (const step of sorted) {
    if (!boundaries.has(step.startMinute)) {
      out.push(
        issue(
          "step_off_grid",
          "warning",
          "timeline",
          `"${step.title}" does not begin at one of the planned window boundaries.`,
          "Align the step with the lesson timetable.",
        ),
      );
    }
  }
  return out;
}

/**
 * The single-teacher guarantee, re-checked against what the model produced.
 *
 * The solver guarantees the skeleton is teachable. This confirms the model did
 * not quietly promote an independent class to direct instruction.
 */
export function checkAttention(
  content: LessonPlanContent,
  constraint: ConstraintPlan,
): ReadinessIssue[] {
  const out: ReadinessIssue[] = [];
  if (constraint.mode === "single") return out;

  for (const conflict of findAttentionConflicts(constraint)) {
    out.push(
      issue("solver_conflict", "error", "timeline", conflict, "Report this; the timetable is invalid."),
    );
  }

  for (const window of constraint.windows) {
    if (window.shared) continue;
    const directGrades = new Set<number>();
    for (const step of content.timeline) {
      const overlaps =
        step.startMinute < window.startMinute + window.durationMinutes &&
        step.startMinute + step.durationMinutes > window.startMinute;
      if (overlaps && step.attention === "direct") {
        step.gradeFocus.forEach((g) => directGrades.add(g));
      }
    }
    if (directGrades.size > 1) {
      out.push(
        issue(
          "attention_conflict",
          "error",
          "timeline",
          `Between minutes ${window.startMinute} and ${window.startMinute + window.durationMinutes}, classes ${[...directGrades].sort().join(", ")} all need the teacher directly.`,
          "Only one class can receive direct instruction at a time.",
        ),
      );
    }
  }
  return out;
}

export function checkMaterials(
  content: LessonPlanContent,
  declared: string[],
): ReadinessIssue[] {
  const out: ReadinessIssue[] = [];
  const allowed = declared.map(normalise);

  for (const material of content.materials) {
    const name = normalise(material.name);
    const banned = UNAVAILABLE.find((bad) =>
      new RegExp(`\\b${bad.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`).test(name),
    );
    if (banned) {
      out.push(
        issue(
          "material_unavailable",
          "error",
          "materials",
          `The plan uses "${material.name}", which a low-resource classroom will not have.`,
          "Redesign that activity around materials the teacher listed.",
        ),
      );
      continue;
    }
    if (
      allowed.length > 0 &&
      material.source !== "household" &&
      !allowed.some((a) => a.includes(name) || name.includes(a))
    ) {
      out.push(
        issue(
          "material_undeclared",
          "warning",
          "materials",
          `"${material.name}" was not in the teacher's list of available materials.`,
          "Confirm it is available, or swap it for something on the list.",
        ),
      );
    }
  }
  return out;
}

export function checkObjectives(content: LessonPlanContent): ReadinessIssue[] {
  const out: ReadinessIssue[] = [];
  if (content.objectives.length < 2) {
    out.push(
      issue(
        "too_few_objectives",
        "error",
        "objectives",
        "A lesson needs at least two measurable objectives.",
        "Regenerate the objectives section.",
      ),
    );
  }

  const assessed = new Set<string>();
  const all = [
    ...content.assessment.diagnosticQuestions,
    ...content.assessment.exitTicket,
    ...content.assessment.questionBank,
  ];
  all.forEach((q) => q.objectiveIds.forEach((id) => assessed.add(id)));
  content.timeline.forEach((s) => s.objectiveIds.forEach((id) => assessed.add(id)));

  for (const objective of content.objectives) {
    if (!assessed.has(objective.id)) {
      out.push(
        issue(
          "objective_unassessed",
          "warning",
          "assessment",
          `Nothing in the lesson checks whether students met: "${objective.statement.slice(0, 80)}".`,
          "Add a question or a check for understanding tied to this objective.",
        ),
      );
    }
  }
  return out;
}

export function checkMultigrade(
  content: LessonPlanContent,
  constraint: ConstraintPlan,
): ReadinessIssue[] {
  const out: ReadinessIssue[] = [];
  if (constraint.mode !== "multi") return out;

  const mg = content.differentiation.multigrade;
  if (!mg) {
    out.push(
      issue(
        "multigrade_missing",
        "error",
        "differentiation",
        "This is a multigrade lesson but the plan has no multigrade section.",
        "Regenerate with the multigrade requirement.",
      ),
    );
    return out;
  }
  if (!mg.anchorActivity || mg.anchorActivity.length < 20) {
    out.push(
      issue(
        "anchor_missing",
        "error",
        "differentiation",
        "A multigrade lesson needs a shared anchor activity that holds the room together.",
        "Regenerate the multigrade section.",
      ),
    );
  }
  const covered = new Set(mg.tracks.map((t) => t.grade));
  for (const grade of constraint.grades) {
    if (!covered.has(grade)) {
      out.push(
        issue(
          "track_missing",
          "error",
          "differentiation",
          `Class ${grade} is in the room but has no track of its own.`,
          "Every class present needs its own tasks and assessment.",
        ),
      );
    }
  }
  return out;
}

/**
 * Catch the common failure of writing English under an Indic label.
 * Devanagari occupies a known Unicode block, so a script-ratio test is cheap.
 */
export function checkLanguage(
  content: LessonPlanContent,
  language: PlanBrief["outputLanguage"],
): ReadinessIssue[] {
  const out: ReadinessIssue[] = [];
  if (language !== "hi") return out;

  const sample = [
    content.overview,
    ...content.timeline.flatMap((s) => s.teacherActions),
  ].join(" ");
  const letters = [...sample].filter((c) => /\p{L}/u.test(c));
  if (letters.length === 0) return out;
  const devanagari = letters.filter((c) => {
    const cp = c.codePointAt(0) ?? 0;
    return cp >= 0x0900 && cp <= 0x097f;
  }).length;
  const ratio = devanagari / letters.length;
  if (ratio < 0.5) {
    out.push(
      issue(
        "wrong_script",
        "error",
        "overview",
        `The plan was requested in Hindi but only ${Math.round(ratio * 100)}% of it is in Devanagari.`,
        "Regenerate in Hindi.",
      ),
    );
  }
  return out;
}

export function checkCitations(
  content: LessonPlanContent,
  suppliedChunkIds: string[],
): ReadinessIssue[] {
  const out: ReadinessIssue[] = [];
  if (suppliedChunkIds.length === 0) return out;
  const known = new Set(suppliedChunkIds);
  for (const citation of content.citations) {
    if (!known.has(citation.chunkId)) {
      out.push(
        issue(
          "fabricated_citation",
          "error",
          "citations",
          "The plan cites a source that was not part of this request.",
          "Citations must reference retrieved material only.",
        ),
      );
    }
  }
  if (content.citations.length === 0) {
    out.push(
      issue(
        "no_citations",
        "info",
        "citations",
        "Curriculum material was available but the plan cites none of it.",
        "This plan is marked as ungrounded.",
      ),
    );
  }
  return out;
}

export function evaluateReadiness(args: {
  content: LessonPlanContent;
  constraint: ConstraintPlan;
  brief: PlanBrief;
  suppliedChunkIds: string[];
}): PlanReadiness {
  const { content, constraint, brief, suppliedChunkIds } = args;
  const issues: ReadinessIssue[] = [
    ...checkPlaceholders(content),
    ...checkTiming(content, constraint),
    ...checkAttention(content, constraint),
    ...checkMaterials(content, brief.availableResources),
    ...checkObjectives(content),
    ...checkMultigrade(content, constraint),
    ...checkLanguage(content, brief.outputLanguage),
    ...checkCitations(content, suppliedChunkIds),
  ];

  const errors = issues.filter((i) => i.severity === "error").length;
  const warnings = issues.filter((i) => i.severity === "warning").length;
  const score = Math.max(0, Math.min(100, 100 - errors * 20 - warnings * 5));

  return { score, issues, checkedAt: new Date().toISOString() };
}

export function hasBlockingIssues(readiness: PlanReadiness): boolean {
  return readiness.issues.some((i) => i.severity === "error");
}

export function blockingMessages(readiness: PlanReadiness): string[] {
  return readiness.issues
    .filter((i) => i.severity === "error")
    .map((i) => `${i.message} ${i.suggestedAction}`);
}
