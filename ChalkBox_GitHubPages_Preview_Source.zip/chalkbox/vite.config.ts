import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";
import path from "node:path";

export default defineConfig({
  base: "/chalkbox-claude-preview/",
  resolve: {
    alias: {
      "@chalkbox/contracts": path.resolve(__dirname, "packages/contracts/src"),
      "@": path.resolve(__dirname, "src"),
    },
  },
  build: {
    target: "es2022",
    rollupOptions: {
      output: {
        // Keep the initial bundle small for low-end Android. Charts and the
        // PDF renderer are only pulled in when a teacher opens those routes.
        manualChunks: {
          react: ["react", "react-dom", "react-router-dom"],
          data: ["dexie", "dexie-react-hooks", "@tanstack/react-query"],
          charts: ["recharts"],
        },
      },
    },
  },
  plugins: [
    react(),
    VitePWA({
      registerType: "prompt",
      includeAssets: ["favicon.svg", "fonts/*.woff2"],
      manifest: {
        name: "ChalkBox",
        short_name: "ChalkBox",
        description: "Your classroom. Your plan.",
        theme_color: "#1F6B5C",
        background_color: "#F7F8F2",
        display: "standalone",
        orientation: "portrait-primary",
        start_url: "/chalkbox-claude-preview/",
        icons: [
          { src: "icons/icon-192.png", sizes: "192x192", type: "image/png" },
          { src: "icons/icon-512.png", sizes: "512x512", type: "image/png" },
          { src: "icons/maskable-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
        ],
      },
      workbox: {
        globPatterns: ["**/*.{js,css,html,svg,woff2,png}"],
        maximumFileSizeToCacheInBytes: 4 * 1024 * 1024,
        navigateFallbackDenylist: [/^\/api/],
        runtimeCaching: [
          {
            // Fonts must survive offline or Devanagari falls back to a system
            // face and every plan reflows mid-lesson.
            urlPattern: /\.(?:woff2|woff)$/,
            handler: "CacheFirst",
            options: { cacheName: "fonts", expiration: { maxEntries: 12, maxAgeSeconds: 31536000 } },
          },
          {
            // Plans live in IndexedDB; this only smooths re-reads while online.
            urlPattern: ({ url }) => url.pathname.startsWith("/rest/v1/"),
            handler: "NetworkFirst",
            options: { cacheName: "supabase", networkTimeoutSeconds: 6 },
          },
        ],
      },
    }),
  ],
  server: { port: 5173 },
});
