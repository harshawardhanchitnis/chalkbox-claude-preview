/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        canvas: "rgb(var(--canvas) / <alpha-value>)",
        surface: "rgb(var(--surface) / <alpha-value>)",
        ink: "rgb(var(--ink) / <alpha-value>)",
        muted: "rgb(var(--muted) / <alpha-value>)",
        line: "rgb(var(--border) / <alpha-value>)",
        primary: {
          DEFAULT: "rgb(var(--primary) / <alpha-value>)",
          hover: "rgb(var(--primary-hover) / <alpha-value>)",
          soft: "rgb(var(--primary-soft) / <alpha-value>)",
          fg: "rgb(var(--primary-fg) / <alpha-value>)",
        },
        accent: "rgb(var(--accent) / <alpha-value>)",
        info: "rgb(var(--info) / <alpha-value>)",
        success: "rgb(var(--success) / <alpha-value>)",
        warning: "rgb(var(--warning) / <alpha-value>)",
        danger: "rgb(var(--error) / <alpha-value>)",
      },
      fontFamily: {
        display: ["Manrope", "system-ui", "sans-serif"],
        body: ["'Noto Sans'", "'Noto Sans Devanagari'", "system-ui", "sans-serif"],
        deva: ["'Noto Sans Devanagari'", "'Noto Sans'", "sans-serif"],
      },
      borderRadius: { field: "10px", card: "14px", panel: "18px" },
      boxShadow: {
        card: "0 1px 2px rgb(23 33 31 / 0.05), 0 2px 10px rgb(23 33 31 / 0.04)",
        lift: "0 4px 12px rgb(23 33 31 / 0.08), 0 12px 32px rgb(23 33 31 / 0.06)",
      },
      maxWidth: { app: "1440px", form: "960px", read: "760px", editor: "1360px" },
      transitionDuration: { DEFAULT: "180ms" },
    },
  },
  plugins: [],
};
