import { expect, test } from "@playwright/test";

test("landing page has one h1 and a skip link target", async ({ page }) => {
  await page.goto("/");
  await expect(page.locator("h1")).toHaveCount(1);
  await expect(page.locator("#main")).toBeVisible();
});

test("every form control on onboarding has an accessible name", async ({ page }) => {
  await page.goto("/demo");
  await page.waitForURL("**/app");
  await page.goto("/app/settings");
  const inputs = page.locator("input:not([type=checkbox]), select, textarea");
  const count = await inputs.count();
  for (let i = 0; i < count; i += 1) {
    const el = inputs.nth(i);
    const name =
      (await el.getAttribute("aria-label")) ??
      (await el.getAttribute("id")) ??
      (await el.getAttribute("placeholder"));
    expect(name, `control ${i} has no accessible name`).toBeTruthy();
  }
});
