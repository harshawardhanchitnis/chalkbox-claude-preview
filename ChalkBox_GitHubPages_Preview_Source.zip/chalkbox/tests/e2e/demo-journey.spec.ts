import { expect, test } from "@playwright/test";

/**
 * The judge's path, end to end, with no account and no backend.
 * If this breaks, the demo breaks.
 */
test("a visitor can enter the demo and open a multigrade plan", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { name: /Your classroom\. Your plan\./i })).toBeVisible();

  await page.getByRole("link", { name: /Try it now/i }).click();
  await page.waitForURL("**/app");

  await expect(page.getByText(/Demo Mode/i).first()).toBeVisible();
  await expect(page.getByText(/one candle, three classes/i).first()).toBeVisible();
});

test("the lesson rail shows one class at a time receiving the teacher", async ({ page }) => {
  await page.goto("/demo");
  await page.waitForURL("**/app");
  await page.getByText(/one candle, three classes/i).first().click();
  await page.waitForURL("**/plans/**");

  await expect(page.getByText(/The period, minute by minute/i)).toBeVisible();
  await expect(page.getByText(/All together/i).first()).toBeVisible();
});

test("plans survive a reload because they are stored on the device", async ({ page }) => {
  await page.goto("/demo");
  await page.waitForURL("**/app");
  await page.reload();
  await expect(page.getByText(/one candle, three classes/i).first()).toBeVisible();
});

test("a saved plan opens with the network disabled", async ({ page, context }) => {
  await page.goto("/demo");
  await page.waitForURL("**/app");
  await context.setOffline(true);
  await page.getByText(/one candle, three classes/i).first().click();
  await expect(page.getByText(/minute by minute/i)).toBeVisible();
  await context.setOffline(false);
});

test("the privacy page states the no-student-data rule", async ({ page }) => {
  await page.goto("/privacy");
  await expect(page.getByRole("heading", { name: /No student data/i })).toBeVisible();
});
