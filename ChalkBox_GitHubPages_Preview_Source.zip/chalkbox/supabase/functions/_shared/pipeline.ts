import { config } from "./config.ts";
import { AIError } from "./errors.ts";
import { embedQuery, generateJSON, type Turn } from "./gemini.ts";
import { generatedPlanSchema } from "./json-schema.ts";
import { buildPlanPrompt, buildRepairPrompt, SYSTEM_PROMPT, type RetrievedChunk } from "./prompts.ts";
import { serviceClient } from "./auth.ts";
import {
  buildConstraintPlan, constraintPromptBlock, findAttentionConflicts, totalMinutes,
} from "../../../packages/contracts/src/constraints.ts";
import {
  generatedPlanSchema as generatedPlanZod, type PlanBrief,
} from "../../../packages/contracts/src/lesson-plan.schema.ts";
import { blockingMessages, evaluateReadiness, hasBlockingIssues } from "../../../packages/contracts/src/readiness.ts";

/**
 * The planning pipeline.
 *
 *   brief -> constraints -> retrieval -> generation -> readiness -> repair?
 *
 * Written as a flat sequence of named steps rather than a clever abstraction,
 * so a reader can follow exactly what happens to a request.
 */

export interface PipelineResult {
  plan: { title: string; content: unknown };
  readiness: ReturnType<typeof evaluateReadiness>;
  constraint: ReturnType<typeof buildConstraintPlan>;
  groundingLevel: "grounded" | "partial" | "ungrounded";
  chunkIds: string[];
  repairUsed: boolean;
  latencyMs: number;
}

/** Built from structured choices, so the teacher never writes a search query. */
function retrievalQuery(brief: PlanBrief): string {
  return [
    brief.topic,
    brief.chapter ?? "",
    brief.customSubject || brief.subject,
    `class ${brief.grades.join(" and ")}`,
    ...brief.desiredGoals.slice(0, 2),
  ].filter(Boolean).join(" ");
}

async function retrieve(brief: PlanBrief): Promise<{
  chunks: RetrievedChunk[];
  outcomes: Array<{ grade: number; code: string; statement: string }>;
}> {
  const admin = serviceClient();
  let chunks: RetrievedChunk[] = [];

  try {
    const embedding = await embedQuery(retrievalQuery(brief));
    const { data, error } = await admin.rpc("match_curriculum", {
      query_embedding: embedding,
      query_text: retrievalQuery(brief),
      filter_grades: brief.grades,
      filter_subject: brief.subject,
      filter_chapter: brief.chapter ?? null,
      match_count: 10,
      candidate_count: 40,
    });
    if (error) console.error("retrieval_error", error.message);
    chunks = (data ?? []) as RetrievedChunk[];

    // Chapter filter too narrow: widen rather than hand the model nothing.
    if (chunks.length === 0 && brief.chapter) {
      const { data: wider } = await admin.rpc("match_curriculum", {
        query_embedding: embedding,
        query_text: retrievalQuery(brief),
        filter_grades: brief.grades,
        filter_subject: brief.subject,
        filter_chapter: null,
        match_count: 10,
        candidate_count: 40,
      });
      chunks = (wider ?? []) as RetrievedChunk[];
    }
  } catch (err) {
    // Retrieval failing is not fatal. We generate ungrounded and say so.
    console.error("embedding_failed", err instanceof Error ? err.message : "unknown");
  }

  const { data: outcomes } = await admin
    .from("learning_outcomes")
    .select("grade, code, statement")
    .in("grade", brief.grades)
    .eq("subject", brief.subject)
    .limit(40);

  return { chunks, outcomes: outcomes ?? [] };
}

function grounding(chunks: RetrievedChunk[], citationCount: number) {
  if (chunks.length === 0) return "ungrounded" as const;
  if (citationCount === 0) return "ungrounded" as const;
  return citationCount >= 2 ? ("grounded" as const) : ("partial" as const);
}

export async function generatePlan(brief: PlanBrief): Promise<PipelineResult> {
  const started = Date.now();

  // 1. Skeleton. Deterministic. No model involved.
  const constraint = buildConstraintPlan(brief.durationMinutes, brief.grades);
  if (totalMinutes(constraint) !== brief.durationMinutes) {
    throw new AIError("internal", "The lesson timetable could not be built.");
  }
  const conflicts = findAttentionConflicts(constraint);
  if (conflicts.length > 0) {
    console.error("solver_regression", conflicts);
    throw new AIError("internal", "The lesson timetable could not be built.");
  }

  // 2. Ground it.
  const { chunks, outcomes } = await retrieve(brief);

  // 3. Generate.
  const userPrompt = buildPlanPrompt({
    brief: {
      grades: brief.grades, subject: brief.subject, customSubject: brief.customSubject,
      topic: brief.topic, chapter: brief.chapter, durationMinutes: brief.durationMinutes,
      outputLanguage: brief.outputLanguage, classSize: brief.classSize,
      availableResources: brief.availableResources, priorKnowledge: brief.priorKnowledge,
      desiredGoals: brief.desiredGoals, learnerNeeds: brief.learnerNeeds,
      accessibilityNeeds: brief.accessibilityNeeds,
      additionalInstructions: brief.additionalInstructions, board: brief.board,
    },
    constraintBlock: constraintPromptBlock(constraint),
    chunks,
    outcomes,
  });

  const turns: Turn[] = [{ role: "user", text: userPrompt }];
  const raw = await generateJSON({
    system: SYSTEM_PROMPT, turns, responseSchema: generatedPlanSchema,
  });

  const chunkIds = chunks.map((c) => c.id);
  let parsed = generatedPlanZod.safeParse(raw);
  let readiness = parsed.success
    ? evaluateReadiness({ content: parsed.data.content, constraint, brief, suppliedChunkIds: chunkIds })
    : null;

  const problems: string[] = parsed.success
    ? (readiness && hasBlockingIssues(readiness) ? blockingMessages(readiness) : [])
    : parsed.error.errors.slice(0, 12).map((e) => `Field "${e.path.join(".")}": ${e.message}`);

  // 4. One repair attempt if anything failed.
  let repairUsed = false;
  if (problems.length > 0) {
    repairUsed = true;
    turns.push({ role: "model", text: JSON.stringify(raw).slice(0, 60_000) });
    turns.push({ role: "user", text: buildRepairPrompt(problems) });
    try {
      const raw2 = await generateJSON({
        system: SYSTEM_PROMPT, turns, responseSchema: generatedPlanSchema,
      });
      const parsed2 = generatedPlanZod.safeParse(raw2);
      if (parsed2.success) {
        const readiness2 = evaluateReadiness({
          content: parsed2.data.content, constraint, brief, suppliedChunkIds: chunkIds,
        });
        const before = readiness ? readiness.issues.filter((i) => i.severity === "error").length : 99;
        const after = readiness2.issues.filter((i) => i.severity === "error").length;
        if (after <= before) { parsed = parsed2; readiness = readiness2; }
      }
    } catch (err) {
      console.error("repair_failed", err instanceof Error ? err.message : "unknown");
    }
  }

  if (!parsed.success || !readiness) throw new AIError("repair_failed");

  // A plan with remaining blocking issues is still returned -- with the issues
  // named -- rather than replaced by something that looks fine but is not.
  return {
    plan: { title: parsed.data.title, content: parsed.data.content },
    readiness,
    constraint,
    groundingLevel: grounding(chunks, parsed.data.content.citations.length),
    chunkIds,
    repairUsed,
    latencyMs: Date.now() - started,
  };
}

export { config };
