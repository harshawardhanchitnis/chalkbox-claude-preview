import { json } from "./cors.ts";

export type AIErrorCode =
  | "unauthenticated" | "forbidden" | "rate_limited" | "quota_exceeded"
  | "invalid_request" | "invalid_model_output" | "repair_failed"
  | "no_curriculum_match" | "upstream_unavailable" | "timeout" | "internal";

const STATUS: Record<AIErrorCode, number> = {
  unauthenticated: 401, forbidden: 403, rate_limited: 429, quota_exceeded: 429,
  invalid_request: 400, invalid_model_output: 502, repair_failed: 502,
  no_curriculum_match: 200, upstream_unavailable: 503, timeout: 504, internal: 500,
};

const RETRYABLE = new Set<AIErrorCode>([
  "upstream_unavailable", "timeout", "internal", "invalid_model_output",
]);

/**
 * Messages are written for a teacher, not a developer, and never leak provider
 * details, keys or stack traces.
 */
const MESSAGES: Record<AIErrorCode, string> = {
  unauthenticated: "Please sign in, or open Demo Mode, and try again.",
  forbidden: "This account cannot perform that action.",
  rate_limited: "Too many requests in a short time. Wait a minute and try again.",
  quota_exceeded: "You have used today's free AI lessons. Your quota resets tomorrow.",
  invalid_request: "Some details of the lesson request were missing or invalid.",
  invalid_model_output: "The lesson came back in an unusable form. Please try again.",
  repair_failed: "The lesson could not be produced correctly. Try changing the topic or duration.",
  no_curriculum_match: "No curriculum material matched this topic.",
  upstream_unavailable: "The AI service is not responding right now. Please try again shortly.",
  timeout: "The lesson took too long to generate. Please try again.",
  internal: "Something went wrong on our side.",
};

export class AIError extends Error {
  constructor(readonly code: AIErrorCode, message?: string, readonly remainingQuota?: number) {
    super(message ?? MESSAGES[code]);
  }
  toResponse(): Response {
    return json(
      {
        ok: false,
        code: this.code,
        message: this.message,
        retryable: RETRYABLE.has(this.code),
        ...(this.remainingQuota !== undefined ? { remainingQuota: this.remainingQuota } : {}),
      },
      STATUS[this.code],
    );
  }
}
