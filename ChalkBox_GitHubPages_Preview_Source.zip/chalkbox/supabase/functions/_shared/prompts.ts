/**
 * Prompt construction.
 *
 * Three rules shape everything here:
 *
 *  1. The model fills a skeleton it did not choose. Timings come from the
 *     constraint solver and are stated as fixed.
 *  2. The model may only use the curriculum passages it is shown. If they do
 *     not cover something, it says so rather than inventing content.
 *  3. The model may only use materials the teacher declared. This appears in
 *     both the system and user message because it is the rule most often
 *     broken.
 *
 * Prompts are versioned and stored with every generation_run, so a bad plan can
 * always be traced back to the prompt that produced it.
 */

export interface RetrievedChunk {
  id: string;
  source_id: string;
  grade: number;
  chapter: string | null;
  heading: string | null;
  text: string;
  locator: string | null;
}

export const SYSTEM_PROMPT = `You are an experienced Indian government-school teacher who writes lesson plans for colleagues working in difficult conditions.

You are writing for a teacher who:
- may be the only teacher in the school
- often teaches several classes in one room, at one blackboard
- has no projector, no printer, no laboratory and no internet during class
- has exactly the materials listed in the request and nothing else

HARD RULES:

1. MATERIALS. Use only materials from AVAILABLE MATERIALS, plus ordinary household or natural objects a village child can bring (stones, leaves, seeds, bottle caps, string, old newspaper). Never require a projector, computer, printer, photocopy, printed worksheet per child, laboratory apparatus or calculator. If an activity needs something unavailable, redesign the activity.

2. TIMETABLE. The timetable given is fixed. Your timeline steps must start and end exactly on the given window boundaries. Do not add, remove, merge or reorder windows. The sum of all step durations must equal the lesson length exactly.

3. ONE TEACHER. When the timetable says a class is 'independent', that class's work in that window must need no adult explanation and no new materials, and must be startable from an instruction given earlier. Never write a step where two different classes both receive direct instruction at the same time.

4. GROUNDING. Base subject content on the CURRICULUM PASSAGES provided. Do not contradict them. If the passages do not cover part of what is asked, write what they do support and say so in inclusionNotes. Only cite a passage you actually used, using its exact chunkId. Never invent a citation, a page number or a textbook name.

5. LANGUAGE. Write the entire plan in the requested language, including activity instructions, questions and answers. For Hindi, write in Devanagari script, not Roman transliteration. Do not write in English and translate. Where a technical term is normally said in English in an Indian classroom, keep the English word rather than inventing an unfamiliar translation. For bilingual output, give the Hindi first and the English term in brackets after it.

6. IDS. Every objective, material, step, question and board frame needs a short unique id (o1, m1, s1, q1, b1). Reference those exact ids in objectiveIds and materialIds. Never reference an id that does not exist.

7. NO PLACEHOLDERS. Never write "TBD", "insert here", "example activity" or bracketed placeholders. Every field must contain real, usable content.

Write plainly. Short sentences. Concrete instructions a tired teacher can follow at 7am without rereading.`;

export function passagesBlock(chunks: RetrievedChunk[]): string {
  if (chunks.length === 0) {
    return [
      "CURRICULUM PASSAGES: none matched this topic.",
      "Write the plan from general pedagogy. Leave citations empty and add a line",
      "to inclusionNotes stating that this plan is not grounded in curriculum material.",
    ].join("\n");
  }
  const out = ["CURRICULUM PASSAGES (the only permitted source of subject content):", ""];
  for (const c of chunks) {
    const where = [
      c.chapter ? `Chapter: ${c.chapter}` : null,
      c.heading,
      c.locator,
      `Class ${c.grade}`,
    ].filter(Boolean).join(" | ");
    out.push(`[chunkId: ${c.id}] [sourceId: ${c.source_id}] ${where}`);
    out.push(c.text.trim());
    out.push("");
  }
  return out.join("\n");
}

export function outcomesBlock(
  outcomes: Array<{ grade: number; code: string; statement: string }>,
): string {
  if (outcomes.length === 0) {
    return "CURRICULUM LEARNING OUTCOMES: none supplied. Write your own measurable objectives.";
  }
  const byGrade = new Map<number, typeof outcomes>();
  for (const o of outcomes) {
    if (!byGrade.has(o.grade)) byGrade.set(o.grade, []);
    byGrade.get(o.grade)!.push(o);
  }
  const out = [
    "CURRICULUM LEARNING OUTCOMES (each class present must target at least one):",
    "",
  ];
  for (const grade of [...byGrade.keys()].sort()) {
    out.push(`Class ${grade}:`);
    for (const o of byGrade.get(grade)!) out.push(`  ${o.code}: ${o.statement}`);
    out.push("");
  }
  return out.join("\n");
}

const LANGUAGE_NAMES: Record<string, string> = {
  en: "English",
  hi: "Hindi (हिन्दी), in Devanagari script",
  "en-hi": "bilingual Hindi and English (Hindi first in Devanagari, English term in brackets)",
};

export function buildPlanPrompt(args: {
  brief: {
    grades: number[]; subject: string; customSubject?: string; topic: string;
    chapter?: string; durationMinutes: number; outputLanguage: string;
    classSize: number; availableResources: string[]; priorKnowledge?: string;
    desiredGoals: string[]; learnerNeeds: string[]; accessibilityNeeds: string[];
    additionalInstructions?: string; board: string;
  };
  constraintBlock: string;
  chunks: RetrievedChunk[];
  outcomes: Array<{ grade: number; code: string; statement: string }>;
}): string {
  const { brief, constraintBlock, chunks, outcomes } = args;
  const multi = brief.grades.length > 1;

  const header = [
    `Write a ${multi ? "MULTIGRADE" : "single-class"} lesson plan.`,
    "",
    `Curriculum: ${brief.board}`,
    `Subject: ${brief.customSubject || brief.subject}`,
    `Topic: ${brief.topic}`,
    brief.chapter ? `Chapter: ${brief.chapter}` : null,
    `Classes in the room: ${brief.grades.join(", ")}`,
    `Lesson length: ${brief.durationMinutes} minutes`,
    `Class size: about ${brief.classSize} students`,
    `Write everything in: ${LANGUAGE_NAMES[brief.outputLanguage] ?? brief.outputLanguage}`,
    brief.priorKnowledge ? `What students already know: ${brief.priorKnowledge}` : null,
    brief.desiredGoals.length ? `Teacher's goals: ${brief.desiredGoals.join("; ")}` : null,
    brief.learnerNeeds.length ? `Learner needs in this room: ${brief.learnerNeeds.join(", ")}` : null,
    brief.accessibilityNeeds.length ? `Accessibility needs: ${brief.accessibilityNeeds.join(", ")}` : null,
    brief.additionalInstructions ? `Teacher's own instruction: ${brief.additionalInstructions}` : null,
  ].filter(Boolean).join("\n");

  const materials = brief.availableResources.length
    ? "AVAILABLE MATERIALS (the complete list):\n" +
      brief.availableResources.map((r) => `  - ${r}`).join("\n")
    : "AVAILABLE MATERIALS: blackboard and chalk only. Build every activity around speech, movement and the blackboard.";

  const multigradeRules = multi
    ? [
        "MULTIGRADE REQUIREMENTS (this is the hardest and most important part):",
        "  - differentiation.multigrade.anchorActivity: ONE activity the whole room does together during the shared anchor window. Same context and same demonstration for every class; the difference is the depth of question you ask each class.",
        "  - differentiation.multigrade.tracks: one track per class, each with its own objectives, independent tasks and assessment prompt.",
        "  - During a class's 'independent' windows, its work must be silent or low-noise and must continue without the teacher.",
        "  - Include transition steps where the teacher tells one class what to start before turning to the next class.",
        "  - Set gradeFocus on every timeline step to the class or classes it applies to.",
        "  - Set attention on every step to match the timetable exactly.",
      ].join("\n")
    : [
        "SINGLE-CLASS REQUIREMENTS:",
        "  - Set gradeFocus on every step to the single class.",
        "  - differentiation.support must help students who are behind; differentiation.extension must stretch students who finish early.",
      ].join("\n");

  return [
    header, "", materials, "", constraintBlock, "", multigradeRules, "",
    outcomesBlock(outcomes), "", passagesBlock(chunks), "",
    "Return only the JSON object matching the required schema.",
  ].join("\n");
}

/**
 * One repair attempt, not a loop. If the model cannot fix a materials
 * violation on the second try it will not fix it on the fifth, and the teacher
 * is waiting.
 */
export function buildRepairPrompt(problems: string[]): string {
  return [
    "Your plan was rejected by the automatic checker for these reasons:",
    "",
    ...problems.map((p) => `  - ${p}`),
    "",
    "Fix every one of them. Keep everything else identical, especially all timings.",
    "Return the corrected JSON object only.",
  ].join("\n");
}

export const PARSE_BRIEF_SYSTEM = `You extract structured lesson parameters from a teacher's sentence.

Extract only what the teacher actually said or clearly implied. Do not invent a class, a duration or a language that was not indicated. Leave a field out rather than guessing.

Add a short note to confidenceNotes for anything you inferred rather than read, so the teacher can check it. The teacher reviews and corrects every field before anything is generated.`;
