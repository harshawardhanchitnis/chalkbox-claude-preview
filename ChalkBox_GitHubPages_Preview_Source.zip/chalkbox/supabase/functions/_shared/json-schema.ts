/**
 * Gemini's structured-output schema, generated from the Zod contract.
 *
 * Written by hand here rather than imported, because the Zod-to-JSON-Schema
 * conversion emits $defs/$ref indirection and `additionalProperties`, neither
 * of which Gemini accepts. Keeping it inline and flat is the reliable path.
 *
 * The shape MUST stay in step with packages/contracts/src/lesson-plan.schema.ts.
 * A drift shows up immediately as a validation failure on the first request,
 * not as silently wrong data.
 */
const str = (maxLength?: number) => ({ type: "string", ...(maxLength ? { maxLength } : {}) });
const arr = (items: unknown, maxItems?: number) => ({
  type: "array", items, ...(maxItems ? { maxItems } : {}),
});
const int = (minimum?: number, maximum?: number) => ({
  type: "integer",
  ...(minimum !== undefined ? { minimum } : {}),
  ...(maximum !== undefined ? { maximum } : {}),
});

const objective = {
  type: "object",
  required: ["id", "statement", "successCriteria", "cognitiveLevel"],
  properties: {
    id: str(40),
    statement: str(400),
    successCriteria: arr(str(300), 5),
    cognitiveLevel: { type: "string", enum: ["remember","understand","apply","analyse","evaluate","create"] },
  },
};

const material = {
  type: "object",
  required: ["id", "name", "source"],
  properties: {
    id: str(40), name: str(120), quantity: str(60),
    source: { type: "string", enum: ["school", "household", "optional"] },
    alternative: str(200),
  },
};

const step = {
  type: "object",
  required: ["id","order","kind","title","startMinute","durationMinutes","teacherActions","studentActions","attention","gradeFocus"],
  properties: {
    id: str(40),
    order: int(0),
    kind: { type: "string", enum: ["hook","diagnostic","explanation","modelling","guided-practice","activity","independent-practice","assessment","closure","transition"] },
    title: str(140),
    startMinute: int(0, 240),
    durationMinutes: int(1, 90),
    gradeFocus: arr(int(1, 10), 4),
    attention: { type: "string", enum: ["direct", "circulating", "independent"] },
    teacherActions: arr(str(600), 8),
    studentActions: arr(str(600), 8),
    materialIds: arr(str(40), 10),
    objectiveIds: arr(str(40), 6),
    checkForUnderstanding: str(500),
    boardPrompt: str(900),
    supportAdaptation: str(500),
    extensionAdaptation: str(500),
  },
};

const question = {
  type: "object",
  required: ["id","type","prompt","correctAnswer","explanation","difficulty"],
  properties: {
    id: str(40),
    type: { type: "string", enum: ["multiple-choice","short-answer","oral","observation","exit-ticket"] },
    prompt: str(600),
    options: arr(str(300), 6),
    correctAnswer: str(600),
    explanation: str(700),
    difficulty: { type: "string", enum: ["support", "core", "challenge"] },
    objectiveIds: arr(str(40), 6),
    gradeFocus: arr(int(1, 10), 4),
  },
};

const multigradeTrack = {
  type: "object",
  required: ["grade", "independentTasks"],
  properties: {
    grade: int(1, 10),
    objectiveIds: arr(str(40), 6),
    independentTasks: arr(str(500), 6),
    directInstructionWindows: arr({
      type: "object",
      required: ["startMinute", "durationMinutes"],
      properties: { startMinute: int(0), durationMinutes: int(1) },
    }, 6),
    assessmentPrompt: str(400),
  },
};

export const lessonPlanContentSchema = {
  type: "object",
  required: ["overview","objectives","timeline","differentiation","assessment","materials"],
  properties: {
    overview: str(1200),
    curriculumAlignment: arr(str(300), 8),
    objectives: arr(objective, 6),
    prerequisites: arr(str(300), 6),
    vocabulary: arr({
      type: "object", required: ["term", "meaning"],
      properties: { term: str(120), meaning: str(400) },
    }, 12),
    misconceptions: arr({
      type: "object", required: ["misconception", "response"],
      properties: { misconception: str(400), response: str(500) },
    }, 8),
    materials: arr(material, 20),
    preparation: arr(str(400), 8),
    timeline: arr(step, 16),
    differentiation: {
      type: "object",
      required: ["support", "core", "extension", "accessibility", "languageScaffolds"],
      properties: {
        support: arr(str(400), 6),
        core: arr(str(400), 6),
        extension: arr(str(400), 6),
        multigrade: {
          type: "object",
          required: ["anchorActivity", "tracks"],
          properties: {
            anchorActivity: str(800),
            sharedInstruction: arr(str(400), 6),
            tracks: arr(multigradeTrack, 4),
            peerSupport: arr(str(400), 4),
            transitionCues: arr(str(300), 6),
          },
        },
        accessibility: arr(str(400), 6),
        languageScaffolds: arr(str(400), 6),
      },
    },
    assessment: {
      type: "object",
      required: ["diagnosticQuestions", "formativeChecks", "exitTicket", "questionBank", "rubric"],
      properties: {
        diagnosticQuestions: arr(question, 5),
        formativeChecks: arr(str(400), 6),
        exitTicket: arr(question, 5),
        questionBank: arr(question, 15),
        rubric: arr({
          type: "object",
          required: ["id", "criterion", "emerging", "developing", "secure"],
          properties: { id: str(40), criterion: str(240), emerging: str(300), developing: str(300), secure: str(300) },
        }, 5),
      },
    },
    boardPlan: arr({
      type: "object", required: ["id", "order", "title", "content"],
      properties: { id: str(40), order: int(0), title: str(160), content: arr(str(400), 12), revealAtStepId: str(40) },
    }, 8),
    homeworkOrExtension: arr(str(400), 5),
    safetyNotes: arr(str(400), 6),
    inclusionNotes: arr(str(400), 6),
    reflectionPrompts: arr(str(300), 5),
    citations: arr({
      type: "object", required: ["id", "sourceId", "chunkId", "label", "excerpt"],
      properties: { id: str(40), sourceId: str(60), chunkId: str(60), label: str(220), locator: str(120), excerpt: str(300) },
    }, 12),
  },
};

export const generatedPlanSchema = {
  type: "object",
  required: ["title", "content"],
  properties: { title: str(220), content: lessonPlanContentSchema },
};

export const parsedBriefSchema = {
  type: "object",
  required: ["grades", "subject", "topic", "durationMinutes", "outputLanguage"],
  properties: {
    grades: arr(int(1, 10), 4),
    subject: { type: "string", enum: ["science","mathematics","social-science","english","hindi","evs","custom"] },
    customSubject: str(60),
    topic: str(160),
    chapter: str(160),
    durationMinutes: int(20, 90),
    outputLanguage: { type: "string", enum: ["en", "hi", "en-hi"] },
    classSize: int(1, 100),
    availableResources: arr(str(80), 20),
    learnerNeeds: arr({ type: "string", enum: ["mixed-ability","language-support","remedial-support","advanced-learners","large-class","multigrade"] }, 6),
    desiredGoals: arr(str(300), 5),
    confidenceNotes: arr(str(200), 5),
  },
};
