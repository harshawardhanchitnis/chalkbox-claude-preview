import { createClient, type SupabaseClient } from "jsr:@supabase/supabase-js@2";
import { config } from "./config.ts";
import { AIError } from "./errors.ts";

export interface Caller {
  userId: string;
  isAnonymous: boolean;
  role: "teacher" | "admin";
  dailyLimit: number;
}

/** Service-role client. Used only inside this function, never exposed. */
export function serviceClient(): SupabaseClient {
  return createClient(config.supabaseUrl, config.serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export async function authenticate(req: Request): Promise<Caller> {
  const header = req.headers.get("Authorization") ?? "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) throw new AIError("unauthenticated");

  const admin = serviceClient();
  const { data, error } = await admin.auth.getUser(token);
  if (error || !data.user) throw new AIError("unauthenticated");

  const { data: profile } = await admin
    .from("profiles").select("role, is_anonymous").eq("id", data.user.id).single();

  const isAnonymous = profile?.is_anonymous ?? data.user.is_anonymous ?? false;
  return {
    userId: data.user.id,
    isAnonymous,
    role: (profile?.role as "teacher" | "admin") ?? "teacher",
    dailyLimit: isAnonymous ? config.dailyLimitDemo : config.dailyLimitTeacher,
  };
}

/**
 * Server-side daily quota.
 *
 * Counted from generation_runs, which authenticated clients cannot write, so
 * the limit cannot be reset by the browser.
 */
export async function assertQuota(caller: Caller): Promise<number> {
  const admin = serviceClient();
  const { data, error } = await admin.rpc("ai_requests_today", { p_user: caller.userId });
  if (error) throw new AIError("internal");
  const used = Number(data ?? 0);
  const remaining = caller.dailyLimit - used;
  if (remaining <= 0) throw new AIError("quota_exceeded", undefined, 0);
  return remaining;
}
