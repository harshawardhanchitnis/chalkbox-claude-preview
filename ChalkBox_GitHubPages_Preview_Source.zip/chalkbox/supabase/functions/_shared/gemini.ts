import { config } from "./config.ts";
import { AIError } from "./errors.ts";

const BASE = "https://generativelanguage.googleapis.com/v1beta/models";

async function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  let timer: number | undefined;
  try {
    return await Promise.race([
      p,
      new Promise<T>((_, reject) => {
        timer = setTimeout(() => reject(new AIError("timeout")), ms);
      }),
    ]);
  } finally {
    if (timer !== undefined) clearTimeout(timer);
  }
}

/** Embed one string. Query-time only; corpus embedding happens offline. */
export async function embedQuery(text: string): Promise<number[]> {
  if (!config.geminiApiKey) throw new AIError("internal", "AI is not configured.");
  const url = `${BASE}/${config.embeddingModel}:embedContent?key=${config.geminiApiKey}`;
  const res = await withTimeout(
    fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: `models/${config.embeddingModel}`,
        content: { parts: [{ text }] },
        taskType: "RETRIEVAL_QUERY",
        outputDimensionality: config.embeddingDimensions,
      }),
    }),
    20_000,
  );
  if (!res.ok) throw new AIError("upstream_unavailable");
  const body = await res.json();
  const values = body?.embedding?.values;
  if (!Array.isArray(values)) throw new AIError("upstream_unavailable");
  return values;
}

export interface Turn { role: "user" | "model"; text: string }

/**
 * Structured generation.
 *
 * responseJsonSchema is what makes a plan a reliable object rather than prose
 * we have to parse. `turns` carries the whole exchange so a repair attempt can
 * replay the original request plus the rejected answer.
 */
export async function generateJSON(args: {
  system: string;
  turns: Turn[];
  responseSchema: Record<string, unknown>;
  maxOutputTokens?: number;
}): Promise<unknown> {
  if (!config.geminiApiKey) throw new AIError("internal", "AI is not configured.");
  const url = `${BASE}/${config.model}:generateContent?key=${config.geminiApiKey}`;

  const res = await withTimeout(
    fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: args.system }] },
        contents: args.turns.map((t) => ({ role: t.role, parts: [{ text: t.text }] })),
        generationConfig: {
          responseMimeType: "application/json",
          responseJsonSchema: args.responseSchema,
          maxOutputTokens: args.maxOutputTokens ?? 32768,
          temperature: 0.7,
        },
      }),
    }),
    120_000,
  );

  if (res.status === 429) throw new AIError("rate_limited");
  if (res.status >= 500) throw new AIError("upstream_unavailable");
  if (!res.ok) {
    // Log status only. The response body can echo the request and we do not
    // want prompt content in logs.
    console.error("gemini_error_status", res.status);
    throw new AIError("upstream_unavailable");
  }

  const body = await res.json();
  const blocked = body?.promptFeedback?.blockReason;
  if (blocked) throw new AIError("invalid_model_output", "The request was blocked by a safety filter.");

  const parts = body?.candidates?.[0]?.content?.parts ?? [];
  const text = parts.map((p: { text?: string }) => p.text ?? "").join("");
  if (!text) throw new AIError("invalid_model_output");

  try {
    return JSON.parse(text);
  } catch {
    throw new AIError("invalid_model_output");
  }
}
