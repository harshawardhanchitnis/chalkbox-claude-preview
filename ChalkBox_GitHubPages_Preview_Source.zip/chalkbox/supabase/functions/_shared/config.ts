/**
 * Edge runtime configuration.
 *
 * Read from Supabase Edge Function secrets. GEMINI_API_KEY never leaves this
 * runtime -- it is not in the client bundle and not in the repository.
 */
export const config = {
  geminiApiKey: Deno.env.get("GEMINI_API_KEY") ?? "",
  model: Deno.env.get("GEMINI_MODEL") ?? "gemini-3.7-flash",
  // NOTE: gemini-embedding-2 is the multimodal model and returns ONE aggregated
  // embedding for multiple inputs, which breaks per-chunk retrieval. For
  // text-only RAG the correct model is gemini-embedding-001. If the secret is
  // still set to the multimodal model we fall back rather than silently
  // indexing garbage.
  embeddingModel: (() => {
    const configured = Deno.env.get("GEMINI_EMBEDDING_MODEL") ?? "gemini-embedding-001";
    return configured === "gemini-embedding-2" ? "gemini-embedding-001" : configured;
  })(),
  embeddingDimensions: Number(Deno.env.get("GEMINI_EMBEDDING_DIMENSIONS") ?? 768),
  dailyLimitTeacher: Number(Deno.env.get("AI_DAILY_LIMIT_TEACHER") ?? 25),
  dailyLimitDemo: Number(Deno.env.get("AI_DAILY_LIMIT_DEMO") ?? 5),
  supabaseUrl: Deno.env.get("SUPABASE_URL") ?? "",
  serviceRoleKey: Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
  promptVersion: "2026.08.21-1",
};

export const SCHEMA_VERSION = 1;
