/**
 * lesson-ai: the single AI gateway.
 *
 * Everything that touches Gemini goes through here. The API key lives in Edge
 * Function secrets and never reaches the browser; quota is counted from a
 * table clients cannot write; and no student-identifying data is accepted or
 * forwarded.
 */
import { corsHeaders, json } from "../_shared/cors.ts";
import { AIError } from "../_shared/errors.ts";
import { authenticate, assertQuota, serviceClient } from "../_shared/auth.ts";
import { config, SCHEMA_VERSION } from "../_shared/config.ts";
import { generatePlan } from "../_shared/pipeline.ts";
import { generateJSON } from "../_shared/gemini.ts";
import { parsedBriefSchema } from "../_shared/json-schema.ts";
import { PARSE_BRIEF_SYSTEM } from "../_shared/prompts.ts";
import { planBriefSchema } from "../../../packages/contracts/src/lesson-plan.schema.ts";

Deno.serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, code: "invalid_request" }, 405);

  const admin = serviceClient();
  let runId: string | null = null;
  let userId: string | null = null;

  try {
    const caller = await authenticate(req);
    userId = caller.userId;

    const body = await req.json().catch(() => null);
    if (!body || typeof body.action !== "string") throw new AIError("invalid_request");
    if (body.schemaVersion !== SCHEMA_VERSION) {
      throw new AIError("invalid_request", "Please refresh the app; it is out of date.");
    }

    if (body.action === "admin-health") {
      if (caller.role !== "admin") throw new AIError("forbidden");
      const { count } = await admin
        .from("curriculum_chunks").select("*", { count: "exact", head: true });
      return json({
        ok: true,
        model: config.model,
        embeddingModel: config.embeddingModel,
        embeddingDimensions: config.embeddingDimensions,
        promptVersion: config.promptVersion,
        indexedChunks: count ?? 0,
        keyConfigured: Boolean(config.geminiApiKey),
      });
    }

    const remaining = await assertQuota(caller);

    if (body.action === "parse-brief") {
      const text = String(body.freeText ?? "").slice(0, 2000);
      if (text.length < 10) throw new AIError("invalid_request", "Please describe the lesson in a sentence or two.");
      const parsed = await generateJSON({
        system: PARSE_BRIEF_SYSTEM,
        turns: [{ role: "user", text }],
        responseSchema: parsedBriefSchema,
        maxOutputTokens: 2048,
      });
      // Extraction is never generated from directly -- the teacher reviews it.
      return json({ ok: true, extracted: parsed, remainingQuota: remaining - 1 });
    }

    if (body.action === "generate-plan") {
      const brief = planBriefSchema.safeParse(body.brief);
      if (!brief.success) throw new AIError("invalid_request");

      const { data: run } = await admin.from("generation_runs").insert({
        user_id: caller.userId, action: "generate-plan", model: config.model,
        embedding_model: config.embeddingModel, prompt_version: config.promptVersion,
        status: "started",
      }).select("id").single();
      runId = run?.id ?? null;

      const result = await generatePlan(brief.data);

      if (runId) {
        await admin.from("generation_runs").update({
          status: "succeeded",
          grounding_level: result.groundingLevel,
          retrieved_chunk_ids: result.chunkIds,
          latency_ms: result.latencyMs,
          validation_repair_used: result.repairUsed,
          safe_metadata: {
            grades: brief.data.grades.length,
            duration: brief.data.durationMinutes,
            language: brief.data.outputLanguage,
            readinessScore: result.readiness.score,
            issueCount: result.readiness.issues.length,
          },
        }).eq("id", runId);
      }

      return json({
        ok: true,
        plan: result.plan,
        readiness: result.readiness,
        groundingLevel: result.groundingLevel,
        constraint: result.constraint,
        meta: {
          generationRunId: runId,
          model: config.model,
          promptVersion: config.promptVersion,
          latencyMs: result.latencyMs,
          repairUsed: result.repairUsed,
          passagesUsed: result.chunkIds.length,
          remainingQuota: remaining - 1,
        },
      });
    }

    throw new AIError("invalid_request", "That action is not supported.");
  } catch (err) {
    const aiError = err instanceof AIError ? err : new AIError("internal");
    if (runId) {
      await admin.from("generation_runs").update({
        status: aiError.code === "quota_exceeded" ? "quota-exceeded" : "failed",
        error_code: aiError.code,
      }).eq("id", runId).then(() => undefined, () => undefined);
    }
    if (!(err instanceof AIError)) {
      console.error("unhandled", err instanceof Error ? err.message : "unknown", { userId });
    }
    return aiError.toResponse();
  }
});
