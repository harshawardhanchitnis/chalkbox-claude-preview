-- ChalkBox 002: identity
create type user_role as enum ('teacher','admin');

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role user_role not null default 'teacher',
  full_name text,
  school_name text,
  district text,
  state text,
  is_anonymous boolean not null default false,
  onboarding_completed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table teacher_settings (
  user_id uuid primary key references profiles(id) on delete cascade,
  default_board text not null default 'cbse-ncert',
  default_state_board text,
  default_grades int[] not null default '{}',
  default_subjects text[] not null default '{}',
  default_language text not null default 'en-hi',
  default_duration_minutes int not null default 40,
  -- Used only for the clearly-labelled "estimated time saved" figure.
  baseline_planning_minutes int not null default 30,
  available_resources text[] not null default '{}',
  theme text not null default 'system',
  reduced_motion boolean not null default false,
  voice_enabled boolean not null default true,
  analytics_range_days int not null default 30,
  updated_at timestamptz not null default now()
);

-- Every new auth user gets a profile automatically, including anonymous
-- demo users, so RLS has something to match against from the first request.
create or replace function handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, is_anonymous, full_name)
  values (
    new.id,
    coalesce(new.is_anonymous, false),
    coalesce(new.raw_user_meta_data->>'full_name', 'Teacher')
  )
  on conflict (id) do nothing;
  insert into public.teacher_settings (user_id) values (new.id) on conflict do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();
