-- ChalkBox 007: analytics and notifications
create table analytics_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  name text not null,
  plan_id uuid references lesson_plans(id) on delete set null,
  -- Whitelisted, non-identifying metadata only.
  safe_metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create index analytics_events_user_idx on analytics_events (user_id, created_at desc);

create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  type text not null,
  title text not null,
  message text not null,
  action_url text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create index notifications_user_idx on notifications (user_id, created_at desc);

create table feedback_submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete set null,
  category text not null check (category in ('bug','content-quality','feature','general')),
  message text not null,
  plan_id uuid references lesson_plans(id) on delete set null,
  status text not null default 'new' check (status in ('new','reviewed','resolved')),
  created_at timestamptz not null default now()
);

/**
 * Teacher analytics, computed from real records.
 *
 * Deliberately a SQL function rather than a stored counter: there is no
 * separate number that can drift away from the underlying data, and an
 * account with no plans honestly returns zeros.
 *
 * "Minutes saved" is an ESTIMATE and is labelled as such everywhere it is
 * shown: baseline planning time minus a nominal two minutes per generated
 * plan, floored at zero.
 */
create or replace function teacher_analytics(p_user uuid, p_days int default 30)
returns jsonb language sql stable as $$
  with window_start as (select now() - make_interval(days => p_days) as ts),
  plans as (
    select * from lesson_plans
    where owner_id = p_user and created_at >= (select ts from window_start)
  ),
  baseline as (
    select coalesce(max(baseline_planning_minutes), 30) as mins
    from teacher_settings where user_id = p_user
  ),
  sessions as (
    select * from teach_sessions
    where teacher_id = p_user and started_at >= (select ts from window_start)
  )
  select jsonb_build_object(
    'rangeDays', p_days,
    'plansCreated', (select count(*) from plans),
    'plansTaught', (select count(*) from plans where status = 'taught'),
    'plansReused', (select count(*) from plans where origin_plan_id is not null),
    'offlinePinnedPlans', (select count(*) from plans where is_pinned_offline),
    'estimatedMinutesSaved',
      greatest(0, (select count(*) from plans) * ((select mins from baseline) - 2)),
    'groundingCoveragePercent',
      coalesce(round(100.0 * (select count(*) from plans where grounding_level in ('grounded','partial'))
        / nullif((select count(*) from plans), 0)), 0),
    'reflectionCompletionPercent',
      coalesce(round(100.0 * (select count(*) from lesson_reflections r
        join plans p on p.id = r.plan_id) / nullif((select count(*) from sessions), 0)), 0),
    'learnerOutcomes', jsonb_build_object(
      'total', coalesce((select sum(attendance_count) from sessions), 0),
      'met', coalesce((select sum(met_objective_count) from sessions), 0),
      'partial', coalesce((select sum(partially_met_count) from sessions), 0),
      'support', coalesce((select sum(needs_support_count) from sessions), 0)
    ),
    'bySubject', coalesce((select jsonb_agg(jsonb_build_object('subject', subject, 'count', c))
      from (select subject, count(*) c from plans group by subject) t), '[]'::jsonb),
    'byGrade', coalesce((select jsonb_agg(jsonb_build_object('grade', g, 'count', c))
      from (select unnest(grades) g, count(*) c from plans group by 1) t), '[]'::jsonb),
    'byLanguage', coalesce((select jsonb_agg(jsonb_build_object('language', output_language, 'count', c))
      from (select output_language, count(*) c from plans group by 1) t), '[]'::jsonb)
  );
$$;
