-- ChalkBox 004: plans, versions, generation audit
create table lesson_plans (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles(id) on delete cascade,
  origin_plan_id uuid references lesson_plans(id) on delete set null,
  current_version_id uuid,
  title text not null,
  status text not null default 'draft' check (status in ('draft','ready','taught','archived')),
  visibility text not null default 'private' check (visibility in ('private','unlisted','community')),
  -- Filterable columns are relational; the evolving pedagogical structure is
  -- validated JSONB. Ownership and search never depend on parsing JSON.
  grades int[] not null,
  subject text not null,
  topic text not null,
  chapter text,
  output_language text not null,
  duration_minutes int not null,
  lesson_date date,
  brief jsonb not null,
  content jsonb not null,
  grounding_level text not null default 'ungrounded'
    check (grounding_level in ('grounded','partial','ungrounded')),
  readiness jsonb not null default '{"score":0,"issues":[],"checkedAt":null}',
  constraint_plan jsonb not null default '{}',
  tags text[] not null default '{}',
  is_favourite boolean not null default false,
  is_pinned_offline boolean not null default false,
  schema_version int not null default 1,
  version_number int not null default 1,
  generation_run_id uuid,
  last_taught_at timestamptz,
  archived_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index lesson_plans_owner_idx on lesson_plans (owner_id, updated_at desc);
create index lesson_plans_status_idx on lesson_plans (owner_id, status);
create index lesson_plans_search_idx on lesson_plans using gin (title gin_trgm_ops);

create table plan_versions (
  id uuid primary key default gen_random_uuid(),
  plan_id uuid not null references lesson_plans(id) on delete cascade,
  version_number int not null,
  snapshot jsonb not null,
  brief_snapshot jsonb not null,
  reason text not null check (reason in
    ('generated','manual-checkpoint','before-regeneration','published','restored')),
  created_by uuid references profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (plan_id, version_number)
);

-- Audit of every model call. Carries no lesson text and no student data --
-- only what is needed to diagnose a failure or reproduce a result.
create table generation_runs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete set null,
  plan_id uuid references lesson_plans(id) on delete set null,
  action text not null,
  model text not null,
  embedding_model text,
  prompt_version text not null,
  status text not null check (status in ('started','succeeded','failed','quota-exceeded')),
  grounding_level text,
  retrieved_chunk_ids uuid[] not null default '{}',
  latency_ms int,
  validation_repair_used boolean not null default false,
  error_code text,
  safe_metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create index generation_runs_user_day_idx on generation_runs (user_id, created_at desc);

-- Server-side daily quota. Enforced here rather than in the client so the
-- limit cannot be bypassed by calling the function directly.
create or replace function ai_requests_today(p_user uuid)
returns int language sql stable as $$
  select count(*)::int from generation_runs
  where user_id = p_user
    and status in ('succeeded','started')
    and created_at >= date_trunc('day', now());
$$;
