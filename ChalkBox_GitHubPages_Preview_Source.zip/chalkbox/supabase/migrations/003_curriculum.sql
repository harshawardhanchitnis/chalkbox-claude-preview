-- ChalkBox 003: curriculum knowledge layer
--
-- Content policy: this table holds ORIGINAL ChalkBox instructional material and
-- openly licensed resources only. It is not a copy of NCERT textbook prose.
-- Curriculum *taxonomy* (class/subject/unit/chapter) is factual and is used for
-- alignment; the passages themselves are ours or openly licensed.

create table curriculum_sources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  publisher text not null,
  board text not null default 'cbse-ncert',
  state_board text,
  grades int[] not null,
  subjects text[] not null,
  language text not null default 'en',
  edition text,
  source_url text,
  licence text not null,
  attribution text not null,
  content_origin text not null default 'chalkbox-original'
    check (content_origin in ('chalkbox-original','open-licensed','user-provided')),
  status text not null default 'draft'
    check (status in ('draft','processing','active','disabled','failed')),
  chunk_count int not null default 0,
  indexed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table curriculum_chunks (
  id uuid primary key default gen_random_uuid(),
  source_id uuid not null references curriculum_sources(id) on delete cascade,
  grade int not null,
  subject text not null,
  unit text,
  chapter text,
  heading text,
  text text not null,
  locator text,
  token_count int not null default 0,
  ordinal int not null default 0,
  -- gemini-embedding-001 truncated to 768 dims via Matryoshka.
  -- Changing this requires changing GEMINI_EMBEDDING_DIMENSIONS together.
  embedding vector(768),
  tsv tsvector generated always as (to_tsvector('simple', text)) stored,
  created_at timestamptz not null default now()
);

create index curriculum_chunks_embedding_idx
  on curriculum_chunks using ivfflat (embedding vector_cosine_ops) with (lists = 100);
create index curriculum_chunks_tsv_idx on curriculum_chunks using gin (tsv);
create index curriculum_chunks_filter_idx on curriculum_chunks (source_id, grade, subject);

-- Learning outcomes are stored discretely, not as prose, so the readiness
-- checker can verify coverage one outcome at a time.
create table learning_outcomes (
  id uuid primary key default gen_random_uuid(),
  source_id uuid references curriculum_sources(id) on delete cascade,
  board text not null default 'cbse-ncert',
  grade int not null,
  subject text not null,
  chapter text,
  code text not null,
  statement text not null,
  unique (board, grade, subject, code)
);

/**
 * Hybrid retrieval.
 *
 * Vector search alone misses exact chapter names and numerals, which matter a
 * lot here. Keyword search alone misses paraphrase across languages. We run
 * both and fuse the rankings with Reciprocal Rank Fusion, which needs no
 * tuning and no second model to host.
 */
create or replace function match_curriculum(
  query_embedding vector(768),
  query_text text,
  filter_grades int[] default null,
  filter_subject text default null,
  filter_chapter text default null,
  match_count int default 8,
  candidate_count int default 40
)
returns table (
  id uuid, source_id uuid, grade int, subject text, chapter text,
  heading text, text text, locator text, score double precision
)
language sql stable as $$
  with dense as (
    select c.id, row_number() over (order by c.embedding <=> query_embedding) as rank
    from curriculum_chunks c
    join curriculum_sources s on s.id = c.source_id and s.status = 'active'
    where (filter_grades is null or c.grade = any(filter_grades))
      and (filter_subject is null or c.subject = filter_subject)
      and (filter_chapter is null or c.chapter = filter_chapter)
    order by c.embedding <=> query_embedding
    limit candidate_count
  ),
  sparse as (
    select c.id, row_number() over (
      order by ts_rank_cd(c.tsv, plainto_tsquery('simple', query_text)) desc
    ) as rank
    from curriculum_chunks c
    join curriculum_sources s on s.id = c.source_id and s.status = 'active'
    where c.tsv @@ plainto_tsquery('simple', query_text)
      and (filter_grades is null or c.grade = any(filter_grades))
      and (filter_subject is null or c.subject = filter_subject)
      and (filter_chapter is null or c.chapter = filter_chapter)
    limit candidate_count
  ),
  fused as (
    select coalesce(d.id, sp.id) as id,
           coalesce(1.0 / (60 + d.rank), 0) + coalesce(1.0 / (60 + sp.rank), 0) as score
    from dense d full outer join sparse sp on sp.id = d.id
  )
  select c.id, c.source_id, c.grade, c.subject, c.chapter,
         c.heading, c.text, c.locator, f.score
  from fused f
  join curriculum_chunks c on c.id = f.id
  order by f.score desc
  limit match_count;
$$;
