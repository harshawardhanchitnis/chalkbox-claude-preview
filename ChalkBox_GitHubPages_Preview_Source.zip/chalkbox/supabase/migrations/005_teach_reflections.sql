-- ChalkBox 005: teaching sessions and reflection
--
-- Privacy rule: only AGGREGATE learner counts are ever stored. No student
-- names, no per-student rows, nothing that could identify a child.
create table teach_sessions (
  id uuid primary key default gen_random_uuid(),
  plan_id uuid not null references lesson_plans(id) on delete cascade,
  teacher_id uuid not null references profiles(id) on delete cascade,
  plan_version_id uuid references plan_versions(id) on delete set null,
  started_at timestamptz not null default now(),
  ended_at timestamptz,
  completed_step_ids text[] not null default '{}',
  current_step_id text,
  elapsed_seconds int not null default 0,
  attendance_count int check (attendance_count between 0 and 200),
  met_objective_count int check (met_objective_count >= 0),
  partially_met_count int check (partially_met_count >= 0),
  needs_support_count int check (needs_support_count >= 0),
  engagement_rating int check (engagement_rating between 1 and 5),
  completed_as_planned boolean,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  -- The tallies can never exceed the number of children in the room.
  constraint outcome_within_attendance check (
    attendance_count is null
    or coalesce(met_objective_count,0) + coalesce(partially_met_count,0)
       + coalesce(needs_support_count,0) <= attendance_count
  )
);

create table lesson_reflections (
  id uuid primary key default gen_random_uuid(),
  plan_id uuid not null references lesson_plans(id) on delete cascade,
  teach_session_id uuid references teach_sessions(id) on delete cascade,
  teacher_id uuid not null references profiles(id) on delete cascade,
  worked_well text[] not null default '{}',
  challenges text[] not null default '{}',
  changes_for_next_time text[] not null default '{}',
  private_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table reflection_action_items (
  id uuid primary key default gen_random_uuid(),
  reflection_id uuid not null references lesson_reflections(id) on delete cascade,
  teacher_id uuid not null references profiles(id) on delete cascade,
  text text not null,
  status text not null default 'open' check (status in ('open','completed')),
  due_date date,
  completed_at timestamptz,
  created_at timestamptz not null default now()
);
