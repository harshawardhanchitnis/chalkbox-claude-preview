-- ChalkBox 008: Row Level Security
--
-- Every table is protected. Frontend route guards are UX only; this file is
-- the actual security boundary. Anonymous demo users are real authenticated
-- identities, so the same ownership rules apply to them unchanged.

alter table profiles                enable row level security;
alter table teacher_settings        enable row level security;
alter table lesson_plans            enable row level security;
alter table plan_versions           enable row level security;
alter table generation_runs         enable row level security;
alter table teach_sessions          enable row level security;
alter table lesson_reflections      enable row level security;
alter table reflection_action_items enable row level security;
alter table plan_shares             enable row level security;
alter table community_publications  enable row level security;
alter table community_saves         enable row level security;
alter table publication_reports     enable row level security;
alter table analytics_events        enable row level security;
alter table notifications           enable row level security;
alter table feedback_submissions    enable row level security;
alter table curriculum_sources      enable row level security;
alter table curriculum_chunks       enable row level security;
alter table learning_outcomes       enable row level security;

-- Role lookup used by admin policies. SECURITY DEFINER so a policy on
-- profiles cannot recurse into itself while checking the role.
create or replace function is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin');
$$;

-- ---------------------------------------------------------------- identity
create policy "read own profile" on profiles
  for select using (auth.uid() = id or is_admin());
create policy "update own profile" on profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);
-- Note: role is deliberately NOT updatable from the client. Promotion to
-- admin happens only through a migration run against the database.

create policy "own settings" on teacher_settings
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ------------------------------------------------------------------- plans
create policy "own plans" on lesson_plans
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

create policy "own plan versions" on plan_versions
  for all using (
    exists (select 1 from lesson_plans p
            where p.id = plan_versions.plan_id and p.owner_id = auth.uid())
  ) with check (
    exists (select 1 from lesson_plans p
            where p.id = plan_versions.plan_id and p.owner_id = auth.uid())
  );

-- Approved community publications expose their version snapshot to everyone.
create policy "read published versions" on plan_versions
  for select using (
    exists (select 1 from community_publications cp
            where cp.plan_version_id = plan_versions.id and cp.status = 'approved')
  );

create policy "read own generation runs" on generation_runs
  for select using (auth.uid() = user_id or is_admin());

-- ---------------------------------------------------------- teach + reflect
create policy "own teach sessions" on teach_sessions
  for all using (auth.uid() = teacher_id) with check (auth.uid() = teacher_id);
create policy "own reflections" on lesson_reflections
  for all using (auth.uid() = teacher_id) with check (auth.uid() = teacher_id);
create policy "own action items" on reflection_action_items
  for all using (auth.uid() = teacher_id) with check (auth.uid() = teacher_id);

-- ---------------------------------------------------------------- sharing
create policy "own shares" on plan_shares
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
-- Public share reads go through get_shared_plan(), which is SECURITY DEFINER.
-- The shares table itself is never publicly selectable, so tokens cannot be
-- enumerated.

-- -------------------------------------------------------------- community
create policy "read approved publications" on community_publications
  for select using (status = 'approved' or auth.uid() = author_id or is_admin());
create policy "submit own publication" on community_publications
  for insert with check (
    auth.uid() = author_id
    and status = 'pending'
    and exists (select 1 from lesson_plans p
                where p.id = plan_id and p.owner_id = auth.uid())
  );
create policy "withdraw own publication" on community_publications
  for update using (auth.uid() = author_id) with check (auth.uid() = author_id);
create policy "moderate publications" on community_publications
  for update using (is_admin()) with check (is_admin());

create policy "own saves" on community_saves
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "file reports" on publication_reports
  for insert with check (auth.uid() = reporter_id);
create policy "admin reads reports" on publication_reports
  for select using (is_admin());

-- ------------------------------------------------- analytics/notifications
create policy "own analytics" on analytics_events
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "admin reads analytics" on analytics_events
  for select using (is_admin());
create policy "own notifications" on notifications
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "submit feedback" on feedback_submissions
  for insert with check (auth.uid() = user_id or user_id is null);
create policy "read own feedback" on feedback_submissions
  for select using (auth.uid() = user_id or is_admin());

-- ------------------------------------------------------------- curriculum
-- Active curriculum is world-readable so citations resolve for public shares.
-- Only admins may write it; ingestion runs with the service key, offline.
create policy "read active sources" on curriculum_sources
  for select using (status = 'active' or is_admin());
create policy "admin writes sources" on curriculum_sources
  for all using (is_admin()) with check (is_admin());
create policy "read chunks of active sources" on curriculum_chunks
  for select using (
    exists (select 1 from curriculum_sources s
            where s.id = curriculum_chunks.source_id and s.status = 'active')
    or is_admin()
  );
create policy "admin writes chunks" on curriculum_chunks
  for all using (is_admin()) with check (is_admin());
create policy "read outcomes" on learning_outcomes for select using (true);
create policy "admin writes outcomes" on learning_outcomes
  for all using (is_admin()) with check (is_admin());
