-- ChalkBox 009: explicit grants
--
-- The Data API is configured NOT to expose new tables automatically, so each
-- table a client legitimately needs is granted here on purpose.

grant usage on schema public to anon, authenticated;

grant select, insert, update, delete on
  lesson_plans, plan_versions, teach_sessions, lesson_reflections,
  reflection_action_items, plan_shares, community_publications,
  community_saves, analytics_events, notifications, teacher_settings
  to authenticated;

grant select on curriculum_sources, curriculum_chunks, learning_outcomes to anon, authenticated;
grant select, update on profiles to authenticated;
grant select on generation_runs to authenticated;
grant insert on publication_reports, feedback_submissions to authenticated;

grant execute on function match_curriculum(vector, text, int[], text, text, int, int) to authenticated;
grant execute on function teacher_analytics(uuid, int) to authenticated;
grant execute on function get_shared_plan(text) to anon, authenticated;
grant execute on function ai_requests_today(uuid) to authenticated;
grant execute on function is_admin() to authenticated;

-- generation_runs is written only by the Edge Function using the service key,
-- so that a client cannot forge quota records to reset its own limit.
revoke insert, update, delete on generation_runs from authenticated;
