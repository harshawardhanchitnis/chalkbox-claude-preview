-- ChalkBox 006: sharing and community
--
-- Both shares and publications point at an immutable plan_version, never at
-- the live plan, so editing a plan can never silently change what a public
-- link or an approved community post shows.
create table plan_shares (
  id uuid primary key default gen_random_uuid(),
  plan_id uuid not null references lesson_plans(id) on delete cascade,
  plan_version_id uuid not null references plan_versions(id) on delete cascade,
  owner_id uuid not null references profiles(id) on delete cascade,
  -- Only the hash is stored; the raw token exists once, in the owner's link.
  token_hash text not null unique,
  is_active boolean not null default true,
  expires_at timestamptz,
  revoked_at timestamptz,
  view_count int not null default 0,
  created_at timestamptz not null default now()
);

create table community_publications (
  id uuid primary key default gen_random_uuid(),
  plan_id uuid not null references lesson_plans(id) on delete cascade,
  plan_version_id uuid not null references plan_versions(id) on delete cascade,
  author_id uuid not null references profiles(id) on delete cascade,
  title text not null,
  summary text not null,
  grades int[] not null,
  subject text not null,
  output_language text not null,
  licence text not null default 'CC-BY-4.0',
  status text not null default 'pending'
    check (status in ('pending','approved','rejected','withdrawn')),
  moderator_id uuid references profiles(id) on delete set null,
  moderation_reason text,
  approved_at timestamptz,
  clone_count int not null default 0,
  report_count int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index community_pub_status_idx on community_publications (status, updated_at desc);

create table community_saves (
  id uuid primary key default gen_random_uuid(),
  publication_id uuid not null references community_publications(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  cloned_plan_id uuid references lesson_plans(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (publication_id, user_id)
);

create table publication_reports (
  id uuid primary key default gen_random_uuid(),
  publication_id uuid not null references community_publications(id) on delete cascade,
  reporter_id uuid references profiles(id) on delete set null,
  reason text not null,
  created_at timestamptz not null default now()
);

-- Public read of a shared plan by token, without exposing the shares table.
create or replace function get_shared_plan(p_token_hash text)
returns table (title text, content jsonb, brief jsonb, grades int[],
               subject text, output_language text, duration_minutes int,
               grounding_level text, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  update plan_shares set view_count = view_count + 1
  where token_hash = p_token_hash and is_active
    and (expires_at is null or expires_at > now()) and revoked_at is null;

  select p.title, v.snapshot, v.brief_snapshot, p.grades, p.subject,
         p.output_language, p.duration_minutes, p.grounding_level, s.created_at
  from plan_shares s
  join plan_versions v on v.id = s.plan_version_id
  join lesson_plans p on p.id = s.plan_id
  where s.token_hash = p_token_hash and s.is_active
    and (s.expires_at is null or s.expires_at > now()) and s.revoked_at is null;
$$;
