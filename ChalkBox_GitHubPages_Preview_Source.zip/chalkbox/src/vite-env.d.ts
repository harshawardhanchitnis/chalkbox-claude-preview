/// <reference types="vite/client" />
/// <reference types="vite-plugin-pwa/client" />

interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL?: string;
  readonly VITE_SUPABASE_PUBLISHABLE_KEY?: string;
  readonly VITE_APP_ENV?: "development" | "production" | "test";
  readonly VITE_DEMO_ENABLED?: string;
  readonly VITE_TURNSTILE_SITE_KEY?: string;
  readonly VITE_APP_VERSION?: string;
}
interface ImportMeta { readonly env: ImportMetaEnv }
