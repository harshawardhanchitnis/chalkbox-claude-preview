import React from "react";
import ReactDOM from "react-dom/client";
import { RouterProvider } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "sonner";
import { router } from "./app/router";
import { ErrorBoundary } from "./components/feedback/ErrorBoundary";
import { useAppStore } from "./store/app.store";
import "./styles/globals.css";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      // Offline is normal here, not an error condition worth hammering.
      retry: (failureCount) => navigator.onLine && failureCount < 2,
      refetchOnWindowFocus: false,
    },
  },
});

function applyTheme() {
  const theme = useAppStore.getState().theme;
  const dark = theme === "dark" ||
    (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.classList.toggle("dark", dark);
}
applyTheme();
useAppStore.subscribe(applyTheme);
window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", applyTheme);

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <RouterProvider router={router} />
        <Toaster position="bottom-center" richColors closeButton />
      </QueryClientProvider>
    </ErrorBoundary>
  </React.StrictMode>,
);
