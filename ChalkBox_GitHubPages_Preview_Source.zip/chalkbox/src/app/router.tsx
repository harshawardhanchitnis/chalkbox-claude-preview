import { createHashRouter, Navigate } from "react-router-dom";
import { lazy, Suspense } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { RouteErrorBoundary } from "@/components/feedback/ErrorBoundary";
import { OnboardingGuard } from "./guards/OnboardingGuard";
import { PlanSkeleton } from "@/components/ui";

const LandingPage = lazy(() => import("@/features/marketing/pages/LandingPage").then((m) => ({ default: m.LandingPage })));
const AboutPage = lazy(() => import("@/features/marketing/pages/AboutPage").then((m) => ({ default: m.AboutPage })));
const PrivacyPage = lazy(() => import("@/features/marketing/pages/PrivacyPage").then((m) => ({ default: m.PrivacyPage })));
const AuthPage = lazy(() => import("@/features/auth/pages/AuthPage").then((m) => ({ default: m.AuthPage })));
const DemoBootstrapPage = lazy(() => import("@/features/demo/pages/DemoBootstrapPage").then((m) => ({ default: m.DemoBootstrapPage })));
const OnboardingPage = lazy(() => import("@/features/onboarding/pages/OnboardingPage").then((m) => ({ default: m.OnboardingPage })));
const DashboardPage = lazy(() => import("@/features/dashboard/pages/DashboardPage").then((m) => ({ default: m.DashboardPage })));
const NewPlanPage = lazy(() => import("@/features/plans/pages/NewPlanPage").then((m) => ({ default: m.NewPlanPage })));
const PlanEditorPage = lazy(() => import("@/features/plans/pages/PlanEditorPage").then((m) => ({ default: m.PlanEditorPage })));
const PlanPreviewPage = lazy(() => import("@/features/plans/pages/PlanPreviewPage").then((m) => ({ default: m.PlanPreviewPage })));
const TeachModePage = lazy(() => import("@/features/teach/pages/TeachModePage").then((m) => ({ default: m.TeachModePage })));
const LibraryPage = lazy(() => import("@/features/library/pages/LibraryPage").then((m) => ({ default: m.LibraryPage })));
const CommunityPage = lazy(() => import("@/features/community/pages/CommunityPage").then((m) => ({ default: m.CommunityPage })));
const CommunityPlanPage = lazy(() => import("@/features/community/pages/CommunityPlanPage").then((m) => ({ default: m.CommunityPlanPage })));
const AnalyticsPage = lazy(() => import("@/features/analytics/pages/AnalyticsPage").then((m) => ({ default: m.AnalyticsPage })));
const SettingsPage = lazy(() => import("@/features/settings/pages/SettingsPage").then((m) => ({ default: m.SettingsPage })));
const AdminPage = lazy(() => import("@/features/admin/pages/AdminPage").then((m) => ({ default: m.AdminPage })));
const OfflinePage = lazy(() => import("@/features/offline/pages/OfflinePage").then((m) => ({ default: m.OfflinePage })));
const PublicSharePage = lazy(() => import("@/features/sharing/pages/PublicSharePage").then((m) => ({ default: m.PublicSharePage })));

function Lazy({ children }: { children: React.ReactNode }) {
  return <Suspense fallback={<div className="p-6"><PlanSkeleton /></div>}>{children}</Suspense>;
}

const wrap = (el: React.ReactNode) => <Lazy>{el}</Lazy>;

export const router = createHashRouter([
  { path: "/", element: wrap(<LandingPage />), errorElement: <RouteErrorBoundary /> },
  { path: "/about", element: wrap(<AboutPage />) },
  { path: "/privacy", element: wrap(<PrivacyPage />) },
  { path: "/auth", element: wrap(<AuthPage />) },
  { path: "/demo", element: wrap(<DemoBootstrapPage />) },
  { path: "/offline", element: wrap(<OfflinePage />) },
  { path: "/share/:token", element: wrap(<PublicSharePage />) },

  // Teach Mode is full-screen and deliberately outside AppShell.
  { path: "/app/plans/:planId/teach", element: wrap(<TeachModePage />), errorElement: <RouteErrorBoundary /> },

  {
    path: "/app",
    element: <OnboardingGuard><AppShell /></OnboardingGuard>,
    errorElement: <RouteErrorBoundary />,
    children: [
      { index: true, element: wrap(<DashboardPage />) },
      { path: "onboarding", element: wrap(<OnboardingPage />) },
      { path: "plans/new", element: wrap(<NewPlanPage />) },
      { path: "plans/:planId", element: wrap(<PlanEditorPage />) },
      { path: "plans/:planId/preview", element: wrap(<PlanPreviewPage />) },
      { path: "library", element: wrap(<LibraryPage />) },
      { path: "community", element: wrap(<CommunityPage />) },
      { path: "community/:publicationId", element: wrap(<CommunityPlanPage />) },
      { path: "analytics", element: wrap(<AnalyticsPage />) },
      { path: "settings", element: wrap(<SettingsPage />) },
      { path: "admin", element: wrap(<AdminPage />) },
    ],
  },
  { path: "*", element: <Navigate to="/" replace /> },
]);
