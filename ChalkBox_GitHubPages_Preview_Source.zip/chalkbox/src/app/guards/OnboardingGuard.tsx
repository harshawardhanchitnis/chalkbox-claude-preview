import { useEffect, useState } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useRepositories } from "@/hooks/use-repositories";
import { PlanSkeleton } from "@/components/ui";

/**
 * Sends a first-time teacher through onboarding.
 *
 * A UX guard, not a security control. Real authorisation is enforced by
 * row-level security in migration 008; nothing here protects data.
 */
export function OnboardingGuard({ children }: { children: React.ReactNode }) {
  const repos = useRepositories();
  const location = useLocation();
  const [state, setState] = useState<"checking" | "ready" | "needs-onboarding">("checking");

  useEffect(() => {
    let cancelled = false;
    repos.settings.get().then((settings) => {
      if (cancelled) return;
      setState(settings?.onboardingCompleted ? "ready" : "needs-onboarding");
    }).catch(() => !cancelled && setState("needs-onboarding"));
    return () => { cancelled = true; };
  }, [repos]);

  if (state === "checking") return <div className="p-6"><PlanSkeleton /></div>;
  if (state === "needs-onboarding" && !location.pathname.endsWith("/onboarding")) {
    return <Navigate to="/app/onboarding" replace />;
  }
  return <>{children}</>;
}
