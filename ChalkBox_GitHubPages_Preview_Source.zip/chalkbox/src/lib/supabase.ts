import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { env, hasBackend } from "./env";

/**
 * The single Supabase browser client.
 *
 * Uses the PUBLISHABLE key only. RLS is what protects data; the publishable
 * key is designed to be public. The service-role key and the Gemini key never
 * appear in this bundle.
 *
 * Returns null when no backend is configured, so the whole application can run
 * in Demo Mode against IndexedDB before the hosted project is wired up.
 */
let client: SupabaseClient | null = null;

export function supabase(): SupabaseClient | null {
  if (!hasBackend) return null;
  if (!client) {
    client = createClient(env.supabaseUrl, env.supabaseKey, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
      global: { headers: { "x-application-name": "chalkbox" } },
    });
  }
  return client;
}

export async function callLessonAI<T>(body: Record<string, unknown>): Promise<T> {
  const sb = supabase();
  if (!sb) {
    throw new AIUnavailableError(
      "AI generation needs a connected backend. Demo Mode can still open, edit and teach the prepared lessons.",
    );
  }
  const { data, error } = await sb.functions.invoke("lesson-ai", { body });
  if (error) throw new AIUnavailableError(error.message);
  if (data && typeof data === "object" && "ok" in data && data.ok === false) {
    const err = data as { code: string; message: string; retryable: boolean };
    throw new AIRequestError(err.code, err.message, err.retryable);
  }
  return data as T;
}

export class AIUnavailableError extends Error {
  readonly code = "backend_unavailable";
  readonly retryable = false;
}

export class AIRequestError extends Error {
  constructor(readonly code: string, message: string, readonly retryable: boolean) {
    super(message);
  }
}
