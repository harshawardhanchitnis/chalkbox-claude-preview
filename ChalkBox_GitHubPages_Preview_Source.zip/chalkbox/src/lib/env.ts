import { z } from "zod";

/**
 * Environment validation.
 *
 * Fails loudly at startup rather than producing a blank screen when a variable
 * is missing. Only PUBLIC values appear here -- the Gemini key lives in
 * Supabase Edge Function secrets and is never part of the browser bundle.
 */
const schema = z.object({
  VITE_SUPABASE_URL: z.string().url().optional(),
  VITE_SUPABASE_PUBLISHABLE_KEY: z.string().min(10).optional(),
  VITE_APP_ENV: z.enum(["development", "production", "test"]).default("development"),
  VITE_DEMO_ENABLED: z.string().default("true"),
  VITE_TURNSTILE_SITE_KEY: z.string().optional(),
  VITE_APP_VERSION: z.string().default("1.0.0"),
});

const parsed = schema.safeParse(import.meta.env);

export const env = parsed.success
  ? {
      supabaseUrl: parsed.data.VITE_SUPABASE_URL ?? "",
      supabaseKey: parsed.data.VITE_SUPABASE_PUBLISHABLE_KEY ?? "",
      appEnv: parsed.data.VITE_APP_ENV,
      demoEnabled: parsed.data.VITE_DEMO_ENABLED !== "false",
      turnstileSiteKey: parsed.data.VITE_TURNSTILE_SITE_KEY ?? "",
      version: parsed.data.VITE_APP_VERSION,
    }
  : {
      supabaseUrl: "", supabaseKey: "", appEnv: "development" as const,
      demoEnabled: true, turnstileSiteKey: "", version: "1.0.0",
    };

/**
 * Whether a live backend is configured.
 *
 * When false the app still runs fully in Demo Mode against IndexedDB. This is
 * what lets the whole product be developed and demonstrated before the hosted
 * Supabase project has migrations applied.
 */
export const hasBackend = Boolean(env.supabaseUrl && env.supabaseKey);
export const envErrors = parsed.success ? [] : parsed.error.errors.map((e) => `${e.path.join(".")}: ${e.message}`);
