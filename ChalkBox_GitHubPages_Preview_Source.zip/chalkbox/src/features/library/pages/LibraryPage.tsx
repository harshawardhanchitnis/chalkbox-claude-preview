import { useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { toast } from "sonner";
import { LayoutGrid, List, Plus, Search } from "lucide-react";
import type { LessonPlan } from "@chalkbox/contracts";
import { useRepositories, useIsDemo } from "@/hooks/use-repositories";
import { useDebouncedValue } from "@/hooks/use-debounced";
import { PlanCard } from "@/features/plans/components/PlanCard";
import {
  Badge, Button, Chip, EmptyState, Input, PageHeader, Skeleton,
} from "@/components/ui";

const SUBJECTS = ["science", "mathematics", "social-science", "english", "hindi", "evs"];
const STATUSES = ["draft", "ready", "taught", "archived"];

/** Filters live in the URL so a teacher can bookmark or share a view. */
export function LibraryPage() {
  const repos = useRepositories();
  const isDemo = useIsDemo();
  const [params, setParams] = useSearchParams();
  const [plans, setPlans] = useState<LessonPlan[] | null>(null);
  const [view, setView] = useState<"grid" | "list">("grid");
  const [pendingDelete, setPendingDelete] = useState<LessonPlan | null>(null);

  const search = params.get("q") ?? "";
  const subject = params.get("subject") ?? "";
  const status = params.get("status") ?? "";
  const favourites = params.get("fav") === "1";
  const offline = params.get("offline") === "1";
  const sort = (params.get("sort") as "updated" | "created" | "title") ?? "updated";
  const debouncedSearch = useDebouncedValue(search, 250);

  function setParam(key: string, value: string | null) {
    const next = new URLSearchParams(params);
    if (!value) next.delete(key); else next.set(key, value);
    setParams(next, { replace: true });
  }

  const filters = useMemo(() => ({
    search: debouncedSearch || undefined,
    subject: subject || undefined,
    status: status || undefined,
    favouritesOnly: favourites,
    offlineOnly: offline,
    includeArchived: status === "archived",
    sort,
  }), [debouncedSearch, subject, status, favourites, offline, sort]);

  useEffect(() => {
    let cancelled = false;
    setPlans(null);
    repos.plans.list(filters).then((p) => !cancelled && setPlans(p));
    return () => { cancelled = true; };
  }, [repos, filters]);

  async function reload() { setPlans(await repos.plans.list(filters)); }

  /** Delete with a real undo window rather than an irreversible tap. */
  async function deleteWithUndo(plan: LessonPlan) {
    setPendingDelete(plan);
    await repos.plans.remove(plan.id);
    await reload();
    toast("Plan deleted", {
      action: {
        label: "Undo",
        onClick: async () => { await repos.plans.create(plan); await reload(); setPendingDelete(null); },
      },
      duration: 7000,
      onDismiss: () => setPendingDelete(null),
    });
  }

  const hasFilters = Boolean(search || subject || status || favourites || offline);

  return (
    <div>
      <PageHeader
        title="My plans"
        description={plans ? `${plans.length} plan${plans.length === 1 ? "" : "s"} on this device` : undefined}
        actions={<Link to="/app/plans/new" className="btn-primary"><Plus className="h-4 w-4" aria-hidden /> New plan</Link>}
      />

      <div className="mb-4 space-y-3">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" aria-hidden />
            <Input aria-label="Search plans" value={search} className="pl-9"
              placeholder="Search by title or topic…"
              onChange={(e) => setParam("q", e.target.value || null)} />
          </div>
          <Button variant="secondary" size="sm"
            aria-label={view === "grid" ? "Switch to list view" : "Switch to grid view"}
            onClick={() => setView(view === "grid" ? "list" : "grid")}>
            {view === "grid" ? <List className="h-4 w-4" aria-hidden /> : <LayoutGrid className="h-4 w-4" aria-hidden />}
          </Button>
        </div>

        <div className="flex flex-wrap gap-2">
          <Chip active={favourites} onClick={() => setParam("fav", favourites ? null : "1")}>Favourites</Chip>
          <Chip active={offline} onClick={() => setParam("offline", offline ? null : "1")}>Offline</Chip>
          {STATUSES.map((s) => (
            <Chip key={s} active={status === s} onClick={() => setParam("status", status === s ? null : s)}>
              {s}
            </Chip>
          ))}
        </div>

        <div className="flex flex-wrap gap-2">
          {SUBJECTS.map((s) => (
            <Chip key={s} active={subject === s} onClick={() => setParam("subject", subject === s ? null : s)}>
              {s.replace("-", " ")}
            </Chip>
          ))}
        </div>

        <div className="flex items-center gap-2 text-sm">
          <label htmlFor="sort" className="text-muted">Sort</label>
          <select id="sort" value={sort} onChange={(e) => setParam("sort", e.target.value)}
            className="rounded-field border border-line bg-surface px-2 py-1">
            <option value="updated">Last edited</option>
            <option value="created">Newest</option>
            <option value="title">Title</option>
          </select>
          {hasFilters && (
            <button className="ml-auto underline underline-offset-4"
              onClick={() => setParams(new URLSearchParams(), { replace: true })}>
              Clear filters
            </button>
          )}
        </div>
      </div>

      {plans === null && (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {[0,1,2,3,4,5].map((i) => <Skeleton key={i} className="h-28" />)}
        </div>
      )}

      {plans?.length === 0 && (
        hasFilters ? (
          <EmptyState title="Nothing matches those filters"
            description="Try removing a filter or searching for something else."
            action={<Button variant="secondary" onClick={() => setParams(new URLSearchParams(), { replace: true })}>Clear filters</Button>} />
        ) : (
          <EmptyState title="No plans yet"
            description="Make your first lesson plan — it takes about a minute."
            action={<Link to="/app/plans/new" className="btn-primary">Make a plan</Link>} />
        )
      )}

      {plans && plans.length > 0 && (
        <ul className={view === "grid" ? "grid gap-3 sm:grid-cols-2 lg:grid-cols-3" : "space-y-2"}>
          {plans.map((plan) => (
            <li key={plan.id} className="relative">
              <PlanCard plan={plan} isDemo={isDemo} />
              <div className="mt-1 flex flex-wrap gap-1.5">
                <Button variant="ghost" size="sm" onClick={async () => {
                  await repos.plans.duplicate(plan.id); await reload(); toast.success("Duplicated");
                }}>Duplicate</Button>
                <Button variant="ghost" size="sm" onClick={async () => {
                  await repos.plans.archive(plan.id, plan.status !== "archived"); await reload();
                }}>{plan.status === "archived" ? "Restore" : "Archive"}</Button>
                <Button variant="ghost" size="sm"
                  disabled={pendingDelete?.id === plan.id}
                  onClick={() => deleteWithUndo(plan)}>Delete</Button>
              </div>
            </li>
          ))}
        </ul>
      )}

      {isDemo && plans && plans.length > 0 && (
        <p className="mt-6 text-center text-sm text-muted">
          <Badge tone="accent">Demo data</Badge>{" "}
          These are prepared sample lessons stored on this device.
        </p>
      )}
    </div>
  );
}
