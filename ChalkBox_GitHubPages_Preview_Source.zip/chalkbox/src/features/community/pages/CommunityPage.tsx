import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Users } from "lucide-react";
import { useRepositories, useIsDemo } from "@/hooks/use-repositories";
import { Badge, Chip, EmptyState, Input, PageHeader, Skeleton } from "@/components/ui";
import type { CommunityItem } from "@/repositories/repository.types";

export function CommunityPage() {
  const repos = useRepositories();
  const isDemo = useIsDemo();
  const [items, setItems] = useState<CommunityItem[] | null>(null);
  const [search, setSearch] = useState("");
  const [subject, setSubject] = useState("");

  useEffect(() => {
    setItems(null);
    repos.community.browse({ search: search || undefined, subject: subject || undefined }).then(setItems);
  }, [repos, search, subject]);

  return (
    <div>
      <PageHeader
        title="Community templates"
        description="Lessons other teachers have shared under an open licence. Save one and adapt it to your room."
      />

      {isDemo && (
        <div className="mb-4 rounded-card border border-accent/50 bg-accent/10 px-4 py-2.5">
          <Badge tone="accent">Demo data</Badge>
          <span className="ml-2 text-sm">These contributors are fictional.</span>
        </div>
      )}

      <div className="mb-4 space-y-3">
        <Input aria-label="Search templates" value={search} placeholder="Search templates…"
          onChange={(e) => setSearch(e.target.value)} />
        <div className="flex flex-wrap gap-2">
          {["science", "mathematics", "social-science", "english"].map((s) => (
            <Chip key={s} active={subject === s} onClick={() => setSubject(subject === s ? "" : s)}>
              {s.replace("-", " ")}
            </Chip>
          ))}
        </div>
      </div>

      {items === null && (
        <div className="grid gap-3 sm:grid-cols-2">
          {[0,1,2,3].map((i) => <Skeleton key={i} className="h-32" />)}
        </div>
      )}

      {items?.length === 0 && (
        <EmptyState icon={<Users className="h-8 w-8" />} title="No templates match"
          description="Try a different search or subject." />
      )}

      {items && items.length > 0 && (
        <ul className="grid gap-3 sm:grid-cols-2">
          {items.map((item) => (
            <li key={item.id}>
              <Link to={`/app/community/${item.id}`}
                className="card block h-full p-4 transition hover:border-primary">
                <h2 className="font-display text-base font-semibold">{item.title}</h2>
                <p className="mt-1 text-sm text-muted">{item.summary}</p>
                <div className="mt-3 flex flex-wrap items-center gap-1.5">
                  <Badge tone="info">Class {item.grades.join(", ")}</Badge>
                  <Badge tone="neutral">{item.subject.replace("-", " ")}</Badge>
                  <Badge tone="neutral">{item.licence}</Badge>
                </div>
                <p className="mt-2 text-xs text-muted">
                  By {item.authorName} · saved {item.cloneCount} times
                </p>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
