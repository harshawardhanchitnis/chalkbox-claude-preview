import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";
import { Copy, Flag } from "lucide-react";
import type { LessonPlan } from "@chalkbox/contracts";
import { useRepositories } from "@/hooks/use-repositories";
import { Badge, Button, EmptyState, Modal, PlanSkeleton, Textarea } from "@/components/ui";
import { PrintablePlan } from "@/features/export/PrintablePlan";
import type { CommunityItem } from "@/repositories/repository.types";

export function CommunityPlanPage() {
  const { publicationId } = useParams();
  const navigate = useNavigate();
  const repos = useRepositories();
  const [data, setData] = useState<{ item: CommunityItem; plan: LessonPlan } | null>(null);
  const [loading, setLoading] = useState(true);
  const [reporting, setReporting] = useState(false);
  const [reason, setReason] = useState("");

  useEffect(() => {
    if (!publicationId) return;
    repos.community.get(publicationId).then((d) => { setData(d); setLoading(false); });
  }, [publicationId, repos]);

  if (loading) return <PlanSkeleton />;
  if (!data) {
    return <EmptyState title="Template not available"
      description="It may have been withdrawn by its author."
      action={<Link to="/app/community" className="btn-primary">Back to templates</Link>} />;
  }

  return (
    <div className="mx-auto max-w-read">
      <Link to="/app/community" className="text-sm text-muted underline underline-offset-4">← Templates</Link>

      <div className="mb-5 mt-3 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold">{data.item.title}</h1>
          <p className="mt-1 text-sm text-muted">
            By {data.item.authorName} · {data.item.licence}
            {data.item.isDemoData && <Badge tone="accent" className="ml-2">Demo data</Badge>}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" onClick={() => setReporting(true)}>
            <Flag className="h-4 w-4" aria-hidden /> Report
          </Button>
          <Button onClick={async () => {
            const copy = await repos.community.clone(data.item.id);
            toast.success("Saved to your plans");
            navigate(`/app/plans/${copy.id}`);
          }}>
            <Copy className="h-4 w-4" aria-hidden /> Save a copy
          </Button>
        </div>
      </div>

      <div className="card p-6">
        <PrintablePlan plan={data.plan} />
      </div>

      <Modal open={reporting} onClose={() => setReporting(false)}
        title="Report this template"
        description="Tell us what is wrong. A moderator will review it."
        footer={
          <>
            <Button variant="secondary" onClick={() => setReporting(false)}>Cancel</Button>
            <Button variant="danger" disabled={reason.trim().length < 5} onClick={async () => {
              await repos.community.report(data.item.id, reason);
              setReporting(false); setReason("");
              toast.success("Reported. Thank you.");
            }}>Send report</Button>
          </>
        }>
        <Textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)}
          placeholder="What is wrong with this template?" />
      </Modal>
    </div>
  );
}
