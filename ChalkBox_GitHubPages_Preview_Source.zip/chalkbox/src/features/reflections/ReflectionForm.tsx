import { useState } from "react";
import { toast } from "sonner";
import type { LessonPlan } from "@chalkbox/contracts";
import { useRepositories } from "@/hooks/use-repositories";
import { Button, Field, Input, Textarea } from "@/components/ui";

/**
 * After-class reflection.
 *
 * Records AGGREGATE counts only. There is no field for a student's name here
 * or anywhere in the database, and the schema enforces that the three tallies
 * can never exceed the number of children present.
 */
export function ReflectionForm({ plan, onDone }: { plan: LessonPlan; onDone: () => void }) {
  const repos = useRepositories();
  const [attendance, setAttendance] = useState(plan.brief.classSize);
  const [met, setMet] = useState(0);
  const [partial, setPartial] = useState(0);
  const [support, setSupport] = useState(0);
  const [engagement, setEngagement] = useState(4);
  const [completed, setCompleted] = useState(true);
  const [worked, setWorked] = useState("");
  const [challenge, setChallenge] = useState("");
  const [change, setChange] = useState("");
  const [busy, setBusy] = useState(false);

  const tallied = met + partial + support;
  const overCount = tallied > attendance;

  async function submit() {
    if (overCount) return;
    setBusy(true);
    try {
      await repos.teach.finish({
        id: `teach-${plan.id}`, planId: plan.id, updatedAt: new Date().toISOString(),
        currentStepId: null, completedStepIds: plan.content.timeline.map((s) => s.id),
        elapsedSeconds: plan.brief.durationMinutes * 60,
        attendanceCount: attendance, metObjectiveCount: met,
        partiallyMetCount: partial, needsSupportCount: support,
        engagementRating: engagement, completedAsPlanned: completed,
      });
      await repos.reflections.save({
        planId: plan.id,
        workedWell: worked ? [worked] : [],
        challenges: challenge ? [challenge] : [],
        changesForNextTime: change ? [change] : [],
        actionItems: change ? [change] : [],
      });
      await repos.analytics.record("plan_taught", plan.id);
      toast.success("Saved. This plan now shows as taught.");
      onDone();
    } finally { setBusy(false); }
  }

  return (
    <div className="space-y-4">
      <Field label="Students present" htmlFor="attendance">
        <Input id="attendance" inputMode="numeric" value={attendance}
          onChange={(e) => setAttendance(Number(e.target.value) || 0)} />
      </Field>

      <fieldset>
        <legend className="field-label">Roughly how many…</legend>
        <div className="grid grid-cols-3 gap-2">
          {([
            ["Met the goal", met, setMet],
            ["Partly", partial, setPartial],
            ["Need more help", support, setSupport],
          ] as const).map(([label, value, set]) => (
            <label key={label} className="text-sm">
              <span className="mb-1 block text-muted">{label}</span>
              <Input inputMode="numeric" value={value}
                onChange={(e) => set(Number(e.target.value) || 0)} />
            </label>
          ))}
        </div>
        {overCount && (
          <p role="alert" className="mt-1.5 text-sm font-medium text-danger">
            That adds up to {tallied}, which is more than the {attendance} students present.
          </p>
        )}
      </fieldset>

      <fieldset>
        <legend className="field-label">How engaged were they?</legend>
        <div className="flex gap-2">
          {[1, 2, 3, 4, 5].map((n) => (
            <button key={n} type="button" onClick={() => setEngagement(n)}
              aria-pressed={engagement === n}
              className={engagement === n ? "chip-on" : "chip-off"}>{n}</button>
          ))}
        </div>
      </fieldset>

      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={completed} onChange={(e) => setCompleted(e.target.checked)} />
        We finished the lesson as planned
      </label>

      <Field label="What worked" htmlFor="worked">
        <Textarea id="worked" rows={2} value={worked} onChange={(e) => setWorked(e.target.value)} />
      </Field>
      <Field label="What did not" htmlFor="challenge">
        <Textarea id="challenge" rows={2} value={challenge} onChange={(e) => setChallenge(e.target.value)} />
      </Field>
      <Field label="Next time I will" htmlFor="change" hint="Becomes a follow-up note on this plan.">
        <Textarea id="change" rows={2} value={change} onChange={(e) => setChange(e.target.value)} />
      </Field>

      <Button className="w-full" loading={busy} disabled={overCount} onClick={submit}>
        Save and finish
      </Button>
    </div>
  );
}
