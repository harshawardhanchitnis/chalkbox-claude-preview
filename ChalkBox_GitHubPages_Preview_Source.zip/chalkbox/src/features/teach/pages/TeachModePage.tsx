import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  ChevronLeft, ChevronRight, Pause, Play, RotateCcw, Volume2, X,
} from "lucide-react";
import type { LessonPlan, LessonStep } from "@chalkbox/contracts";
import { useRepositories } from "@/hooks/use-repositories";
import { Button, Modal, PlanSkeleton } from "@/components/ui";
import { ReflectionForm } from "@/features/reflections/ReflectionForm";
import { cn } from "@/lib/utils";

/**
 * Teach Mode.
 *
 * The plan on the wall, one step at a time, with a timer counting the step
 * down. No new data and no model call -- this is the same plan object the
 * editor renders, laid out for a room to read from six metres away.
 *
 * It exists because a plan that never survives contact with a classroom is not
 * worth much. Works entirely offline from a cached plan.
 */
export function TeachModePage() {
  const { planId } = useParams();
  const navigate = useNavigate();
  const repos = useRepositories();

  const [plan, setPlan] = useState<LessonPlan | null>(null);
  const [loading, setLoading] = useState(true);
  const [grade, setGrade] = useState<number | null>(null);
  const [stepIndex, setStepIndex] = useState(0);
  const [remaining, setRemaining] = useState(0);
  const [running, setRunning] = useState(false);
  const [showAnswers, setShowAnswers] = useState(false);
  const [confirmExit, setConfirmExit] = useState(false);
  const [finishing, setFinishing] = useState(false);
  const wakeLock = useRef<{ release?: () => Promise<void> } | null>(null);

  useEffect(() => {
    if (!planId) return;
    (async () => {
      const [p, draft] = await Promise.all([
        repos.plans.get(planId), repos.teach.loadDraft(planId),
      ]);
      setPlan(p);
      setGrade(p?.brief.grades[0] ?? null);
      if (draft) {
        // Restore an interrupted session rather than starting over.
        const idx = p?.content.timeline.findIndex((s) => s.id === draft.currentStepId) ?? 0;
        if (idx >= 0) setStepIndex(idx);
      }
      setLoading(false);
    })();
  }, [planId, repos]);

  const steps = useMemo(() => {
    if (!plan) return [] as LessonStep[];
    if (grade == null || plan.brief.grades.length === 1) return plan.content.timeline;
    // Show the steps that concern this class, plus everything shared.
    return plan.content.timeline.filter(
      (s) => s.gradeFocus.length === 0 || s.gradeFocus.includes(grade as never),
    );
  }, [plan, grade]);

  const step = steps[stepIndex];

  useEffect(() => {
    if (step) { setRemaining(step.durationMinutes * 60); setRunning(false); setShowAnswers(false); }
  }, [step]);

  useEffect(() => {
    if (!running) return;
    const t = setInterval(() => setRemaining((r) => (r <= 0 ? 0 : r - 1)), 1000);
    return () => clearInterval(t);
  }, [running]);

  // A teacher is not tapping the phone every thirty seconds.
  useEffect(() => {
    const nav = navigator as Navigator & { wakeLock?: { request(type: "screen"): Promise<{ release(): Promise<void> }> } };
    nav.wakeLock?.request("screen").then((l) => { wakeLock.current = l; }).catch(() => undefined);
    return () => { void wakeLock.current?.release?.(); };
  }, []);

  const saveDraft = useCallback(() => {
    if (!plan || !step) return;
    void repos.teach.saveDraft({
      id: `teach-${plan.id}`, planId: plan.id, updatedAt: new Date().toISOString(),
      currentStepId: step.id,
      completedStepIds: steps.slice(0, stepIndex).map((s) => s.id),
      elapsedSeconds: steps.slice(0, stepIndex).reduce((n, s) => n + s.durationMinutes * 60, 0),
    });
  }, [plan, step, steps, stepIndex, repos]);

  useEffect(() => { saveDraft(); }, [saveDraft]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") setStepIndex((i) => Math.min(i + 1, steps.length - 1));
      if (e.key === "ArrowLeft") setStepIndex((i) => Math.max(i - 1, 0));
      if (e.key === " ") { e.preventDefault(); setRunning((r) => !r); }
      if (e.key === "Escape") setConfirmExit(true);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [steps.length]);

  function readAloud() {
    if (!step || !("speechSynthesis" in window)) return;
    const utter = new SpeechSynthesisUtterance(
      [step.title, ...step.teacherActions, ...step.studentActions].join(". "),
    );
    utter.lang = plan?.brief.outputLanguage === "en" ? "en-IN" : "hi-IN";
    speechSynthesis.cancel();
    speechSynthesis.speak(utter);
  }

  if (loading) return <div className="p-6"><PlanSkeleton /></div>;
  if (!plan || !step) {
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center gap-4 p-6 text-center">
        <p className="font-display text-lg">This plan is not available on this device.</p>
        <Link to="/app/library" className="btn-primary">My plans</Link>
      </div>
    );
  }

  const hi = plan.brief.outputLanguage === "hi";
  const mm = String(Math.floor(remaining / 60)).padStart(2, "0");
  const ss = String(remaining % 60).padStart(2, "0");
  const over = remaining === 0;
  const questions = [...plan.content.assessment.exitTicket, ...plan.content.assessment.questionBank];
  const isLast = stepIndex === steps.length - 1;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-ink text-canvas">
      <div className="flex flex-wrap items-center gap-2 border-b border-white/15 px-4 py-2.5">
        <Button variant="ghost" size="sm" className="text-canvas hover:bg-white/10"
          onClick={() => setConfirmExit(true)}>
          <X className="h-4 w-4" aria-hidden /> {hi ? "बंद करें" : "Exit"}
        </Button>

        {plan.brief.grades.length > 1 && (
          <div className="flex gap-1.5" role="group" aria-label="Class">
            {plan.brief.grades.map((g) => (
              <button key={g} onClick={() => { setGrade(g); setStepIndex(0); }}
                className={cn("rounded-full px-3 py-1 font-display text-sm",
                  grade === g ? "bg-canvas text-ink" : "border border-white/30 text-canvas/80")}>
                {hi ? `कक्षा ${g}` : `Class ${g}`}
              </button>
            ))}
          </div>
        )}

        <div className="ml-auto flex items-center gap-2">
          {"speechSynthesis" in window && (
            <Button variant="ghost" size="sm" className="text-canvas hover:bg-white/10"
              aria-label="Read this step aloud" onClick={readAloud}>
              <Volume2 className="h-4 w-4" aria-hidden />
            </Button>
          )}
          <Button variant="ghost" size="sm" className="text-canvas hover:bg-white/10"
            aria-label="Reset timer" onClick={() => { setRemaining(step.durationMinutes * 60); setRunning(false); }}>
            <RotateCcw className="h-4 w-4" aria-hidden />
          </Button>
          <button onClick={() => setRunning((r) => !r)}
            aria-label={running ? "Pause timer" : "Start timer"}
            className={cn("flex items-center gap-2 rounded-field px-4 py-1.5 font-display text-2xl tabular-nums",
              over ? "bg-danger text-white" : "border border-white/30")}>
            {running ? <Pause className="h-4 w-4" aria-hidden /> : <Play className="h-4 w-4" aria-hidden />}
            <span aria-live="off">{mm}:{ss}</span>
          </button>
        </div>
      </div>

      <div className="flex flex-1 flex-col justify-center overflow-y-auto px-5 py-6 sm:px-12">
        <p className="font-display text-sm uppercase tracking-widest text-accent">
          {step.startMinute}–{step.startMinute + step.durationMinutes} min
          {step.attention === "independent" && (hi ? " · बिना आपके" : " · without you")}
          {step.gradeFocus.length > 0 && plan.brief.grades.length > 1 &&
            ` · ${hi ? "कक्षा" : "Class"} ${step.gradeFocus.join(", ")}`}
        </p>

        <h1 className="mt-2 font-display text-3xl font-bold leading-tight sm:text-5xl">
          {step.title}
        </h1>

        <div className="mt-6 grid gap-6 sm:grid-cols-2">
          <div>
            <p className="font-display text-xs uppercase tracking-widest text-canvas/60">
              {hi ? "आप करें" : "You do"}
            </p>
            <ul className="mt-2 space-y-2">
              {step.teacherActions.map((a, i) => (
                <li key={i} className="text-lg leading-relaxed sm:text-2xl">{a}</li>
              ))}
            </ul>
          </div>
          <div>
            <p className="font-display text-xs uppercase tracking-widest text-canvas/60">
              {hi ? "बच्चे करें" : "Students do"}
            </p>
            <ul className="mt-2 space-y-2">
              {step.studentActions.map((a, i) => (
                <li key={i} className="text-lg leading-relaxed sm:text-2xl">{a}</li>
              ))}
            </ul>
          </div>
        </div>

        {step.boardPrompt && (
          <div className="mt-6 rounded-panel border-2 border-dashed border-white/30 px-5 py-4">
            <p className="font-display text-xs uppercase tracking-widest text-accent">
              {hi ? "श्यामपट्ट पर" : "On the blackboard"}
            </p>
            <pre className="mt-2 whitespace-pre-wrap font-body text-lg leading-relaxed sm:text-2xl">
              {step.boardPrompt}
            </pre>
          </div>
        )}

        {step.materialIds.length > 0 && (
          <p className="mt-4 text-sm text-canvas/60">
            {hi ? "सामग्री" : "You need"}:{" "}
            {plan.content.materials
              .filter((m) => step.materialIds.includes(m.id))
              .map((m) => m.name).join(" · ")}
          </p>
        )}

        {isLast && questions.length > 0 && (
          <section className="mt-8 rounded-panel border border-white/20 p-5">
            <h2 className="font-display text-lg font-bold">{hi ? "जाँच प्रश्न" : "Quick check"}</h2>
            <ol className="mt-3 space-y-3">
              {questions.slice(0, 4).map((q, i) => (
                <li key={q.id} className="text-lg">
                  {i + 1}. {q.prompt}
                  {showAnswers && <div className="mt-1 text-base text-accent">→ {q.correctAnswer}</div>}
                </li>
              ))}
            </ol>
            <Button variant="ghost" className="mt-3 text-canvas hover:bg-white/10"
              onClick={() => setShowAnswers((v) => !v)}>
              {showAnswers ? (hi ? "उत्तर छिपाएँ" : "Hide answers") : (hi ? "उत्तर दिखाएँ" : "Show answers")}
            </Button>
          </section>
        )}
      </div>

      <div className="flex items-center gap-3 border-t border-white/15 px-4 py-3">
        <Button variant="ghost" className="text-canvas hover:bg-white/10"
          disabled={stepIndex === 0} onClick={() => setStepIndex((i) => i - 1)}
          aria-label="Previous step">
          <ChevronLeft className="h-5 w-5" aria-hidden />
        </Button>

        <div className="flex flex-1 gap-1" role="progressbar"
          aria-valuenow={stepIndex + 1} aria-valuemin={1} aria-valuemax={steps.length}
          aria-label="Lesson progress">
          {steps.map((_, i) => (
            <span key={i} className={cn("h-1.5 flex-1 rounded-full",
              i <= stepIndex ? "bg-accent" : "bg-white/20")} />
          ))}
        </div>

        {isLast ? (
          <Button onClick={() => setFinishing(true)}>{hi ? "समाप्त" : "Finish lesson"}</Button>
        ) : (
          <Button variant="secondary" onClick={() => setStepIndex((i) => i + 1)} aria-label="Next step">
            <ChevronRight className="h-5 w-5" aria-hidden />
          </Button>
        )}
      </div>

      <Modal open={confirmExit} onClose={() => setConfirmExit(false)}
        title={hi ? "कक्षा छोड़ें?" : "Leave Teach Mode?"}
        description="Your place in the lesson is saved on this device."
        footer={
          <>
            <Button variant="secondary" onClick={() => setConfirmExit(false)}>
              {hi ? "जारी रखें" : "Keep teaching"}
            </Button>
            <Button onClick={() => navigate(`/app/plans/${plan.id}`)}>
              {hi ? "बाहर जाएँ" : "Leave"}
            </Button>
          </>
        } />

      <Modal open={finishing} onClose={() => setFinishing(false)}
        title={hi ? "कक्षा कैसी रही?" : "How did it go?"}
        description="Only counts are recorded — never any student's name.">
        <ReflectionForm plan={plan}
          onDone={() => { setFinishing(false); navigate(`/app/plans/${plan.id}`); }} />
      </Modal>
    </div>
  );
}
