import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { BarChart, Bar, ResponsiveContainer, XAxis, YAxis, Tooltip, Cell } from "recharts";
import { useRepositories } from "@/hooks/use-repositories";
import {
  AccessibleChartTable, Badge, Card, Chip, EmptyState, PageHeader, Skeleton,
} from "@/components/ui";
import type { AnalyticsSummary } from "@/repositories/repository.types";

const COLOURS = ["#1F6B5C", "#2563EB", "#F59E0B", "#B45309", "#15803D", "#5F6D68"];

/**
 * Impact.
 *
 * Every number here is derived from the teacher's own stored records. Nothing
 * is hard-coded. An account with no plans shows zeros, because that is the
 * truth. In Demo Mode the underlying records are prepared fixtures, and the
 * page says so at the top.
 */
export function AnalyticsPage() {
  const repos = useRepositories();
  const [params, setParams] = useSearchParams();
  const range = Number(params.get("days") ?? 30);
  const [summary, setSummary] = useState<AnalyticsSummary | null>(null);

  useEffect(() => {
    setSummary(null);
    repos.analytics.summary(range).then(setSummary);
  }, [repos, range]);

  if (!summary) {
    return (
      <div>
        <PageHeader title="Impact" />
        <div className="grid gap-3 sm:grid-cols-4">
          {[0,1,2,3].map((i) => <Skeleton key={i} className="h-24" />)}
        </div>
      </div>
    );
  }

  const empty = summary.plansCreated === 0;
  const outcomes = summary.learnerOutcomes;

  return (
    <div>
      <PageHeader
        title="Impact"
        description="Everything here is worked out from your own plans and lessons."
        actions={
          <div className="flex gap-2">
            {[7, 30, 90].map((d) => (
              <Chip key={d} active={range === d}
                onClick={() => setParams({ days: String(d) }, { replace: true })}>
                {d} days
              </Chip>
            ))}
          </div>
        }
      />

      {summary.isDemoData && (
        <div className="mb-5 rounded-card border border-accent/50 bg-accent/10 px-4 py-3">
          <Badge tone="accent">Demo data</Badge>
          <p className="mt-1.5 text-sm">
            These figures are computed from the prepared demo lessons on this
            device, not from real classroom work.
          </p>
        </div>
      )}

      {empty ? (
        <EmptyState
          title="Nothing to show yet"
          description="Once you have made and taught some lessons, this page fills in with your own numbers."
        />
      ) : (
        <>
          <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Metric label="Plans made" value={summary.plansCreated} />
            <Metric label="Lessons taught" value={summary.plansTaught} />
            <Metric label="Reused from another plan" value={summary.plansReused} />
            <Metric label="Minutes saved" value={summary.estimatedMinutesSaved}
              note="Estimate: your usual planning time minus two minutes per plan." />
          </div>

          <div className="mb-6 grid gap-4 lg:grid-cols-2">
            <Card className="p-5">
              <h2 className="font-display text-base font-semibold">Plans by subject</h2>
              {summary.bySubject.length > 0 ? (
                <>
                  <div className="mt-3 h-52">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={summary.bySubject}>
                        <XAxis dataKey="subject" tick={{ fontSize: 11 }} />
                        <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                        <Tooltip />
                        <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                          {summary.bySubject.map((_, i) => (
                            <Cell key={i} fill={COLOURS[i % COLOURS.length]} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <AccessibleChartTable
                    caption="Plans by subject"
                    columns={["Subject", "Plans"]}
                    rows={summary.bySubject.map((s) => [s.subject, s.count])}
                  />
                </>
              ) : <p className="mt-2 text-sm text-muted">No data in this range.</p>}
            </Card>

            <Card className="p-5">
              <h2 className="font-display text-base font-semibold">Plans by class</h2>
              {summary.byGrade.length > 0 ? (
                <>
                  <div className="mt-3 h-52">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={summary.byGrade}>
                        <XAxis dataKey="grade" tick={{ fontSize: 11 }} />
                        <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                        <Tooltip />
                        <Bar dataKey="count" fill="#1F6B5C" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <AccessibleChartTable
                    caption="Plans by class"
                    columns={["Class", "Plans"]}
                    rows={summary.byGrade.map((g) => [g.grade, g.count])}
                  />
                </>
              ) : <p className="mt-2 text-sm text-muted">No data in this range.</p>}
            </Card>
          </div>

          <Card className="mb-6 p-5">
            <h2 className="font-display text-base font-semibold">How lessons went</h2>
            <p className="text-sm text-muted">
              Aggregate counts you recorded after teaching. No individual student
              is ever identified.
            </p>
            {outcomes.total > 0 ? (
              <>
                <div className="mt-4 flex h-6 overflow-hidden rounded-full">
                  {([
                    ["Met the goal", outcomes.met, "#15803D"],
                    ["Partly met", outcomes.partial, "#F59E0B"],
                    ["Need more help", outcomes.support, "#B45309"],
                  ] as const).map(([label, value, colour]) => (
                    value > 0 && (
                      <div key={label} title={`${label}: ${value}`}
                        style={{ width: `${(value / outcomes.total) * 100}%`, background: colour }} />
                    )
                  ))}
                </div>
                <p className="mt-2 text-sm text-muted">
                  {outcomes.met} of {outcomes.total} students met the lesson goal.
                </p>
                <AccessibleChartTable
                  caption="Learner outcomes"
                  columns={["Outcome", "Students"]}
                  rows={[
                    ["Met the goal", outcomes.met],
                    ["Partly met", outcomes.partial],
                    ["Need more help", outcomes.support],
                    ["Total present", outcomes.total],
                  ]}
                />
              </>
            ) : (
              <p className="mt-2 text-sm text-muted">
                Nothing recorded yet. Finish a lesson in Teach Mode to add to this.
              </p>
            )}
          </Card>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Metric label="Grounded in curriculum" value={summary.groundingCoveragePercent} suffix="%" />
            <Metric label="Reflections completed" value={summary.reflectionCompletionPercent} suffix="%" />
            <Metric label="Pinned offline" value={summary.offlinePinnedPlans} />
            <Metric label="Printed or exported" value={summary.exportCount} />
          </div>
        </>
      )}
    </div>
  );
}

function Metric({
  label, value, note, suffix,
}: { label: string; value: number; note?: string; suffix?: string }) {
  return (
    <Card className="p-4">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-1 font-display text-2xl font-bold tabular-nums">
        {value.toLocaleString("en-IN")}{suffix}
      </p>
      {note && <p className="mt-0.5 text-[11px] italic text-muted">{note}</p>}
    </Card>
  );
}
