import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { Database, RotateCcw, Trash2 } from "lucide-react";
import { useRepositories, useIsDemo } from "@/hooks/use-repositories";
import { useAppStore } from "@/store/app.store";
import { estimateStorage } from "@/db/dexie";
import { resetDemo } from "@/features/demo/demo.bootstrap";
import {
  Button, Card, Chip, Field, Input, Modal, PageHeader, Skeleton, Textarea,
} from "@/components/ui";
import type { TeacherSettings } from "@/repositories/repository.types";

const RESOURCES = [
  "Blackboard and chalk", "Coloured chalk", "Notebooks", "Slates",
  "Stones or pebbles", "Bottle caps", "Sticks or twigs", "String",
  "Old newspaper", "Water and a bucket", "Matchbox", "Candle",
  "Glass tumbler", "Rubber bands", "Leaves and seeds", "Measuring tape",
];

export function SettingsPage() {
  const repos = useRepositories();
  const isDemo = useIsDemo();
  const theme = useAppStore((s) => s.theme);
  const setTheme = useAppStore((s) => s.setTheme);
  const [settings, setSettings] = useState<TeacherSettings | null>(null);
  const [storage, setStorage] = useState<{ usedMB: number; quotaMB: number } | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const [feedback, setFeedback] = useState("");

  useEffect(() => {
    repos.settings.get().then(setSettings);
    estimateStorage().then(setStorage);
  }, [repos]);

  async function patch(update: Partial<TeacherSettings>) {
    if (!settings) return;
    const next = { ...settings, ...update };
    setSettings(next);
    await repos.settings.save(next);
  }

  if (!settings) return <Skeleton className="h-64" />;

  return (
    <div className="mx-auto max-w-form">
      <PageHeader title="Settings" />

      <div className="space-y-6">
        <Card className="p-5">
          <h2 className="mb-4 font-display text-base font-semibold">You and your classroom</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Name" htmlFor="name">
              <Input value={settings.displayName}
                onChange={(e) => patch({ displayName: e.target.value })} />
            </Field>
            <Field label="School" htmlFor="school">
              <Input value={settings.schoolName ?? ""}
                onChange={(e) => patch({ schoolName: e.target.value })} />
            </Field>
          </div>

          <fieldset className="mt-4">
            <legend className="field-label">Classes you teach</legend>
            <div className="flex flex-wrap gap-2">
              {[1,2,3,4,5,6,7,8,9,10].map((g) => (
                <Chip key={g} active={settings.defaultGrades.includes(g)}
                  onClick={() => patch({
                    defaultGrades: settings.defaultGrades.includes(g)
                      ? settings.defaultGrades.filter((x) => x !== g)
                      : [...settings.defaultGrades, g].sort((a, b) => a - b),
                  })}>{g}</Chip>
              ))}
            </div>
          </fieldset>

          <fieldset className="mt-4">
            <legend className="field-label">Default plan language</legend>
            <div className="flex gap-2">
              {([["hi","हिन्दी"],["en","English"],["en-hi","Both"]] as const).map(([v, l]) => (
                <Chip key={v} active={settings.defaultLanguage === v}
                  onClick={() => patch({ defaultLanguage: v })}>{l}</Chip>
              ))}
            </div>
          </fieldset>

          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <Field label="Usual period length" htmlFor="dur" hint="Minutes.">
              <Input id="dur" inputMode="numeric" value={settings.defaultDurationMinutes}
                onChange={(e) => patch({ defaultDurationMinutes: Number(e.target.value) || 40 })} />
            </Field>
            <Field label="Time you usually spend planning" htmlFor="base"
              hint="Only used for the estimated time-saved figure on your Impact page.">
              <Input id="base" inputMode="numeric" value={settings.baselinePlanningMinutes}
                onChange={(e) => patch({ baselinePlanningMinutes: Number(e.target.value) || 30 })} />
            </Field>
          </div>
        </Card>

        <Card className="p-5">
          <h2 className="mb-1 font-display text-base font-semibold">What your classroom has</h2>
          <p className="mb-3 text-sm text-muted">
            Plans will only ever use these, plus ordinary household objects.
          </p>
          <div className="flex flex-wrap gap-2">
            {RESOURCES.map((r) => (
              <Chip key={r} active={settings.availableResources.includes(r)}
                onClick={() => patch({
                  availableResources: settings.availableResources.includes(r)
                    ? settings.availableResources.filter((x) => x !== r)
                    : [...settings.availableResources, r],
                })}>{r}</Chip>
            ))}
          </div>
        </Card>

        <Card className="p-5">
          <h2 className="mb-4 font-display text-base font-semibold">Display and access</h2>
          <fieldset>
            <legend className="field-label">Theme</legend>
            <div className="flex gap-2">
              {(["light", "dark", "system"] as const).map((t) => (
                <Chip key={t} active={theme === t} onClick={() => { setTheme(t); patch({ theme: t }); }}>
                  {t}
                </Chip>
              ))}
            </div>
          </fieldset>
          <label className="mt-4 flex items-center gap-2 text-sm">
            <input type="checkbox" checked={settings.reducedMotion}
              onChange={(e) => patch({ reducedMotion: e.target.checked })} />
            Reduce motion and animation
          </label>
          <label className="mt-2 flex items-center gap-2 text-sm">
            <input type="checkbox" checked={settings.voiceEnabled}
              onChange={(e) => patch({ voiceEnabled: e.target.checked })} />
            Show the microphone button for voice input
          </label>
        </Card>

        <Card className="p-5">
          <h2 className="mb-2 flex items-center gap-2 font-display text-base font-semibold">
            <Database className="h-4 w-4" aria-hidden /> Storage on this device
          </h2>
          {storage ? (
            <p className="text-sm text-muted">
              Using {storage.usedMB} MB of about {storage.quotaMB} MB available.
            </p>
          ) : (
            <p className="text-sm text-muted">Your browser does not report a storage estimate.</p>
          )}
          {isDemo && (
            <Button variant="secondary" className="mt-3" onClick={() => setConfirmReset(true)}>
              <RotateCcw className="h-4 w-4" aria-hidden /> Reset the demo
            </Button>
          )}
        </Card>

        <Card className="p-5">
          <h2 className="mb-2 font-display text-base font-semibold">Send feedback</h2>
          <Textarea rows={3} value={feedback} placeholder="Something wrong, confusing or missing?"
            onChange={(e) => setFeedback(e.target.value)} />
          <Button variant="secondary" className="mt-3" disabled={feedback.trim().length < 5}
            onClick={() => { toast.success("Thank you — noted."); setFeedback(""); }}>
            Send
          </Button>
        </Card>

        <Card className="p-5">
          <h2 className="mb-2 font-display text-base font-semibold">Privacy</h2>
          <p className="text-sm text-muted">
            ChalkBox never records a student's name. Read what is and is not
            collected on the{" "}
            <Link to="/privacy" className="underline underline-offset-4">privacy page</Link>.
          </p>
        </Card>
      </div>

      <Modal open={confirmReset} onClose={() => setConfirmReset(false)}
        title="Reset the demo?"
        description="This erases the demo plans and your changes to them, then loads the original samples again. Only demo data is affected."
        footer={
          <>
            <Button variant="secondary" onClick={() => setConfirmReset(false)}>Cancel</Button>
            <Button variant="danger" onClick={async () => {
              await resetDemo();
              toast.success("Demo reset");
              window.location.href = "/app";
            }}>
              <Trash2 className="h-4 w-4" aria-hidden /> Reset
            </Button>
          </>
        } />
    </div>
  );
}
