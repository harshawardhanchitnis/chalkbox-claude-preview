import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Link2, Trash2 } from "lucide-react";
import { useRepositories, useIsDemo } from "@/hooks/use-repositories";
import { Button, Modal, Badge } from "@/components/ui";

/**
 * Share links.
 *
 * A share points at an immutable snapshot, so editing the plan afterwards can
 * never silently change what a recipient sees. Revoking is immediate.
 */
export function SharePlanDialog({
  open, onClose, planId,
}: { open: boolean; onClose: () => void; planId: string }) {
  const repos = useRepositories();
  const isDemo = useIsDemo();
  const [links, setLinks] = useState<Array<{ id: string; url: string; isActive: boolean; createdAt: string }>>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) repos.shares.listForPlan(planId).then(setLinks);
  }, [open, planId, repos]);

  return (
    <Modal open={open} onClose={onClose} title="Share this plan"
      description="Anyone with the link can read it. They cannot edit it, and they see nothing else from your account.">
      {isDemo && (
        <div className="mb-3 rounded-field border border-accent/50 bg-accent/10 px-3 py-2">
          <Badge tone="accent">Demo Mode</Badge>
          <p className="mt-1.5 text-sm">
            Links are created locally so you can see the flow, but there is no
            server to serve them from in the demo. They will open only on this device.
          </p>
        </div>
      )}

      <Button loading={busy} onClick={async () => {
        setBusy(true);
        try {
          const { url } = await repos.shares.create(planId);
          await navigator.clipboard?.writeText(url).catch(() => undefined);
          setLinks(await repos.shares.listForPlan(planId));
          toast.success("Link created and copied");
        } finally { setBusy(false); }
      }}>
        <Link2 className="h-4 w-4" aria-hidden /> Create a link
      </Button>

      {links.length > 0 && (
        <ul className="mt-4 space-y-2">
          {links.map((l) => (
            <li key={l.id} className="flex items-center gap-2 rounded-field border border-line px-3 py-2">
              <span className="min-w-0 flex-1 truncate text-sm">{l.url}</span>
              {l.isActive
                ? <Badge tone="success">active</Badge>
                : <Badge tone="neutral">revoked</Badge>}
              {l.isActive && (
                <Button variant="ghost" size="sm" aria-label="Revoke link"
                  onClick={async () => {
                    await repos.shares.revoke(l.id);
                    setLinks(await repos.shares.listForPlan(planId));
                    toast.success("Link revoked");
                  }}>
                  <Trash2 className="h-4 w-4" aria-hidden />
                </Button>
              )}
            </li>
          ))}
        </ul>
      )}
    </Modal>
  );
}
