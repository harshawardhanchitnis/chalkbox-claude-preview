import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import type { LessonPlan } from "@chalkbox/contracts";
import { demoDB } from "@/db/dexie";
import { EmptyState, PlanSkeleton } from "@/components/ui";
import { PrintablePlan } from "@/features/export/PrintablePlan";

/**
 * A publicly shared plan.
 *
 * Read-only, no navigation into the app, and no author details beyond what the
 * plan itself contains. In this build the token resolves against the local
 * store; the production adapter calls get_shared_plan(), which is the
 * SECURITY DEFINER function so share tokens can never be enumerated.
 */
export function PublicSharePage() {
  const { token } = useParams();
  const [plan, setPlan] = useState<LessonPlan | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "missing">("loading");

  useEffect(() => {
    (async () => {
      if (!token) { setState("missing"); return; }
      const entry = await demoDB.kv.get(`share-token:${token}`);
      const planId = entry?.value as string | undefined;
      const row = planId ? await demoDB.plans.get(planId) : undefined;
      if (!row) { setState("missing"); return; }
      setPlan(row.plan);
      setState("ready");
    })();
  }, [token]);

  if (state === "loading") return <div className="p-6"><PlanSkeleton /></div>;

  if (state === "missing" || !plan) {
    return (
      <div className="mx-auto max-w-read px-5 py-16">
        <EmptyState
          title="This link is not available"
          description="It may have been revoked by its author, expired, or never existed."
          action={<Link to="/" className="btn-primary">About ChalkBox</Link>}
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-read px-5 py-10">
      <div className="no-print mb-6 flex items-center justify-between">
        <Link to="/" className="font-display font-bold">ChalkBox</Link>
        <button className="btn-secondary btn-sm" onClick={() => window.print()}>Print</button>
      </div>
      <PrintablePlan plan={plan} watermark={plan.status === "draft" ? "DRAFT" : undefined} />
      <p className="no-print mt-8 border-t border-line pt-4 text-sm text-muted">
        Shared read-only from ChalkBox.{" "}
        <Link to="/demo" className="underline underline-offset-4">Try it yourself</Link>
      </p>
    </div>
  );
}
