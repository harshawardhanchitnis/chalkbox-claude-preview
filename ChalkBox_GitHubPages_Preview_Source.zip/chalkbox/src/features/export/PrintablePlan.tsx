import type { LessonPlan } from "@chalkbox/contracts";

/**
 * The printable plan.
 *
 * Print CSS rather than a PDF library: it renders Devanagari correctly using
 * the fonts already loaded, it works offline, it adds nothing to the bundle,
 * and the browser's own "Save as PDF" produces a real PDF on every platform
 * a teacher is likely to use.
 *
 * One class per page in multigrade mode, so a teacher can hand each track to
 * a different group.
 */
export function PrintablePlan({
  plan, watermark,
}: { plan: LessonPlan; watermark?: string }) {
  const { content, brief } = plan;
  const multi = brief.grades.length > 1;
  const hi = brief.outputLanguage === "hi";

  return (
    <article className="prose-plan" lang={hi ? "hi" : "en"}>
      {watermark && (
        <p className="mb-3 inline-block rounded border border-warning px-2 py-0.5 text-xs font-bold uppercase tracking-widest text-warning">
          {watermark}
        </p>
      )}

      <header className="border-b border-line pb-3">
        <h1 className="font-display text-2xl font-bold">{plan.title}</h1>
        <p className="mt-1 text-sm text-muted">
          {multi ? `Classes ${brief.grades.join(", ")}` : `Class ${brief.grades[0]}`}
          {" · "}{brief.subject}
          {brief.chapter && ` · ${brief.chapter}`}
          {" · "}{brief.durationMinutes} minutes
          {" · "}{brief.classSize} students
        </p>
      </header>

      <section className="mt-4">
        <h3>Overview</h3>
        <p>{content.overview}</p>
      </section>

      <section className="mt-4">
        <h3>What this lesson should achieve</h3>
        <ol className="list-inside list-decimal space-y-1 text-[15px]">
          {content.objectives.map((o) => <li key={o.id}>{o.statement}</li>)}
        </ol>
      </section>

      <section className="mt-4">
        <h3>Materials</h3>
        <p className="text-[15px]">{content.materials.map((m) => m.name).join(" · ")}</p>
      </section>

      {content.differentiation.multigrade && (
        <section className="mt-4">
          <h3>Shared anchor activity</h3>
          <p>{content.differentiation.multigrade.anchorActivity}</p>
        </section>
      )}

      <section className="mt-4">
        <h3>The lesson</h3>
        <table className="w-full text-[14px]">
          <thead>
            <tr className="border-b border-line text-left">
              <th scope="col" className="w-20 py-1">Time</th>
              <th scope="col" className="py-1">You do</th>
              <th scope="col" className="py-1">Students do</th>
            </tr>
          </thead>
          <tbody>
            {content.timeline.map((s) => (
              <tr key={s.id} className="border-b border-line/60 align-top">
                <td className="py-2 tabular-nums">
                  {s.startMinute}–{s.startMinute + s.durationMinutes}′
                  {s.gradeFocus.length > 0 && multi && (
                    <div className="text-xs text-muted">Cl. {s.gradeFocus.join(",")}</div>
                  )}
                </td>
                <td className="py-2">
                  <strong className="block">{s.title}</strong>
                  {s.teacherActions.join(" ")}
                  {s.boardPrompt && (
                    <div className="mt-1 border-l-2 border-line pl-2 text-[13px]">
                      Board: {s.boardPrompt}
                    </div>
                  )}
                </td>
                <td className="py-2">{s.studentActions.join(" ")}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {content.differentiation.multigrade?.tracks.map((track) => (
        <section key={track.grade} className="print-break mt-6">
          <h2 className="font-display text-xl font-bold">Class {track.grade}</h2>
          <h3>Work to do independently</h3>
          <ul className="list-inside list-disc space-y-1 text-[15px]">
            {track.independentTasks.map((t, i) => <li key={i}>{t}</li>)}
          </ul>
          {track.assessmentPrompt && (
            <>
              <h3>Check</h3>
              <p>{track.assessmentPrompt}</p>
            </>
          )}
        </section>
      ))}

      {(content.assessment.exitTicket.length > 0 || content.assessment.questionBank.length > 0) && (
        <section className="mt-6">
          <h3>Questions and answers</h3>
          <ol className="list-inside list-decimal space-y-2 text-[15px]">
            {[...content.assessment.exitTicket, ...content.assessment.questionBank].map((q) => (
              <li key={q.id}>
                {q.prompt}
                <div className="text-muted">Answer: {q.correctAnswer}</div>
              </li>
            ))}
          </ol>
        </section>
      )}

      {content.homeworkOrExtension.length > 0 && (
        <section className="mt-4">
          <h3>Homework</h3>
          <ul className="list-inside list-disc text-[15px]">
            {content.homeworkOrExtension.map((h, i) => <li key={i}>{h}</li>)}
          </ul>
        </section>
      )}

      {content.safetyNotes.length > 0 && (
        <section className="mt-4">
          <h3>Safety</h3>
          <ul className="list-inside list-disc text-[15px]">
            {content.safetyNotes.map((s, i) => <li key={i}>{s}</li>)}
          </ul>
        </section>
      )}

      {content.citations.length > 0 && (
        <section className="mt-6 border-t border-line pt-3">
          <h3>Sources used</h3>
          <ol className="list-inside list-decimal text-[13px] text-muted">
            {content.citations.map((c) => (
              <li key={c.id}>{c.label}{c.locator ? ` — ${c.locator}` : ""}</li>
            ))}
          </ol>
        </section>
      )}

      <footer className="mt-6 border-t border-line pt-2 text-[11px] text-muted">
        Generated with ChalkBox. AI-assisted draft — please review before teaching.
        {plan.groundingLevel === "ungrounded" && " Not grounded in curriculum sources."}
      </footer>
    </article>
  );
}
