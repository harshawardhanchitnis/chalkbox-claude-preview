import { Link } from "react-router-dom";

export function AboutPage() {
  return (
    <div className="mx-auto max-w-read px-5 py-12">
      <Link to="/" className="text-sm text-muted underline underline-offset-4">← Back</Link>
      <h1 className="mt-4 font-display text-3xl font-bold tracking-tight">About ChalkBox</h1>

      <h2 className="mt-8 font-display text-xl font-semibold">The problem</h2>
      <p className="mt-2 text-[15px] leading-relaxed">
        Omni_EdTech_7 asks for a tool that helps teachers in under-resourced
        schools create effective lesson plans quickly. The hard part is not
        writing prose. It is that the teacher writing the plan is often the only
        adult in the room, teaching three classes at one blackboard, with a
        period that ends when the bell rings whether the lesson is finished or
        not.
      </p>

      <h2 className="mt-8 font-display text-xl font-semibold">How ChalkBox is different</h2>
      <p className="mt-2 text-[15px] leading-relaxed">
        Most AI planning tools are a prompt box in front of a language model.
        ChalkBox puts three deterministic layers around the model. A constraint
        solver computes the lesson timetable before any text is generated, so
        the guarantee that one teacher cannot instruct two classes at once is
        arithmetic rather than hope. Retrieval grounds the content in a real
        curriculum corpus with citations. Then eight checks run on the result
        before a teacher ever sees it.
      </p>

      <h2 className="mt-8 font-display text-xl font-semibold">Principles</h2>
      <ul className="mt-2 space-y-2 text-[15px]">
        <li><strong>Never show impressive-looking nonsense.</strong> A plan that fails a check is shown with the failure named, not quietly replaced.</li>
        <li><strong>The teacher decides.</strong> Every plan opens as an editable draft.</li>
        <li><strong>No child's data.</strong> Only aggregate counts are ever recorded.</li>
        <li><strong>Assume nothing works.</strong> No signal, no printer, no projector.</li>
      </ul>

      <h2 className="mt-8 font-display text-xl font-semibold">Team</h2>
      <p className="mt-2 text-[15px]">
        Team HarshLabs — Harshawardhan Chitnis. Built for the Omnikon National
        Hackathon 2026.
      </p>
    </div>
  );
}
