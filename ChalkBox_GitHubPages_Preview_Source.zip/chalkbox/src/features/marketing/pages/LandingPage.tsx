import { Link } from "react-router-dom";
import { BookOpen, Check, Languages, Quote, Users, WifiOff } from "lucide-react";

export function LandingPage() {
  return (
    <div className="min-h-dvh bg-canvas">
      <header className="mx-auto flex max-w-app items-center justify-between px-5 py-4">
        <span className="flex items-center gap-2">
          <BookOpen className="h-6 w-6 text-primary" aria-hidden />
          <span className="font-display text-lg font-bold">ChalkBox</span>
        </span>
        <nav aria-label="Site" className="flex items-center gap-1 sm:gap-3">
          <Link to="/about" className="btn-ghost btn-sm">About</Link>
          <Link to="/privacy" className="btn-ghost btn-sm hidden sm:inline-flex">Privacy</Link>
          <Link to="/demo" className="btn-primary btn-sm">Try the demo</Link>
        </nav>
      </header>

      <main id="main">
        <section className="mx-auto max-w-app px-5 pb-14 pt-8 sm:pt-16">
          <p className="font-display text-sm font-semibold uppercase tracking-widest text-primary">
            Omni_EdTech_7 · Team HarshLabs
          </p>
          <h1 className="mt-3 max-w-3xl font-display text-4xl font-bold leading-[1.1] tracking-tight sm:text-6xl">
            Your classroom. Your plan.
          </h1>
          <p className="mt-5 max-w-read text-lg text-muted">
            ChalkBox turns a class, a chapter and a bell schedule into a
            minute-by-minute lesson plan — in Hindi or English, using only the
            materials you actually have, and split across every class sitting in
            your room.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/demo" className="btn-primary">Try it now — no account needed</Link>
            <Link to="/auth" className="btn-secondary">Create an account</Link>
          </div>
          <p className="mt-3 text-sm text-muted">
            The demo runs entirely on your device with prepared sample lessons.
          </p>
        </section>

        <section className="border-y border-line bg-surface py-14">
          <div className="mx-auto max-w-app px-5">
            <h2 className="font-display text-2xl font-bold tracking-tight">
              Built for the room that actually exists
            </h2>
            <p className="mt-2 max-w-read text-muted">
              Over a lakh Indian schools run on a single teacher. Most planning
              tools quietly assume a projector, a printer and a full-strength
              connection. ChalkBox assumes none of them.
            </p>

            <div className="mt-8 grid gap-5 sm:grid-cols-3">
              <Feature
                icon={<Users className="h-5 w-5" aria-hidden />}
                title="One teacher, several classes"
                body="A timetable is computed before any text is written, so no two classes ever need you at the same moment. One shared activity holds the room together; each class works at its own depth."
              />
              <Feature
                icon={<Languages className="h-5 w-5" aria-hidden />}
                title="Real Hindi, not Roman"
                body="Plans are generated in Devanagari, not transliterated English, so they can go straight into a register, onto a notice board or into a printed worksheet."
              />
              <Feature
                icon={<WifiOff className="h-5 w-5" aria-hidden />}
                title="Works without a signal"
                body="Plans are saved to your phone the moment they exist. Open, edit, print and teach from them with no connection, and changes sync when you are back online."
              />
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-app px-5 py-14">
          <h2 className="font-display text-2xl font-bold tracking-tight">How it works</h2>
          <ol className="mt-6 grid gap-6 sm:grid-cols-4">
            {[
              ["Describe the lesson", "One sentence, typed or spoken. ChalkBox pulls out the class, subject, chapter and duration for you to check."],
              ["Confirm your room", "Which classes are in front of you, how long the period is, and what is actually on your shelf."],
              ["Get a real plan", "Timed steps, board layout, activity, differentiation, questions and homework — with the curriculum passage each part came from."],
              ["Teach from it", "Full-screen classroom mode with a timer, then record how it went in aggregate."],
            ].map(([title, body], i) => (
              <li key={title}>
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary font-display text-sm font-bold text-white">
                  {i + 1}
                </span>
                <h3 className="mt-3 font-display text-base font-semibold">{title}</h3>
                <p className="mt-1 text-sm text-muted">{body}</p>
              </li>
            ))}
          </ol>
        </section>

        <section className="border-t border-line bg-primary-soft/50 py-14">
          <div className="mx-auto max-w-read px-5">
            <Quote className="h-6 w-6 text-primary" aria-hidden />
            <h2 className="mt-3 font-display text-xl font-bold">What ChalkBox will not do</h2>
            <ul className="mt-4 space-y-2 text-[15px]">
              {[
                "Show you a plan that failed its own checks without telling you.",
                "Invent a textbook citation or a page number.",
                "Suggest a projector, a printout or lab apparatus your school does not have.",
                "Collect any student's name, photograph or individual record.",
                "Replace your judgement — every plan opens as an editable draft.",
              ].map((line) => (
                <li key={line} className="flex gap-2">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden />
                  <span>{line}</span>
                </li>
              ))}
            </ul>
          </div>
        </section>
      </main>

      <footer className="border-t border-line py-8">
        <div className="mx-auto flex max-w-app flex-wrap items-center justify-between gap-3 px-5 text-sm text-muted">
          <p>ChalkBox — Team HarshLabs · Omnikon National Hackathon 2026</p>
          <nav aria-label="Footer" className="flex gap-4">
            <Link to="/about" className="underline underline-offset-4">About</Link>
            <Link to="/privacy" className="underline underline-offset-4">Privacy &amp; AI</Link>
            <Link to="/demo" className="underline underline-offset-4">Demo</Link>
          </nav>
        </div>
      </footer>
    </div>
  );
}

function Feature({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return (
    <div className="card p-5">
      <span className="flex h-10 w-10 items-center justify-center rounded-field bg-primary-soft text-primary">
        {icon}
      </span>
      <h3 className="mt-3 font-display text-base font-semibold">{title}</h3>
      <p className="mt-1.5 text-sm text-muted">{body}</p>
    </div>
  );
}
