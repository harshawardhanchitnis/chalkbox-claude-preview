import { Link } from "react-router-dom";

export function PrivacyPage() {
  return (
    <div className="mx-auto max-w-read px-5 py-12">
      <Link to="/" className="text-sm text-muted underline underline-offset-4">← Back</Link>
      <h1 className="mt-4 font-display text-3xl font-bold tracking-tight">Privacy and responsible AI</h1>

      <h2 className="mt-8 font-display text-xl font-semibold">No student data. At all.</h2>
      <p className="mt-2 text-[15px] leading-relaxed">
        ChalkBox has no student accounts and no per-student records. After a
        lesson you may record how many students met, partly met or need more
        support. Those are counts. There is no field anywhere in the database
        for a student's name, and the schema enforces that the counts can never
        exceed the number of children present.
      </p>

      <h2 className="mt-8 font-display text-xl font-semibold">What is sent to the AI</h2>
      <p className="mt-2 text-[15px] leading-relaxed">
        When you generate a plan, ChalkBox sends the class, subject, topic,
        duration, language, class size, your materials list and the curriculum
        passages retrieved for that topic. It does not send your name, your
        school, your email, or anything about an individual child. Requests go
        through our server, so the AI provider never sees your account.
      </p>
      <p className="mt-2 text-[15px] leading-relaxed">
        We use Google's Gemini API on its free tier. Google states that free-tier
        requests may be used to improve their products, which is exactly why no
        personal or confidential information is ever included in a request.
      </p>

      <h2 className="mt-8 font-display text-xl font-semibold">Where your plans live</h2>
      <p className="mt-2 text-[15px] leading-relaxed">
        Plans are stored on your device so they open without a connection. If
        you have an account they also sync to our database, where row-level
        security means only you can read them. Demo Mode data never leaves your
        device and can be erased from Settings at any time.
      </p>

      <h2 className="mt-8 font-display text-xl font-semibold">Generated content is a draft</h2>
      <p className="mt-2 text-[15px] leading-relaxed">
        AI output can be wrong. ChalkBox runs automatic checks and shows you what
        it found, but the checks cannot judge whether a lesson is good. Read
        every plan before you teach it. Where a plan cites the curriculum you can
        open the exact passage it used; where it cites nothing, it is labelled
        ungrounded.
      </p>

      <h2 className="mt-8 font-display text-xl font-semibold">No tracking</h2>
      <p className="mt-2 text-[15px] leading-relaxed">
        There is no Google Analytics, no advertising pixel and no third-party
        behavioural tracking. Usage counts are computed from your own records,
        for your own dashboard.
      </p>
    </div>
  );
}
