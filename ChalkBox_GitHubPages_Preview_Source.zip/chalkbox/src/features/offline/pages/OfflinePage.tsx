import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { WifiOff } from "lucide-react";
import type { LessonPlan } from "@chalkbox/contracts";
import { useRepositories } from "@/hooks/use-repositories";
import { useConnectivity } from "@/hooks/use-connectivity";
import { PlanCard } from "@/features/plans/components/PlanCard";
import { Button, EmptyState, PageHeader, Skeleton } from "@/components/ui";

export function OfflinePage() {
  const repos = useRepositories();
  const online = useConnectivity();
  const [plans, setPlans] = useState<LessonPlan[] | null>(null);

  useEffect(() => {
    repos.plans.list({ offlineOnly: true }).then(setPlans);
  }, [repos]);

  return (
    <div className="mx-auto max-w-form px-5 py-10">
      <PageHeader
        title={online ? "Available offline" : "You are offline"}
        description={
          online
            ? "These plans are kept on this device and will open without a connection."
            : "These plans are on this device. You can open, edit, print and teach from them now."
        }
      />

      {plans === null && <Skeleton className="h-32" />}

      {plans?.length === 0 && (
        <EmptyState
          icon={<WifiOff className="h-8 w-8" />}
          title="No plans pinned yet"
          description="Open a plan and tap the offline icon to keep it on this device for a day with no signal."
          action={<Link to="/app/library" className="btn-primary">My plans</Link>}
        />
      )}

      {plans && plans.length > 0 && (
        <ul className="grid gap-3 sm:grid-cols-2">
          {plans.map((p) => <li key={p.id}><PlanCard plan={p} /></li>)}
        </ul>
      )}

      {online && (
        <Button variant="secondary" className="mt-6" onClick={() => window.location.reload()}>
          Reload
        </Button>
      )}
    </div>
  );
}
