import { useState } from "react";
import { AlertTriangle, CheckCircle2, Info } from "lucide-react";
import type { PlanReadiness } from "@chalkbox/contracts";
import { Badge } from "@/components/ui";

/**
 * What the automatic checks found.
 *
 * Shown to the teacher rather than hidden. A plan with remaining errors is
 * still displayed -- with the errors named -- because quietly swapping in
 * something that looks fine is exactly the failure mode we refuse.
 *
 * The score counts kept guarantees. It explicitly does not judge teaching
 * quality, and the wording says so.
 */
export function ReadinessPanel({
  readiness, grounding, passagesUsed, onJump,
}: {
  readiness: PlanReadiness;
  grounding: "grounded" | "partial" | "ungrounded";
  passagesUsed?: number;
  onJump?: (section: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const errors = readiness.issues.filter((i) => i.severity === "error");
  const warnings = readiness.issues.filter((i) => i.severity === "warning");
  const infos = readiness.issues.filter((i) => i.severity === "info");

  const tone = errors.length ? "danger" : warnings.length ? "warning" : "success";

  return (
    <section aria-label="Plan checks"
      className={`rounded-card border px-4 py-3 ${
        errors.length ? "border-danger/40 bg-danger/5"
        : warnings.length ? "border-warning/40 bg-warning/5"
        : "border-line bg-surface"
      }`}>
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
        <span className="flex items-baseline gap-1.5">
          <span className="font-display text-2xl font-bold tabular-nums">{readiness.score}%</span>
          <span className="text-sm text-muted">checks passed</span>
        </span>

        <Badge tone={grounding === "grounded" ? "info" : grounding === "partial" ? "accent" : "warning"}>
          {grounding === "grounded" ? "Curriculum cited"
            : grounding === "partial" ? "Partly cited" : "Not grounded"}
        </Badge>

        {passagesUsed !== undefined && passagesUsed > 0 && (
          <span className="text-xs text-muted">{passagesUsed} passages used</span>
        )}

        {readiness.issues.length > 0 && (
          <button onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            className={`ml-auto font-display text-sm font-semibold underline underline-offset-4 ${
              errors.length ? "text-danger" : "text-muted"
            }`}>
            {errors.length
              ? `${errors.length} problem${errors.length === 1 ? "" : "s"}`
              : `${warnings.length + infos.length} note${warnings.length + infos.length === 1 ? "" : "s"}`}
          </button>
        )}
        {readiness.issues.length === 0 && (
          <span className="ml-auto flex items-center gap-1 text-sm text-success">
            <CheckCircle2 className="h-4 w-4" aria-hidden /> All checks passed
          </span>
        )}
      </div>

      {open && (
        <ul className="mt-3 space-y-2 border-t border-line pt-3">
          {[...errors, ...warnings, ...infos].map((issue, i) => (
            <li key={i} className="flex gap-2">
              {issue.severity === "error"
                ? <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-danger" aria-hidden />
                : <Info className="mt-0.5 h-4 w-4 shrink-0 text-muted" aria-hidden />}
              <div className="min-w-0 flex-1">
                <p className="text-sm">{issue.message}</p>
                <p className="text-xs text-muted">{issue.suggestedAction}</p>
              </div>
              {onJump && (
                <button onClick={() => onJump(issue.section)}
                  className="shrink-0 text-xs underline underline-offset-2">
                  Go there
                </button>
              )}
            </li>
          ))}
          <li className="pt-1 text-xs italic text-muted">
            These checks confirm the plan keeps ChalkBox's own guarantees — timing,
            materials, one teacher at a time, real citations. They cannot tell you
            whether the lesson is good. Please read it before you teach it.
          </li>
        </ul>
      )}
      <span className="sr-only">Readiness {tone}</span>
    </section>
  );
}
