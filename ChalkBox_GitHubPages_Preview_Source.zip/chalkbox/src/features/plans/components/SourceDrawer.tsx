import type { SourceCitation } from "@chalkbox/contracts";
import { Modal, Badge } from "@/components/ui";

/** Every plan can be traced back to the passages it came from. */
export function SourceDrawer({
  open, onClose, citations, grounding,
}: {
  open: boolean; onClose: () => void;
  citations: SourceCitation[];
  grounding: "grounded" | "partial" | "ungrounded";
}) {
  return (
    <Modal open={open} onClose={onClose} title="Where this plan came from">
      {grounding === "ungrounded" ? (
        <div className="rounded-field border border-warning/40 bg-warning/5 px-3 py-3">
          <Badge tone="warning">Not grounded</Badge>
          <p className="mt-2 text-sm text-warning">
            No curriculum passage matched this topic, so the subject content came
            from the model's general knowledge rather than a checked source.
            Read it carefully before teaching.
          </p>
        </div>
      ) : (
        <ul className="space-y-3">
          {citations.map((c) => (
            <li key={c.id} className="border-l-2 border-primary pl-3">
              <p className="font-display text-sm font-semibold">{c.label}</p>
              {c.locator && <p className="text-xs text-muted">{c.locator}</p>}
              <p className="mt-1 text-sm italic text-muted">“{c.excerpt}”</p>
            </li>
          ))}
        </ul>
      )}
    </Modal>
  );
}
