import type { ConstraintPlan } from "@chalkbox/contracts";
import { cn } from "@/lib/utils";

/**
 * The lesson rail.
 *
 * The one view a general-purpose chatbot cannot produce, so the interface is
 * built around it. Time runs downward; each class gets a column. The fill says
 * where the single teacher is:
 *
 *   solid       teaching this class directly
 *   hatched     class works independently
 *   amber       whole room together on the shared anchor
 *
 * Read across any row and only one column is ever solid. That is the promise
 * of the product, drawn.
 */
const MIN_PX = 4.2;

export function LessonRail({
  constraint, language = "en", activeGrade,
}: { constraint: ConstraintPlan; language?: string; activeGrade?: number | null }) {
  const hi = language === "hi";
  const grades = constraint.grades;

  const label = (attention: string, shared: boolean) => {
    if (shared) return hi ? "सब साथ" : "All together";
    if (attention === "direct") return hi ? "आप यहाँ" : "You are here";
    if (attention === "circulating") return hi ? "घूमते हुए" : "Circulating";
    return hi ? "स्वयं" : "On their own";
  };

  return (
    <div className="card p-3">
      <div className="mb-3 flex items-baseline justify-between">
        <h3 className="font-display text-xs font-semibold uppercase tracking-wide text-muted">
          {hi ? "कालांश का नक़्शा" : "The period, minute by minute"}
        </h3>
        <span className="text-xs text-muted">{constraint.durationMinutes} min</span>
      </div>

      <div className="mb-1 grid gap-1 pl-10"
        style={{ gridTemplateColumns: `repeat(${grades.length}, minmax(0,1fr))` }}>
        {grades.map((g) => (
          <div key={g} className={cn(
            "border-b-2 pb-1 text-center font-display text-xs font-semibold",
            activeGrade === g ? "border-ink text-ink" : "border-line text-muted",
          )}>
            {hi ? `कक्षा ${g}` : `Class ${g}`}
          </div>
        ))}
      </div>

      {constraint.windows.map((w) => (
        <div key={w.startMinute} className="flex gap-1">
          <div className="w-9 shrink-0 pt-0.5 text-right">
            <span className="text-[11px] tabular-nums text-muted">{w.startMinute}′</span>
          </div>
          <div className="grid flex-1 gap-1 pb-1"
            style={{ gridTemplateColumns: `repeat(${grades.length}, minmax(0,1fr))` }}>
            {grades.map((g) => {
              const attention = w.attention[g];
              const dim = activeGrade != null && activeGrade !== g && !w.shared;
              return (
                <div key={g}
                  style={{ height: Math.max(34, w.durationMinutes * MIN_PX) }}
                  title={`${w.label} — ${label(attention, w.shared)}`}
                  className={cn(
                    "flex flex-col justify-center rounded-field border px-2 text-left",
                    w.shared && "border-accent bg-accent/20 text-ink",
                    !w.shared && attention === "direct" && "border-primary bg-primary text-white",
                    !w.shared && attention === "circulating" && "border-line bg-primary-soft text-ink",
                    !w.shared && attention === "independent" && "chalk-hatch border-line text-muted",
                    dim && "opacity-40",
                  )}>
                  <span className="text-[11px] leading-tight">{label(attention, w.shared)}</span>
                  {w.durationMinutes >= 6 && (
                    <span className="text-[10px] leading-tight opacity-75">{w.durationMinutes} min</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      ))}

      <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 border-t border-line pt-2">
        <Legend className="bg-primary" label={label("direct", false)} />
        <Legend className="chalk-hatch border border-line" label={label("independent", false)} />
        <Legend className="border border-accent bg-accent/30" label={label("direct", true)} />
      </div>

      {constraint.warnings.length > 0 && (
        <div className="mt-2 rounded-field border border-warning/40 bg-warning/5 px-2 py-1.5">
          {constraint.warnings.map((warning, i) => (
            <p key={i} className="text-[11px] leading-snug text-warning">{warning}</p>
          ))}
        </div>
      )}
    </div>
  );
}

function Legend({ className, label }: { className: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className={cn("inline-block h-3 w-3 rounded-sm", className)} aria-hidden />
      <span className="text-[11px] text-muted">{label}</span>
    </span>
  );
}
