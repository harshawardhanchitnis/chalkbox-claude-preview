import { useEffect, useRef, useState } from "react";
import { Mic, Square } from "lucide-react";
import { Button } from "@/components/ui";

/**
 * Voice dictation.
 *
 * Uses the browser's own speech recognition, which handles hi-IN in Chrome on
 * Android with no key, no cost and no server round trip. Typing always remains
 * available; if the API is missing the button simply does not render.
 */
export function VoiceInput({
  language, onResult,
}: { language: "en" | "hi" | "en-hi"; onResult: (text: string) => void }) {
  const [listening, setListening] = useState(false);
  const [supported, setSupported] = useState(true);
  const recognition = useRef<{ start(): void; stop(): void; abort?(): void } | null>(null);

  useEffect(() => {
    const w = window as unknown as { SpeechRecognition?: new () => never; webkitSpeechRecognition?: new () => never };
    const SR = w.SpeechRecognition ?? w.webkitSpeechRecognition;
    if (!SR) { setSupported(false); return; }
    const r = new SR() as unknown as {
      lang: string; interimResults: boolean; maxAlternatives: number;
      onresult: (e: { results: Array<Array<{ transcript: string }>> }) => void;
      onend: () => void; onerror: () => void;
      start(): void; stop(): void; abort(): void;
    };
    r.lang = language === "en" ? "en-IN" : "hi-IN";
    r.interimResults = false;
    r.maxAlternatives = 1;
    r.onresult = (e) => onResult(e.results[0][0].transcript);
    r.onend = () => setListening(false);
    r.onerror = () => setListening(false);
    recognition.current = r;
    return () => r.abort?.();
  }, [language, onResult]);

  if (!supported) return null;

  return (
    <Button
      type="button"
      variant={listening ? "danger" : "secondary"}
      aria-pressed={listening}
      aria-label={listening ? "Stop listening" : "Speak instead of typing"}
      onClick={() => {
        if (listening) { recognition.current?.stop(); return; }
        setListening(true);
        recognition.current?.start();
      }}
    >
      {listening ? <Square className="h-4 w-4" aria-hidden /> : <Mic className="h-4 w-4" aria-hidden />}
      <span className="hidden sm:inline">{listening ? "Listening…" : "Speak"}</span>
    </Button>
  );
}
