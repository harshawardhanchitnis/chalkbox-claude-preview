import { Link } from "react-router-dom";
import { Star, WifiOff } from "lucide-react";
import type { LessonPlan } from "@chalkbox/contracts";
import { Badge } from "@/components/ui";

const STATUS_TONE = {
  draft: "neutral", ready: "success", taught: "info", archived: "neutral",
} as const;

export function PlanCard({ plan, isDemo }: { plan: LessonPlan; isDemo?: boolean }) {
  const multi = plan.brief.grades.length > 1;
  return (
    <Link
      to={`/app/plans/${plan.id}`}
      className="card block h-full p-4 transition hover:border-primary hover:shadow-lift"
    >
      <div className="flex items-start gap-3">
        <div className="flex w-12 shrink-0 flex-col items-center rounded-field bg-primary py-1.5 text-white">
          <span className="font-display text-sm font-bold leading-none">
            {plan.brief.grades.join("·")}
          </span>
          <span className="mt-0.5 text-[10px] leading-none opacity-80">
            {plan.brief.durationMinutes}m
          </span>
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="line-clamp-2 font-display text-[15px] font-semibold leading-snug">
            {plan.title}
          </h3>
          <p className="mt-1 truncate text-xs text-muted">
            {plan.brief.topic}
            {multi && " · multigrade"}
          </p>
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            <Badge tone={STATUS_TONE[plan.status]}>{plan.status}</Badge>
            {plan.groundingLevel === "grounded" && <Badge tone="info">cited</Badge>}
            {plan.groundingLevel === "ungrounded" && <Badge tone="warning">ungrounded</Badge>}
            {isDemo && <Badge tone="accent">Demo</Badge>}
            {plan.isPinnedOffline && (
              <span title="Available offline"><WifiOff className="h-3.5 w-3.5 text-muted" aria-label="Available offline" /></span>
            )}
            {plan.isFavourite && (
              <Star className="h-3.5 w-3.5 fill-accent text-accent" aria-label="Favourite" />
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}
