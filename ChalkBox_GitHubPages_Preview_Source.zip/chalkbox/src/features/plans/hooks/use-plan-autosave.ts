import { useCallback, useEffect, useRef, useState } from "react";
import type { LessonPlan } from "@chalkbox/contracts";
import { useRepositories } from "@/hooks/use-repositories";

export type SaveState = "idle" | "saving" | "saved" | "queued" | "error";

/**
 * Debounced autosave.
 *
 * Saves through the repository, which writes to IndexedDB immediately and
 * queues a server mutation when a backend exists. A teacher editing on a bus
 * with no signal sees "saved on this device", not an error.
 */
export function usePlanAutosave(planId: string | undefined, delay = 900) {
  const repos = useRepositories();
  const [state, setState] = useState<SaveState>("idle");
  const [lastSavedAt, setLastSavedAt] = useState<Date | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pending = useRef<LessonPlan | null>(null);

  const flush = useCallback(async () => {
    if (!planId || !pending.current) return;
    const plan = pending.current;
    pending.current = null;
    setState("saving");
    try {
      await repos.plans.update(planId, plan);
      setState(navigator.onLine ? "saved" : "queued");
      setLastSavedAt(new Date());
    } catch {
      setState("error");
    }
  }, [planId, repos]);

  const save = useCallback((plan: LessonPlan) => {
    pending.current = plan;
    setState("saving");
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => { void flush(); }, delay);
  }, [flush, delay]);

  // Never lose an in-flight edit when the tab closes.
  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current);
    void flush();
  }, [flush]);

  return { save, flushNow: flush, state, lastSavedAt, hasPending: () => pending.current !== null };
}
