import { describe, expect, it } from "vitest";
import { buildConstraintPlan, evaluateReadiness } from "@chalkbox/contracts";
import { buildDemoPlans } from "@/data/demo/fixtures";

/**
 * The demo fixtures must pass the same checks a live generated plan does.
 * If a fixture ever drifts into failing its own validator, the demo would be
 * showing a teacher something ChalkBox would have rejected.
 */
describe("demo fixtures", () => {
  const plans = buildDemoPlans();

  it("produces the expected number of sample plans", () => {
    expect(plans.length).toBeGreaterThanOrEqual(8);
  });

  it("gives every fixture a timeline that fills its period exactly", () => {
    for (const plan of plans) {
      const total = plan.content.timeline.reduce((s, x) => s + x.durationMinutes, 0);
      expect(total, plan.title).toBe(plan.brief.durationMinutes);
    }
  });

  it("passes readiness with no blocking errors", () => {
    for (const plan of plans) {
      const constraint = buildConstraintPlan(plan.brief.durationMinutes, plan.brief.grades);
      const readiness = evaluateReadiness({
        content: plan.content, constraint, brief: plan.brief,
        suppliedChunkIds: plan.content.citations.map((c) => c.chunkId),
      });
      const errors = readiness.issues.filter((i) => i.severity === "error");
      expect(errors, `${plan.title}: ${JSON.stringify(errors)}`).toHaveLength(0);
    }
  });

  it("gives every multigrade fixture an anchor and a track per class", () => {
    for (const plan of plans.filter((p) => p.brief.grades.length > 1)) {
      const mg = plan.content.differentiation.multigrade;
      expect(mg, plan.title).toBeDefined();
      expect(mg!.anchorActivity.length).toBeGreaterThan(20);
      expect(mg!.tracks.map((t) => t.grade).sort()).toEqual([...plan.brief.grades].sort());
    }
  });

  it("marks ungrounded fixtures honestly rather than faking citations", () => {
    for (const plan of plans) {
      if (plan.groundingLevel === "ungrounded") {
        expect(plan.content.citations, plan.title).toHaveLength(0);
      } else {
        expect(plan.content.citations.length, plan.title).toBeGreaterThan(0);
      }
    }
  });

  it("never uses equipment a low-resource classroom lacks", () => {
    const banned = ["projector", "computer", "printer", "photocopy", "laboratory"];
    for (const plan of plans) {
      for (const m of plan.content.materials) {
        expect(banned.some((b) => m.name.toLowerCase().includes(b)), `${plan.title}: ${m.name}`).toBe(false);
      }
    }
  });
});
