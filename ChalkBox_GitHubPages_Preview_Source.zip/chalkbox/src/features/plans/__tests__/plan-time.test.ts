import { describe, expect, it } from "vitest";
import type { LessonStep } from "@chalkbox/contracts";
import {
  addStep, moveStep, rebalance, remainingMinutes, removeStep,
  resequence, setStepDuration, totalDuration,
} from "../plan-time";

function step(id: string, order: number, minutes: number): LessonStep {
  return {
    id, order, kind: "activity", title: id, startMinute: 0,
    durationMinutes: minutes, gradeFocus: [6], attention: "direct",
    teacherActions: ["a"], studentActions: ["b"],
    materialIds: [], objectiveIds: [],
  };
}

const base = [step("s1", 0, 5), step("s2", 1, 12), step("s3", 2, 10), step("s4", 3, 8), step("s5", 4, 5)];

describe("timeline arithmetic", () => {
  it("lays steps end to end with no gaps", () => {
    const out = resequence(base);
    expect(out.map((s) => s.startMinute)).toEqual([0, 5, 17, 27, 35]);
    expect(totalDuration(out)).toBe(40);
  });

  it("reflows every later step when one duration changes", () => {
    const out = setStepDuration(base, "s2", 20);
    expect(out.find((s) => s.id === "s3")!.startMinute).toBe(25);
    expect(totalDuration(out)).toBe(48);
  });

  it("reports how many minutes are still unplanned", () => {
    expect(remainingMinutes(base, 40)).toBe(0);
    expect(remainingMinutes(setStepDuration(base, "s1", 10), 40)).toBe(-5);
  });

  it("rebalances back to exactly the period length", () => {
    const over = setStepDuration(base, "s2", 25);
    const fixed = rebalance(over, 40);
    expect(totalDuration(fixed)).toBe(40);
    expect(fixed.every((s) => s.durationMinutes >= 1)).toBe(true);
  });

  it("rebalances upward when the lesson is short", () => {
    const short = removeStep(base, "s2");
    expect(totalDuration(rebalance(short, 40))).toBe(40);
  });

  it("moves a step and keeps the timeline contiguous", () => {
    const moved = moveStep(base, "s3", -1);
    expect(moved.map((s) => s.id)).toEqual(["s1", "s3", "s2", "s4", "s5"]);
    expect(moved[1].startMinute).toBe(5);
    expect(totalDuration(moved)).toBe(40);
  });

  it("refuses to move the first step earlier", () => {
    expect(moveStep(base, "s1", -1).map((s) => s.id)).toEqual(base.map((s) => s.id));
  });

  it("adds a step after the chosen one and renumbers", () => {
    const out = addStep(base, "s2");
    expect(out).toHaveLength(6);
    expect(out[2].order).toBe(2);
    expect(out.map((s) => s.startMinute)).toEqual([0, 5, 17, 22, 32, 40]);
  });

  it("never allows a step below one minute when shrinking", () => {
    const out = rebalance([step("a", 0, 3), step("b", 1, 3)], 2);
    expect(out.every((s) => s.durationMinutes >= 1)).toBe(true);
  });
});
