import type { LessonPlanContent, LessonStep } from "@chalkbox/contracts";

/**
 * Timeline arithmetic.
 *
 * A lesson ends when the bell rings. Every edit that changes a duration
 * re-flows the steps that follow, so the timeline always adds up to exactly
 * the period length and a teacher never has to do the sums.
 */

export function resequence(steps: LessonStep[]): LessonStep[] {
  let cursor = 0;
  return [...steps]
    .sort((a, b) => a.order - b.order)
    .map((step, i) => {
      const next = { ...step, order: i, startMinute: cursor };
      cursor += step.durationMinutes;
      return next;
    });
}

export function totalDuration(steps: LessonStep[]): number {
  return steps.reduce((sum, s) => sum + s.durationMinutes, 0);
}

export function remainingMinutes(steps: LessonStep[], target: number): number {
  return target - totalDuration(steps);
}

export function setStepDuration(
  steps: LessonStep[], stepId: string, minutes: number,
): LessonStep[] {
  const safe = Math.max(1, Math.min(90, Math.round(minutes)));
  return resequence(steps.map((s) => (s.id === stepId ? { ...s, durationMinutes: safe } : s)));
}

export function moveStep(steps: LessonStep[], stepId: string, direction: -1 | 1): LessonStep[] {
  const ordered = [...steps].sort((a, b) => a.order - b.order);
  const index = ordered.findIndex((s) => s.id === stepId);
  const target = index + direction;
  if (index === -1 || target < 0 || target >= ordered.length) return steps;
  [ordered[index], ordered[target]] = [ordered[target], ordered[index]];
  return resequence(ordered.map((s, i) => ({ ...s, order: i })));
}

export function removeStep(steps: LessonStep[], stepId: string): LessonStep[] {
  return resequence(steps.filter((s) => s.id !== stepId));
}

export function addStep(steps: LessonStep[], afterId: string | null, template: Partial<LessonStep> = {}): LessonStep[] {
  const ordered = [...steps].sort((a, b) => a.order - b.order);
  const index = afterId ? ordered.findIndex((s) => s.id === afterId) : ordered.length - 1;
  const gradeFocus = ordered[0]?.gradeFocus ?? [];
  const step: LessonStep = {
    id: `s_${crypto.randomUUID().slice(0, 8)}`,
    order: 0, kind: "activity", title: "New step",
    startMinute: 0, durationMinutes: 5,
    gradeFocus, attention: "direct",
    teacherActions: ["Describe what you will do."],
    studentActions: ["Describe what students will do."],
    materialIds: [], objectiveIds: [],
    ...template,
  };
  ordered.splice(index + 1, 0, step);
  return resequence(ordered.map((s, i) => ({ ...s, order: i })));
}

/**
 * Absorb a duration change into the rest of the lesson so the total is kept.
 * Used when the teacher lengthens one step and expects the period to still fit.
 */
export function rebalance(steps: LessonStep[], target: number): LessonStep[] {
  const ordered = resequence(steps);
  let drift = target - totalDuration(ordered);
  if (drift === 0) return ordered;

  // Take from (or give to) the longest steps first, never below one minute.
  const byLength = [...ordered].sort((a, b) => b.durationMinutes - a.durationMinutes);
  for (const step of byLength) {
    if (drift === 0) break;
    if (drift < 0) {
      const canTake = Math.min(step.durationMinutes - 1, -drift);
      step.durationMinutes -= canTake;
      drift += canTake;
    } else {
      step.durationMinutes += drift;
      drift = 0;
    }
  }
  return resequence(ordered);
}

export function withTimeline(content: LessonPlanContent, timeline: LessonStep[]): LessonPlanContent {
  return { ...content, timeline: resequence(timeline) };
}
