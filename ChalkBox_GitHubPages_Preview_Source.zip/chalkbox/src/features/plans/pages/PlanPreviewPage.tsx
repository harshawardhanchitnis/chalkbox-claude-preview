import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Printer } from "lucide-react";
import type { LessonPlan } from "@chalkbox/contracts";
import { useRepositories } from "@/hooks/use-repositories";
import { Button, EmptyState, PlanSkeleton } from "@/components/ui";
import { PrintablePlan } from "@/features/export/PrintablePlan";

export function PlanPreviewPage() {
  const { planId } = useParams();
  const repos = useRepositories();
  const [plan, setPlan] = useState<LessonPlan | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!planId) return;
    repos.plans.get(planId).then((p) => { setPlan(p); setLoading(false); });
  }, [planId, repos]);

  if (loading) return <PlanSkeleton />;
  if (!plan) return <EmptyState title="Plan not found" action={<Link to="/app/library" className="btn-primary">My plans</Link>} />;

  return (
    <div className="mx-auto max-w-read">
      <div className="no-print mb-5 flex items-center justify-between">
        <Link to={`/app/plans/${plan.id}`} className="text-sm text-muted underline underline-offset-4">
          ← Back to editing
        </Link>
        <Button onClick={async () => {
          await repos.analytics.record("plan_exported", plan.id);
          window.print();
        }}>
          <Printer className="h-4 w-4" aria-hidden /> Print or save as PDF
        </Button>
      </div>

      <div className="no-print mb-4 rounded-card border border-line bg-surface px-4 py-3 text-sm text-muted">
        Use your browser's print dialog and choose “Save as PDF”. This keeps
        Hindi text rendering correctly and works with no internet.
      </div>

      <div className="card p-6 print:border-0 print:p-0 print:shadow-none">
        <PrintablePlan plan={plan} watermark={plan.status === "draft" ? "DRAFT" : undefined} />
      </div>
    </div>
  );
}
