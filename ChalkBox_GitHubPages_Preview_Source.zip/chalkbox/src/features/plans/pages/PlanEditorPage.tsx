import { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { toast } from "sonner";
import {
  ArrowDown, ArrowUp, BookMarked, Check, Cloud, CloudOff, Copy, Loader2,
  Play, Plus, Printer, Share2, Star, Trash2, WifiOff,
} from "lucide-react";
import {
  buildConstraintPlan, evaluateReadiness,
  type LessonPlan, type LessonStep,
} from "@chalkbox/contracts";
import { useRepositories, useIsDemo } from "@/hooks/use-repositories";
import { useUnsavedWarning } from "@/hooks/use-unsaved-warning";
import { usePlanAutosave } from "../hooks/use-plan-autosave";
import {
  addStep, moveStep, rebalance, remainingMinutes, removeStep,
  setStepDuration, totalDuration,
} from "../plan-time";
import { LessonRail } from "../components/LessonRail";
import { ReadinessPanel } from "../components/ReadinessPanel";
import { SourceDrawer } from "../components/SourceDrawer";
import { SharePlanDialog } from "@/features/sharing/components/SharePlanDialog";
import {
  Badge, Button, Card, EmptyState, Input, Modal, PlanSkeleton, Textarea,
} from "@/components/ui";
import { cn } from "@/lib/utils";

export function PlanEditorPage() {
  const { planId } = useParams();
  const repos = useRepositories();
  const isDemo = useIsDemo();
  const [plan, setPlan] = useState<LessonPlan | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeGrade, setActiveGrade] = useState<number | null>(null);
  const [sourcesOpen, setSourcesOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const autosave = usePlanAutosave(planId);
  useUnsavedWarning(autosave.state === "saving");

  useEffect(() => {
    if (!planId) return;
    let cancelled = false;
    repos.plans.get(planId).then((p) => {
      if (cancelled) return;
      setPlan(p);
      setActiveGrade(p?.brief.grades[0] ?? null);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [planId, repos]);

  const constraint = useMemo(() => {
    if (!plan) return null;
    try { return buildConstraintPlan(plan.brief.durationMinutes, plan.brief.grades); }
    catch { return null; }
  }, [plan]);

  /**
   * Every mutation re-runs the readiness checks, so the panel is always telling
   * the truth about the plan as it stands right now, not as it was generated.
   */
  const mutate = useCallback((next: LessonPlan) => {
    if (!constraint) { setPlan(next); autosave.save(next); return; }
    const readiness = evaluateReadiness({
      content: next.content, constraint, brief: next.brief,
      suppliedChunkIds: next.content.citations.map((c) => c.chunkId),
    });
    const withChecks = { ...next, readiness };
    setPlan(withChecks);
    autosave.save(withChecks);
  }, [constraint, autosave]);

  const updateTimeline = useCallback((timeline: LessonStep[]) => {
    if (!plan) return;
    mutate({ ...plan, content: { ...plan.content, timeline } });
  }, [plan, mutate]);

  if (loading) return <PlanSkeleton />;
  if (!plan) {
    return (
      <EmptyState
        title="That plan is not on this device"
        description="It may have been deleted, or belong to another account."
        action={<Link to="/app/library" className="btn-primary">Back to my plans</Link>}
      />
    );
  }

  const timeline = plan.content.timeline;
  const used = totalDuration(timeline);
  const remaining = remainingMinutes(timeline, plan.brief.durationMinutes);
  const multi = plan.brief.grades.length > 1;
  const track = plan.content.differentiation.multigrade?.tracks.find((t) => t.grade === activeGrade);

  return (
    <div className="mx-auto max-w-editor">
      {/* Header */}
      <div className="no-print mb-4">
        <Link to="/app/library" className="text-sm text-muted underline underline-offset-4">
          ← My plans
        </Link>
      </div>

      <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <Input
            aria-label="Lesson title"
            value={plan.title}
            onChange={(e) => mutate({ ...plan, title: e.target.value })}
            className="border-transparent bg-transparent px-0 font-display text-2xl font-bold focus:border-line focus:px-3"
          />
          <p className="mt-1 text-sm text-muted">
            {multi ? `Classes ${plan.brief.grades.join(", ")}` : `Class ${plan.brief.grades[0]}`}
            {" · "}{plan.brief.durationMinutes} min
            {" · "}{plan.brief.topic}
            {isDemo && <Badge tone="accent" className="ml-2">Demo data</Badge>}
          </p>
        </div>

        <div className="no-print flex flex-wrap gap-2">
          <SaveIndicator state={autosave.state} />
          <Button variant="ghost" size="sm" aria-label={plan.isFavourite ? "Remove from favourites" : "Add to favourites"}
            onClick={async () => {
              await repos.plans.setFavourite(plan.id, !plan.isFavourite);
              setPlan({ ...plan, isFavourite: !plan.isFavourite });
            }}>
            <Star className={cn("h-4 w-4", plan.isFavourite && "fill-accent text-accent")} aria-hidden />
          </Button>
          <Button variant="ghost" size="sm"
            aria-label={plan.isPinnedOffline ? "Unpin from offline" : "Keep available offline"}
            onClick={async () => {
              await repos.plans.setPinnedOffline(plan.id, !plan.isPinnedOffline);
              setPlan({ ...plan, isPinnedOffline: !plan.isPinnedOffline });
              toast.success(plan.isPinnedOffline ? "Unpinned" : "Pinned — this plan opens without internet");
            }}>
            <WifiOff className={cn("h-4 w-4", plan.isPinnedOffline && "text-primary")} aria-hidden />
          </Button>
          <Button variant="secondary" size="sm" onClick={() => setSourcesOpen(true)}>
            <BookMarked className="h-4 w-4" aria-hidden />
            <span className="hidden sm:inline">Sources</span>
          </Button>
          <Button variant="secondary" size="sm" onClick={() => setShareOpen(true)}>
            <Share2 className="h-4 w-4" aria-hidden />
            <span className="hidden sm:inline">Share</span>
          </Button>
          <Link to={`/app/plans/${plan.id}/preview`} className="btn-secondary btn-sm">
            <Printer className="h-4 w-4" aria-hidden />
            <span className="hidden sm:inline">Print</span>
          </Link>
          <Link to={`/app/plans/${plan.id}/teach`} className="btn-primary btn-sm">
            <Play className="h-4 w-4" aria-hidden /> Teach
          </Link>
        </div>
      </div>

      <div className="mb-5">
        <ReadinessPanel
          readiness={plan.readiness}
          grounding={plan.groundingLevel}
          passagesUsed={plan.content.citations.length}
          onJump={(section) => document.getElementById(`section-${section}`)?.scrollIntoView({ behavior: "smooth" })}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
        <div className="min-w-0 space-y-6">
          {/* Overview */}
          <Section id="overview" title="Overview">
            <Textarea rows={3} value={plan.content.overview}
              onChange={(e) => mutate({ ...plan, content: { ...plan.content, overview: e.target.value } })} />
          </Section>

          {/* Objectives */}
          <Section id="objectives" title="What this lesson should achieve">
            <ul className="space-y-2">
              {plan.content.objectives.map((o, i) => (
                <li key={o.id} className="flex gap-2">
                  <span className="mt-2.5 text-xs text-muted">{i + 1}.</span>
                  <Input value={o.statement}
                    onChange={(e) => mutate({
                      ...plan,
                      content: {
                        ...plan.content,
                        objectives: plan.content.objectives.map((x) =>
                          x.id === o.id ? { ...x, statement: e.target.value } : x),
                      },
                    })} />
                </li>
              ))}
            </ul>
          </Section>

          {/* Anchor */}
          {plan.content.differentiation.multigrade && (
            <Section id="differentiation" title="Shared anchor activity"
              hint="One activity, one context, every class together. The difference is the depth of question you ask.">
              <Textarea rows={3}
                value={plan.content.differentiation.multigrade.anchorActivity}
                onChange={(e) => mutate({
                  ...plan,
                  content: {
                    ...plan.content,
                    differentiation: {
                      ...plan.content.differentiation,
                      multigrade: { ...plan.content.differentiation.multigrade!, anchorActivity: e.target.value },
                    },
                  },
                })} />
            </Section>
          )}

          {/* Timeline */}
          <Section id="timeline"
            title="The lesson, step by step"
            hint={
              remaining === 0
                ? `${used} of ${plan.brief.durationMinutes} minutes — exactly right.`
                : remaining > 0
                  ? `${remaining} minutes still unplanned.`
                  : `${Math.abs(remaining)} minutes over the period.`
            }
            action={
              <div className="flex gap-2">
                {remaining !== 0 && (
                  <Button variant="secondary" size="sm"
                    onClick={() => updateTimeline(rebalance(timeline, plan.brief.durationMinutes))}>
                    Fit to {plan.brief.durationMinutes} min
                  </Button>
                )}
                <Button variant="secondary" size="sm"
                  onClick={() => updateTimeline(addStep(timeline, timeline[timeline.length - 1]?.id ?? null))}>
                  <Plus className="h-4 w-4" aria-hidden /> Add step
                </Button>
              </div>
            }>
            <div className={cn(
              "mb-3 h-2 overflow-hidden rounded-full bg-line",
              remaining < 0 && "bg-danger/20",
            )}>
              <div className={cn("h-full rounded-full transition-all",
                remaining === 0 ? "bg-success" : remaining > 0 ? "bg-primary" : "bg-danger")}
                style={{ width: `${Math.min(100, (used / plan.brief.durationMinutes) * 100)}%` }}
                role="progressbar" aria-valuenow={used} aria-valuemin={0}
                aria-valuemax={plan.brief.durationMinutes}
                aria-label="Minutes planned" />
            </div>

            <ul className="space-y-3">
              {timeline.map((step, i) => (
                <li key={step.id}>
                  <StepCard
                    step={step} index={i} isLast={i === timeline.length - 1}
                    onChange={(next) => updateTimeline(timeline.map((s) => (s.id === step.id ? next : s)))}
                    onDuration={(mins) => updateTimeline(setStepDuration(timeline, step.id, mins))}
                    onMove={(dir) => updateTimeline(moveStep(timeline, step.id, dir))}
                    onRemove={() => updateTimeline(removeStep(timeline, step.id))}
                  />
                </li>
              ))}
            </ul>
          </Section>

          {/* Assessment */}
          <Section id="assessment" title="Checking understanding">
            {plan.content.assessment.exitTicket.length === 0 &&
             plan.content.assessment.questionBank.length === 0 ? (
              <p className="text-sm text-muted">No questions in this plan yet.</p>
            ) : (
              <ol className="space-y-3">
                {[...plan.content.assessment.exitTicket, ...plan.content.assessment.questionBank].map((q, i) => (
                  <li key={q.id} className="rounded-field border border-line p-3">
                    <p className="text-sm font-medium">{i + 1}. {q.prompt}</p>
                    <p className="mt-1 text-sm text-muted">→ {q.correctAnswer}</p>
                    <Badge tone="neutral" className="mt-2">{q.difficulty}</Badge>
                  </li>
                ))}
              </ol>
            )}
          </Section>

          {/* Homework + safety */}
          {plan.content.homeworkOrExtension.length > 0 && (
            <Section id="homeworkOrExtension" title="Homework">
              <ul className="list-inside list-disc space-y-1 text-[15px]">
                {plan.content.homeworkOrExtension.map((h, i) => <li key={i}>{h}</li>)}
              </ul>
            </Section>
          )}
          {plan.content.safetyNotes.length > 0 && (
            <Section id="safety" title="Safety">
              <ul className="space-y-1">
                {plan.content.safetyNotes.map((s, i) => (
                  <li key={i} className="rounded-field border border-warning/40 bg-warning/5 px-3 py-2 text-sm text-warning">
                    {s}
                  </li>
                ))}
              </ul>
            </Section>
          )}
        </div>

        {/* Contextual panel */}
        <aside className="no-print space-y-4 lg:sticky lg:top-6 lg:self-start">
          {constraint && (
            <>
              {multi && (
                <div className="flex flex-wrap gap-2">
                  {plan.brief.grades.map((g) => (
                    <button key={g} onClick={() => setActiveGrade(g)}
                      className={activeGrade === g ? "chip-on" : "chip-off"}>
                      Class {g}
                    </button>
                  ))}
                </div>
              )}
              <LessonRail constraint={constraint} language={plan.brief.outputLanguage}
                activeGrade={activeGrade} />
            </>
          )}

          {track && (
            <Card className="p-4">
              <h3 className="font-display text-sm font-semibold">Class {track.grade} works on</h3>
              <ul className="mt-2 list-inside list-disc space-y-1 text-sm">
                {track.independentTasks.map((t, i) => <li key={i}>{t}</li>)}
              </ul>
              {track.assessmentPrompt && (
                <p className="mt-2 text-sm text-muted">Check: {track.assessmentPrompt}</p>
              )}
            </Card>
          )}

          <Card className="p-4">
            <h3 className="font-display text-sm font-semibold">Materials</h3>
            <ul className="mt-2 space-y-1 text-sm">
              {plan.content.materials.map((m) => (
                <li key={m.id} className="flex items-center justify-between gap-2">
                  <span>{m.name}</span>
                  <Badge tone={m.source === "household" ? "neutral" : "info"}>{m.source}</Badge>
                </li>
              ))}
            </ul>
          </Card>

          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" size="sm" onClick={async () => {
              const copy = await repos.plans.duplicate(plan.id);
              toast.success("Duplicated");
              window.location.href = `/app/plans/${copy.id}`;
            }}>
              <Copy className="h-4 w-4" aria-hidden /> Duplicate
            </Button>
            <Button variant="secondary" size="sm" onClick={async () => {
              await repos.plans.archive(plan.id, plan.status !== "archived");
              toast.success(plan.status === "archived" ? "Restored" : "Archived");
              setPlan({ ...plan, status: plan.status === "archived" ? "ready" : "archived" });
            }}>
              {plan.status === "archived" ? "Restore" : "Archive"}
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setConfirmDelete(true)}>
              <Trash2 className="h-4 w-4" aria-hidden /> Delete
            </Button>
          </div>
        </aside>
      </div>

      <SourceDrawer open={sourcesOpen} onClose={() => setSourcesOpen(false)}
        citations={plan.content.citations} grounding={plan.groundingLevel} />
      <SharePlanDialog open={shareOpen} onClose={() => setShareOpen(false)} planId={plan.id} />

      <Modal open={confirmDelete} onClose={() => setConfirmDelete(false)}
        title="Delete this plan?"
        description="This removes it from this device. It cannot be undone."
        footer={
          <>
            <Button variant="secondary" onClick={() => setConfirmDelete(false)}>Keep it</Button>
            <Button variant="danger" onClick={async () => {
              await repos.plans.remove(plan.id);
              window.location.href = "/app/library";
            }}>Delete</Button>
          </>
        } />
    </div>
  );
}

function Section({
  id, title, hint, action, children,
}: { id: string; title: string; hint?: string; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <section id={`section-${id}`} aria-labelledby={`h-${id}`}>
      <div className="mb-2 flex flex-wrap items-end justify-between gap-2">
        <div>
          <h2 id={`h-${id}`} className="font-display text-base font-semibold">{title}</h2>
          {hint && <p className="text-sm text-muted">{hint}</p>}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

function StepCard({
  step, index, isLast, onChange, onDuration, onMove, onRemove,
}: {
  step: LessonStep; index: number; isLast: boolean;
  onChange: (s: LessonStep) => void;
  onDuration: (m: number) => void;
  onMove: (d: -1 | 1) => void;
  onRemove: () => void;
}) {
  return (
    <Card className="overflow-hidden">
      <div className="flex flex-wrap items-center gap-2 border-b border-line bg-canvas px-3 py-2">
        <span className="font-display text-sm font-bold tabular-nums">
          {step.startMinute}–{step.startMinute + step.durationMinutes}′
        </span>
        <Badge tone="neutral">{step.kind.replace("-", " ")}</Badge>
        {step.attention === "independent" && <Badge tone="warning">without you</Badge>}
        {step.gradeFocus.length > 0 && (
          <Badge tone="info">Class {step.gradeFocus.join(", ")}</Badge>
        )}
        <div className="ml-auto flex items-center gap-1">
          <label className="sr-only" htmlFor={`dur-${step.id}`}>Minutes for {step.title}</label>
          <input id={`dur-${step.id}`} type="number" min={1} max={90}
            value={step.durationMinutes}
            onChange={(e) => onDuration(Number(e.target.value))}
            className="w-16 rounded border border-line bg-surface px-2 py-1 text-sm tabular-nums" />
          <Button variant="ghost" size="sm" aria-label="Move step earlier"
            disabled={index === 0} onClick={() => onMove(-1)}>
            <ArrowUp className="h-4 w-4" aria-hidden />
          </Button>
          <Button variant="ghost" size="sm" aria-label="Move step later"
            disabled={isLast} onClick={() => onMove(1)}>
            <ArrowDown className="h-4 w-4" aria-hidden />
          </Button>
          <Button variant="ghost" size="sm" aria-label="Remove step" onClick={onRemove}>
            <Trash2 className="h-4 w-4" aria-hidden />
          </Button>
        </div>
      </div>

      <div className="space-y-3 px-3 py-3">
        <Input aria-label="Step title" value={step.title}
          onChange={(e) => onChange({ ...step, title: e.target.value })}
          className="font-display font-semibold" />
        <EditableList label="You do" items={step.teacherActions}
          onChange={(teacherActions) => onChange({ ...step, teacherActions })} />
        <EditableList label="Students do" items={step.studentActions}
          onChange={(studentActions) => onChange({ ...step, studentActions })} />
        {step.boardPrompt !== undefined && (
          <div>
            <p className="mb-1 font-display text-[11px] uppercase tracking-wide text-muted">On the blackboard</p>
            <Textarea rows={2} value={step.boardPrompt ?? ""}
              onChange={(e) => onChange({ ...step, boardPrompt: e.target.value })} />
          </div>
        )}
        {step.checkForUnderstanding && (
          <p className="text-sm text-muted">Check: {step.checkForUnderstanding}</p>
        )}
      </div>
    </Card>
  );
}

function EditableList({
  label, items, onChange,
}: { label: string; items: string[]; onChange: (items: string[]) => void }) {
  return (
    <div>
      <p className="mb-1 font-display text-[11px] uppercase tracking-wide text-muted">{label}</p>
      <ul className="space-y-1.5">
        {items.map((item, i) => (
          <li key={i} className="flex gap-2">
            <Textarea rows={2} value={item} aria-label={`${label} line ${i + 1}`}
              onChange={(e) => onChange(items.map((x, j) => (j === i ? e.target.value : x)))} />
            {items.length > 1 && (
              <Button variant="ghost" size="sm" aria-label="Remove line"
                onClick={() => onChange(items.filter((_, j) => j !== i))}>
                <Trash2 className="h-4 w-4" aria-hidden />
              </Button>
            )}
          </li>
        ))}
      </ul>
      <Button variant="ghost" size="sm" className="mt-1" onClick={() => onChange([...items, ""])}>
        <Plus className="h-3.5 w-3.5" aria-hidden /> Add line
      </Button>
    </div>
  );
}

function SaveIndicator({ state }: { state: string }) {
  const map: Record<string, { icon: React.ReactNode; text: string; className: string }> = {
    idle: { icon: null, text: "", className: "" },
    saving: { icon: <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />, text: "Saving…", className: "text-muted" },
    saved: { icon: <Check className="h-3.5 w-3.5" aria-hidden />, text: "Saved", className: "text-success" },
    queued: { icon: <CloudOff className="h-3.5 w-3.5" aria-hidden />, text: "Saved on this device", className: "text-warning" },
    error: { icon: <Cloud className="h-3.5 w-3.5" aria-hidden />, text: "Save failed", className: "text-danger" },
  };
  const entry = map[state];
  if (!entry?.text) return null;
  return (
    <span role="status" className={cn("flex items-center gap-1.5 self-center text-xs", entry.className)}>
      {entry.icon}{entry.text}
    </span>
  );
}
