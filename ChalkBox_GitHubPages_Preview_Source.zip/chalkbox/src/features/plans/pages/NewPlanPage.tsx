import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Sparkles, Wand2 } from "lucide-react";
import {
  buildConstraintPlan, evaluateReadiness, planBriefSchema,
  type GradeLevel, type LessonPlan, type PlanBrief,
} from "@chalkbox/contracts";
import { useRepositories } from "@/hooks/use-repositories";
import { useConnectivity } from "@/hooks/use-connectivity";
import { describeAIError, generatePlan, parseBrief, type ExtractedBrief } from "@/features/ai/ai.client";
import { Button, Card, Chip, Field, Input, InlineError, PageHeader, Textarea } from "@/components/ui";
import { VoiceInput } from "../components/VoiceInput";
import { LessonRail } from "../components/LessonRail";
import type { TeacherSettings } from "@/repositories/repository.types";

const SUBJECTS: Array<[PlanBrief["subject"], string]> = [
  ["science", "Science"], ["mathematics", "Mathematics"],
  ["social-science", "Social Science"], ["english", "English"],
  ["hindi", "Hindi"], ["evs", "EVS"],
];

const NEEDS: Array<[PlanBrief["learnerNeeds"][number], string]> = [
  ["mixed-ability", "Mixed ability"], ["multigrade", "Multigrade room"],
  ["language-support", "Language support"], ["remedial-support", "Needs remedial help"],
  ["advanced-learners", "Advanced learners"], ["large-class", "Very large class"],
];

/**
 * The three-tap path.
 *
 * Everything below "More detail" is optional. A teacher who taps nothing but
 * "Make the plan" still gets a valid, grounded lesson, because the profile
 * already carries classes, language and materials.
 */
export function NewPlanPage() {
  const navigate = useNavigate();
  const repos = useRepositories();
  const online = useConnectivity();

  const [settings, setSettings] = useState<TeacherSettings | null>(null);
  const [freeText, setFreeText] = useState("");
  const [extracting, setExtracting] = useState(false);
  const [extracted, setExtracted] = useState<ExtractedBrief | null>(null);

  const [grades, setGrades] = useState<GradeLevel[]>([]);
  const [subject, setSubject] = useState<PlanBrief["subject"]>("science");
  const [topic, setTopic] = useState("");
  const [chapter, setChapter] = useState("");
  const [duration, setDuration] = useState(40);
  const [language, setLanguage] = useState<PlanBrief["outputLanguage"]>("en-hi");
  const [classSize, setClassSize] = useState(40);
  const [needs, setNeeds] = useState<PlanBrief["learnerNeeds"]>(["mixed-ability"]);
  const [priorKnowledge, setPriorKnowledge] = useState("");
  const [instructions, setInstructions] = useState("");
  const [showMore, setShowMore] = useState(false);

  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<{ message: string; retryable: boolean } | null>(null);

  useEffect(() => {
    (async () => {
      const [cfg, draft] = await Promise.all([repos.settings.get(), repos.drafts.load()]);
      if (cfg) {
        setSettings(cfg);
        setGrades(cfg.defaultGrades as GradeLevel[]);
        setSubject((cfg.defaultSubjects[0] as PlanBrief["subject"]) ?? "science");
        setLanguage(cfg.defaultLanguage);
        setDuration(cfg.defaultDurationMinutes);
      }
      if (draft?.brief) {
        const b = draft.brief;
        if (b.topic) setTopic(b.topic);
        if (b.grades) setGrades(b.grades as GradeLevel[]);
        if (b.chapter) setChapter(b.chapter);
        toast.info("Restored your unfinished plan request.");
      }
    })();
  }, [repos]);

  // Persist a draft so a closed tab does not lose a half-filled request.
  useEffect(() => {
    if (!topic && grades.length === 0) return;
    const t = setTimeout(() => {
      repos.drafts.save({
        id: "current", updatedAt: new Date().toISOString(), step: 1,
        brief: { topic, grades, chapter: chapter || undefined, durationMinutes: duration },
      }).catch(() => undefined);
    }, 800);
    return () => clearTimeout(t);
  }, [topic, grades, chapter, duration, repos]);

  const multi = grades.length > 1;
  const preview = useMemo(() => {
    if (grades.length === 0) return null;
    try { return buildConstraintPlan(duration, grades); } catch { return null; }
  }, [duration, grades]);

  function toggle<T>(list: T[], value: T, set: (v: T[]) => void) {
    set(list.includes(value) ? list.filter((x) => x !== value) : [...list, value]);
  }

  async function runExtract() {
    if (freeText.trim().length < 10) {
      toast.error("Describe the lesson in a sentence or two first.");
      return;
    }
    setExtracting(true); setError(null);
    try {
      const result = await parseBrief(freeText);
      setExtracted(result);
      // Extraction never generates directly -- fields are filled in for review.
      if (result.grades?.length) setGrades(result.grades as GradeLevel[]);
      if (result.subject) setSubject(result.subject);
      if (result.topic) setTopic(result.topic);
      if (result.chapter) setChapter(result.chapter);
      if (result.durationMinutes) setDuration(result.durationMinutes);
      if (result.outputLanguage) setLanguage(result.outputLanguage);
      if (result.classSize) setClassSize(result.classSize);
      if (result.learnerNeeds?.length) setNeeds(result.learnerNeeds);
      setShowMore(true);
      toast.success("Check the details below, then make the plan.");
    } catch (err) {
      const described = describeAIError(err);
      setError(described);
    } finally {
      setExtracting(false);
    }
  }

  function buildBrief(): PlanBrief | null {
    const candidate = {
      board: settings?.defaultBoard ?? "cbse-ncert",
      grades, subject, topic: topic.trim(),
      chapter: chapter.trim() || undefined,
      durationMinutes: duration, outputLanguage: language, classSize,
      connectivity: "intermittent" as const,
      availableResources: settings?.availableResources ?? ["Blackboard and chalk"],
      priorKnowledge: priorKnowledge.trim() || undefined,
      desiredGoals: [], learnerNeeds: needs, accessibilityNeeds: [],
      additionalInstructions: instructions.trim() || undefined,
    };
    const parsed = planBriefSchema.safeParse(candidate);
    if (!parsed.success) {
      toast.error(parsed.error.errors[0]?.message ?? "Some details are missing.");
      return null;
    }
    return parsed.data;
  }

  async function submit() {
    const brief = buildBrief();
    if (!brief) return;
    setGenerating(true); setError(null);
    try {
      const result = await generatePlan(brief);
      const constraint = buildConstraintPlan(brief.durationMinutes, brief.grades);
      const readiness = result.readiness ?? evaluateReadiness({
        content: result.plan.content, constraint, brief, suppliedChunkIds: [],
      });
      const now = new Date().toISOString();
      const plan: LessonPlan = {
        id: crypto.randomUUID(), ownerId: null, title: result.plan.title,
        status: "ready", visibility: "private", brief, content: result.plan.content,
        groundingLevel: result.groundingLevel, readiness, tags: [brief.subject],
        isFavourite: false, isPinnedOffline: false, schemaVersion: 1, versionNumber: 1,
        generationRunId: result.meta?.generationRunId ?? null,
        createdAt: now, updatedAt: now,
      };
      await repos.plans.create(plan);
      await repos.analytics.record("plan_created", plan.id, {
        grades: brief.grades.length, language: brief.outputLanguage,
      });
      await repos.drafts.clear();
      navigate(`/app/plans/${plan.id}`, { replace: true });
    } catch (err) {
      setError(describeAIError(err));
    } finally {
      setGenerating(false);
    }
  }

  return (
    <div className="mx-auto max-w-form">
      <PageHeader
        title="New lesson plan"
        description="Describe it in a sentence, or fill in the details directly."
      />

      <Card className="p-5">
        <label className="field-label" htmlFor="brief">Quick brief</label>
        <p className="mb-2 text-sm text-muted">
          For example: “40 minute Class 6 science lesson on separation of
          substances using only a blackboard and household things, mixed ability.”
        </p>
        <div className="flex gap-2">
          <Textarea id="brief" value={freeText} rows={3}
            onChange={(e) => setFreeText(e.target.value)}
            placeholder="Tell ChalkBox about the lesson…" />
          <div className="flex flex-col gap-2">
            <VoiceInput language={language}
              onResult={(t) => setFreeText((v) => `${v} ${t}`.trim())} />
          </div>
        </div>
        <Button variant="secondary" className="mt-3" loading={extracting}
          disabled={!online} onClick={runExtract}>
          <Wand2 className="h-4 w-4" aria-hidden /> Fill in the details for me
        </Button>
        {!online && (
          <p className="mt-2 text-sm text-warning">
            Reading a brief needs a connection. You can still fill in the fields below.
          </p>
        )}
        {extracted?.confidenceNotes?.length ? (
          <div className="mt-3 rounded-field border border-info/30 bg-info/5 px-3 py-2">
            <p className="text-xs font-semibold text-info">ChalkBox guessed these — please check:</p>
            <ul className="mt-1 list-inside list-disc text-xs text-ink">
              {extracted.confidenceNotes.map((n, i) => <li key={i}>{n}</li>)}
            </ul>
          </div>
        ) : null}
      </Card>

      <div className="mt-6 space-y-6">
        <fieldset>
          <legend className="field-label">Classes in the room</legend>
          <div className="flex flex-wrap gap-2">
            {([1,2,3,4,5,6,7,8,9,10] as GradeLevel[]).map((g) => (
              <Chip key={g} active={grades.includes(g)}
                onClick={() => toggle(grades, g, setGrades as (v: GradeLevel[]) => void)}>
                {g}
              </Chip>
            ))}
          </div>
          {multi && (
            <p className="mt-2 text-sm text-primary">
              {grades.length} classes together. ChalkBox will build one shared
              activity plus a separate track for each class, so you are never
              needed in two places at once.
            </p>
          )}
        </fieldset>

        <div className="grid gap-4 sm:grid-cols-2">
          <fieldset>
            <legend className="field-label">Subject</legend>
            <div className="flex flex-wrap gap-2">
              {SUBJECTS.map(([value, label]) => (
                <Chip key={value} active={subject === value} onClick={() => setSubject(value)}>
                  {label}
                </Chip>
              ))}
            </div>
          </fieldset>
          <Field label="Topic" htmlFor="topic" required
            hint="What the lesson is about.">
            <Input value={topic} onChange={(e) => setTopic(e.target.value)}
              placeholder="Separation of substances" />
          </Field>
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          <fieldset>
            <legend className="field-label">Period length</legend>
            <div className="flex flex-wrap gap-2">
              {[30, 35, 40, 45, 60].map((d) => (
                <Chip key={d} active={duration === d} onClick={() => setDuration(d)}>{d}</Chip>
              ))}
            </div>
          </fieldset>
          <fieldset>
            <legend className="field-label">Language</legend>
            <div className="flex flex-wrap gap-2">
              {([["hi","हिन्दी"],["en","English"],["en-hi","Both"]] as const).map(([v, l]) => (
                <Chip key={v} active={language === v} onClick={() => setLanguage(v)}>{l}</Chip>
              ))}
            </div>
          </fieldset>
          <Field label="Class size" htmlFor="size">
            <Input id="size" inputMode="numeric" value={classSize}
              onChange={(e) => setClassSize(Number(e.target.value) || 40)} />
          </Field>
        </div>

        {settings && (
          <Card className="p-4">
            <p className="field-label mb-1">What the plan may use</p>
            <p className="text-sm text-muted">{settings.availableResources.join(" · ")}</p>
            <p className="mt-1.5 text-xs text-muted">
              Nothing outside this list, apart from ordinary household objects.
              Change it in Settings.
            </p>
          </Card>
        )}

        <button type="button" onClick={() => setShowMore((v) => !v)}
          className="font-display text-sm font-semibold text-primary underline underline-offset-4">
          {showMore ? "Hide extra detail" : "More detail (optional)"}
        </button>

        {showMore && (
          <div className="space-y-5">
            <fieldset>
              <legend className="field-label">This room</legend>
              <div className="flex flex-wrap gap-2">
                {NEEDS.map(([value, label]) => (
                  <Chip key={value} active={needs.includes(value)}
                    onClick={() => toggle(needs, value, setNeeds as (v: typeof needs) => void)}>
                    {label}
                  </Chip>
                ))}
              </div>
            </fieldset>
            <Field label="Chapter" htmlFor="chapter" hint="Helps ChalkBox find the right curriculum passages.">
              <Input value={chapter} onChange={(e) => setChapter(e.target.value)} />
            </Field>
            <Field label="What students already know" htmlFor="prior">
              <Input value={priorKnowledge} onChange={(e) => setPriorKnowledge(e.target.value)} />
            </Field>
            <Field label="Anything else" htmlFor="notes"
              hint="Local examples, an activity you want included, something to avoid.">
              <Textarea id="notes" value={instructions} rows={2}
                onChange={(e) => setInstructions(e.target.value)} />
            </Field>
          </div>
        )}

        {preview && (
          <section aria-label="Lesson shape preview">
            <h2 className="field-label">How the period will be split</h2>
            <LessonRail constraint={preview} language={language} />
          </section>
        )}

        {error && (
          <InlineError message={error.message} onRetry={error.retryable ? submit : undefined} />
        )}
      </div>

      <div className="sticky bottom-20 mt-8 lg:bottom-6">
        <Button className="w-full shadow-lift" loading={generating}
          disabled={grades.length === 0 || topic.trim().length < 2 || !online}
          onClick={submit}>
          <Sparkles className="h-4 w-4" aria-hidden />
          {generating ? "Building your plan…" : "Make the plan"}
        </Button>
        {!online && (
          <p className="mt-2 text-center text-sm text-warning">
            Making a new plan needs a connection. Your saved plans still work offline.
          </p>
        )}
      </div>
    </div>
  );
}
