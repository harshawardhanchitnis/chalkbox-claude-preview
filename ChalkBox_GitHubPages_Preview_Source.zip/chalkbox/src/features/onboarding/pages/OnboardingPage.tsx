import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useRepositories } from "@/hooks/use-repositories";
import { Button, Chip, Field, Input, PageHeader } from "@/components/ui";

const RESOURCES = [
  "Blackboard and chalk", "Coloured chalk", "Notebooks", "Slates",
  "Stones or pebbles", "Bottle caps", "Sticks or twigs", "String",
  "Old newspaper", "Water and a bucket", "Matchbox", "Candle",
  "Glass tumbler", "Rubber bands", "Leaves and seeds", "Measuring tape",
  "Wall charts", "Textbook (teacher's copy)",
];

const SUBJECTS = [
  ["science", "Science"], ["mathematics", "Mathematics"],
  ["social-science", "Social Science"], ["english", "English"],
  ["hindi", "Hindi"], ["evs", "EVS"],
];

export function OnboardingPage() {
  const navigate = useNavigate();
  const repos = useRepositories();
  const [saving, setSaving] = useState(false);
  const [name, setName] = useState("");
  const [school, setSchool] = useState("");
  const [grades, setGrades] = useState<number[]>([6, 7]);
  const [subjects, setSubjects] = useState<string[]>(["science"]);
  const [language, setLanguage] = useState<"en" | "hi" | "en-hi">("en-hi");
  const [duration, setDuration] = useState(40);
  const [baseline, setBaseline] = useState(30);
  const [resources, setResources] = useState<string[]>(["Blackboard and chalk", "Notebooks"]);

  function toggle<T>(list: T[], value: T, set: (v: T[]) => void) {
    set(list.includes(value) ? list.filter((x) => x !== value) : [...list, value]);
  }

  async function finish() {
    setSaving(true);
    await repos.settings.save({
      displayName: name || "Teacher",
      schoolName: school || undefined,
      defaultBoard: "cbse-ncert",
      defaultGrades: [...grades].sort((a, b) => a - b),
      defaultSubjects: subjects,
      defaultLanguage: language,
      defaultDurationMinutes: duration,
      baselinePlanningMinutes: baseline,
      availableResources: resources,
      theme: "system",
      reducedMotion: false,
      voiceEnabled: true,
      onboardingCompleted: true,
    });
    navigate("/app", { replace: true });
  }

  return (
    <div className="mx-auto max-w-form px-5 py-10">
      <PageHeader
        title="Set up your classroom"
        description="Asked once. After this, a plan takes three taps."
      />

      <div className="space-y-7">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Your name" htmlFor="name" hint="Optional — used only to greet you.">
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Anita Sharma" />
          </Field>
          <Field label="School" htmlFor="school" hint="Optional.">
            <Input value={school} onChange={(e) => setSchool(e.target.value)} placeholder="Government Middle School" />
          </Field>
        </div>

        <fieldset>
          <legend className="field-label">Classes you teach</legend>
          <div className="flex flex-wrap gap-2">
            {[1,2,3,4,5,6,7,8,9,10].map((g) => (
              <Chip key={g} active={grades.includes(g)} onClick={() => toggle(grades, g, setGrades)}>
                {g}
              </Chip>
            ))}
          </div>
        </fieldset>

        <fieldset>
          <legend className="field-label">Subjects</legend>
          <div className="flex flex-wrap gap-2">
            {SUBJECTS.map(([value, label]) => (
              <Chip key={value} active={subjects.includes(value)} onClick={() => toggle(subjects, value, setSubjects)}>
                {label}
              </Chip>
            ))}
          </div>
        </fieldset>

        <div className="grid gap-4 sm:grid-cols-3">
          <fieldset>
            <legend className="field-label">Plan language</legend>
            <div className="flex flex-wrap gap-2">
              {([["hi","हिन्दी"],["en","English"],["en-hi","Both"]] as const).map(([v, l]) => (
                <Chip key={v} active={language === v} onClick={() => setLanguage(v)}>{l}</Chip>
              ))}
            </div>
          </fieldset>
          <Field label="Usual period length" htmlFor="dur" hint="Minutes.">
            <Input id="dur" inputMode="numeric" value={duration}
              onChange={(e) => setDuration(Number(e.target.value) || 40)} />
          </Field>
          <Field label="Time you usually spend planning" htmlFor="base"
            hint="Used only for the estimated time-saved figure.">
            <Input id="base" inputMode="numeric" value={baseline}
              onChange={(e) => setBaseline(Number(e.target.value) || 30)} />
          </Field>
        </div>

        <fieldset>
          <legend className="field-label">What you actually have in the room</legend>
          <p className="mb-2 text-sm text-muted">
            Plans will only use these, plus ordinary household objects. Leave out
            anything your school does not have.
          </p>
          <div className="flex flex-wrap gap-2">
            {RESOURCES.map((r) => (
              <Chip key={r} active={resources.includes(r)} onClick={() => toggle(resources, r, setResources)}>
                {r}
              </Chip>
            ))}
          </div>
        </fieldset>

        <Button className="w-full" loading={saving} disabled={grades.length === 0 || subjects.length === 0}
          onClick={finish}>
          Start planning
        </Button>
      </div>
    </div>
  );
}
