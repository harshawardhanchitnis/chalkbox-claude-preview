import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabase";
import { hasBackend } from "@/lib/env";
import { useAppStore } from "@/store/app.store";
import { Button, Card, Field, Input, InlineError } from "@/components/ui";

/**
 * Sign in and register.
 *
 * When no backend is configured the form is disabled with an honest
 * explanation rather than a button that silently does nothing.
 */
export function AuthPage() {
  const navigate = useNavigate();
  const setMode = useAppStore((s) => s.setMode);
  const [tab, setTab] = useState<"signin" | "register">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const sb = supabase();
    if (!sb) return;
    setBusy(true); setError(null); setNotice(null);
    try {
      if (tab === "register") {
        const { error: err } = await sb.auth.signUp({ email, password });
        if (err) throw err;
        setNotice("Check your email to confirm the account, then sign in.");
      } else {
        const { error: err } = await sb.auth.signInWithPassword({ email, password });
        if (err) throw err;
        setMode("production");
        navigate("/app", { replace: true });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not sign in.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-dvh max-w-md flex-col justify-center px-5 py-10">
      <Link to="/" className="mb-6 text-sm text-muted underline underline-offset-4">← Back</Link>
      <h1 className="font-display text-2xl font-bold tracking-tight">
        {tab === "signin" ? "Sign in to ChalkBox" : "Create your account"}
      </h1>

      {!hasBackend && (
        <div className="mt-4 rounded-card border border-warning/40 bg-warning/5 px-4 py-3">
          <p className="text-sm text-warning">
            Accounts are not connected yet in this build. Demo Mode gives you the
            full product on this device — plans, editing, Teach Mode, export and
            offline all work.
          </p>
        </div>
      )}

      <Card className="mt-5 p-5">
        <div role="tablist" aria-label="Authentication" className="mb-4 flex gap-2">
          {(["signin", "register"] as const).map((t) => (
            <button key={t} role="tab" aria-selected={tab === t}
              onClick={() => setTab(t)}
              className={tab === t ? "chip-on" : "chip-off"}>
              {t === "signin" ? "Sign in" : "Register"}
            </button>
          ))}
        </div>

        <form onSubmit={submit} className="space-y-4">
          <Field label="Email" htmlFor="email">
            <Input type="email" autoComplete="email" required disabled={!hasBackend}
              value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label="Password" htmlFor="password"
            hint={tab === "register" ? "At least 8 characters." : undefined}>
            <Input type="password" minLength={8} required disabled={!hasBackend}
              autoComplete={tab === "register" ? "new-password" : "current-password"}
              value={password} onChange={(e) => setPassword(e.target.value)} />
          </Field>
          {error && <InlineError message={error} />}
          {notice && <p role="status" className="text-sm text-success">{notice}</p>}
          <Button type="submit" className="w-full" loading={busy} disabled={!hasBackend}>
            {tab === "signin" ? "Sign in" : "Create account"}
          </Button>
        </form>
      </Card>

      <p className="mt-6 text-center text-sm text-muted">
        Just looking?{" "}
        <Link to="/demo" className="font-semibold text-primary underline underline-offset-4">
          Open the demo instead
        </Link>
      </p>
    </div>
  );
}
