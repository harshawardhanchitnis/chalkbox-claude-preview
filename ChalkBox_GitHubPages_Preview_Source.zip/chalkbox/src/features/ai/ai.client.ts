import { SCHEMA_VERSION, type PlanBrief, type GeneratedPlan, type PlanReadiness } from "@chalkbox/contracts";
import { AIRequestError, AIUnavailableError, callLessonAI } from "@/lib/supabase";

/**
 * The only place the browser talks to the AI gateway.
 *
 * Every call carries an idempotency key so a retry after a dropped connection
 * cannot produce two plans and burn two quota units.
 */

export interface GenerateResult {
  plan: GeneratedPlan;
  readiness: PlanReadiness;
  groundingLevel: "grounded" | "partial" | "ungrounded";
  constraint: unknown;
  meta: {
    generationRunId: string | null;
    model: string;
    promptVersion: string;
    latencyMs: number;
    repairUsed: boolean;
    passagesUsed: number;
    remainingQuota: number;
  };
}

export interface ExtractedBrief {
  grades?: number[];
  subject?: PlanBrief["subject"];
  customSubject?: string;
  topic?: string;
  chapter?: string;
  durationMinutes?: number;
  outputLanguage?: PlanBrief["outputLanguage"];
  classSize?: number;
  availableResources?: string[];
  learnerNeeds?: PlanBrief["learnerNeeds"];
  desiredGoals?: string[];
  /** What the model inferred rather than read, so the teacher can check it. */
  confidenceNotes?: string[];
}

export async function parseBrief(freeText: string): Promise<ExtractedBrief> {
  const data = await callLessonAI<{ extracted: ExtractedBrief }>({
    action: "parse-brief",
    schemaVersion: SCHEMA_VERSION,
    freeText,
    idempotencyKey: crypto.randomUUID(),
  });
  return data.extracted;
}

export async function generatePlan(brief: PlanBrief): Promise<GenerateResult> {
  return callLessonAI<GenerateResult>({
    action: "generate-plan",
    schemaVersion: SCHEMA_VERSION,
    brief,
    idempotencyKey: crypto.randomUUID(),
  });
}

export async function regenerateSection(args: {
  brief: PlanBrief;
  section: string;
  currentContent: unknown;
  teacherInstruction?: string;
}): Promise<{ section: string; content: unknown }> {
  return callLessonAI({
    action: "regenerate-section",
    schemaVersion: SCHEMA_VERSION,
    ...args,
    idempotencyKey: crypto.randomUUID(),
  });
}

/** Turns any failure into something a teacher can act on. */
export function describeAIError(err: unknown): { message: string; retryable: boolean; code: string } {
  if (err instanceof AIRequestError) {
    return { message: err.message, retryable: err.retryable, code: err.code };
  }
  if (err instanceof AIUnavailableError) {
    return { message: err.message, retryable: false, code: err.code };
  }
  return {
    message: "The lesson could not be generated. Please try again.",
    retryable: true,
    code: "unknown",
  };
}

export { AIRequestError, AIUnavailableError };
