import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { CalendarDays, Clock, FileText, Plus, WifiOff } from "lucide-react";
import type { LessonPlan } from "@chalkbox/contracts";
import { useRepositories, useIsDemo } from "@/hooks/use-repositories";
import { useConnectivity } from "@/hooks/use-connectivity";
import { Badge, Card, EmptyState, InlineError, PageHeader, Skeleton } from "@/components/ui";
import { PlanCard } from "@/features/plans/components/PlanCard";
import type { AnalyticsSummary, TeacherSettings } from "@/repositories/repository.types";

export function DashboardPage() {
  const repos = useRepositories();
  const isDemo = useIsDemo();
  const online = useConnectivity();
  const [plans, setPlans] = useState<LessonPlan[] | null>(null);
  const [summary, setSummary] = useState<AnalyticsSummary | null>(null);
  const [settings, setSettings] = useState<TeacherSettings | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [p, s, cfg] = await Promise.all([
          repos.plans.list({ sort: "updated" }),
          repos.analytics.summary(30),
          repos.settings.get(),
        ]);
        if (cancelled) return;
        setPlans(p); setSummary(s); setSettings(cfg);
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : "Could not load your dashboard.");
      }
    })();
    return () => { cancelled = true; };
  }, [repos]);

  const greeting = (() => {
    const h = new Date().getHours();
    if (h < 12) return "Good morning";
    if (h < 17) return "Good afternoon";
    return "Good evening";
  })();

  if (error) return <InlineError message={error} onRetry={() => window.location.reload()} />;

  const upcoming = plans?.find((p) => p.status === "ready");
  const recent = plans?.slice(0, 6) ?? [];

  return (
    <div>
      <PageHeader
        title={`${greeting}${settings?.displayName ? `, ${settings.displayName.split(" ")[0]}` : ""}`}
        description={
          upcoming
            ? "Your next lesson is ready to teach."
            : "Make a plan for tomorrow — it takes about a minute."
        }
        actions={<Link to="/app/plans/new" className="btn-primary"><Plus className="h-4 w-4" aria-hidden /> New plan</Link>}
      />

      {!online && (
        <div className="mb-5 flex items-start gap-2 rounded-card border border-warning/40 bg-warning/5 px-4 py-3">
          <WifiOff className="mt-0.5 h-4 w-4 shrink-0 text-warning" aria-hidden />
          <p className="text-sm text-warning">
            You are offline. Saved plans open, edit and print normally. Making a
            new plan with AI needs a connection.
          </p>
        </div>
      )}

      {upcoming && (
        <Card className="mb-6 overflow-hidden">
          <div className="border-b border-line bg-primary-soft/50 px-5 py-2">
            <p className="flex items-center gap-1.5 font-display text-xs font-semibold uppercase tracking-wide text-primary">
              <CalendarDays className="h-3.5 w-3.5" aria-hidden /> Ready to teach
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-4 px-5 py-4">
            <div className="min-w-0 flex-1">
              <h2 className="truncate font-display text-lg font-semibold">{upcoming.title}</h2>
              <p className="mt-0.5 text-sm text-muted">
                {upcoming.brief.grades.length > 1
                  ? `Classes ${upcoming.brief.grades.join(", ")}`
                  : `Class ${upcoming.brief.grades[0]}`}
                {" · "}{upcoming.brief.durationMinutes} min
                {" · "}{upcoming.readiness.score}% ready
              </p>
            </div>
            <div className="flex gap-2">
              <Link to={`/app/plans/${upcoming.id}`} className="btn-secondary btn-sm">Open</Link>
              <Link to={`/app/plans/${upcoming.id}/teach`} className="btn-primary btn-sm">Teach</Link>
            </div>
          </div>
        </Card>
      )}

      <section aria-labelledby="metrics" className="mb-8">
        <h2 id="metrics" className="mb-3 font-display text-sm font-semibold uppercase tracking-wide text-muted">
          Last 30 days {summary?.isDemoData && <Badge tone="accent" className="ml-1">Demo data</Badge>}
        </h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {summary ? (
            <>
              <Metric label="Plans made" value={summary.plansCreated} icon={<FileText className="h-4 w-4" />} />
              <Metric label="Lessons taught" value={summary.plansTaught} />
              <Metric label="Pinned offline" value={summary.offlinePinnedPlans} />
              <Metric
                label="Est. minutes saved"
                value={summary.estimatedMinutesSaved}
                icon={<Clock className="h-4 w-4" />}
                note="Estimate"
              />
            </>
          ) : (
            [0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-24" />)
          )}
        </div>
      </section>

      <section aria-labelledby="recent">
        <div className="mb-3 flex items-center justify-between">
          <h2 id="recent" className="font-display text-sm font-semibold uppercase tracking-wide text-muted">
            Recent plans
          </h2>
          <Link to="/app/library" className="text-sm underline underline-offset-4">See all</Link>
        </div>

        {plans === null && (
          <div className="grid gap-3 sm:grid-cols-2">
            {[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-28" />)}
          </div>
        )}

        {plans?.length === 0 && (
          <EmptyState
            title="No plans yet"
            description="Make your first lesson plan. Tell ChalkBox the class and chapter, and it does the rest."
            action={<Link to="/app/plans/new" className="btn-primary">Make a plan</Link>}
          />
        )}

        {recent.length > 0 && (
          <ul className="grid gap-3 sm:grid-cols-2">
            {recent.map((plan) => (
              <li key={plan.id}><PlanCard plan={plan} isDemo={isDemo} /></li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function Metric({
  label, value, icon, note,
}: { label: string; value: number; icon?: React.ReactNode; note?: string }) {
  return (
    <Card className="p-4">
      <div className="flex items-center gap-1.5 text-muted">
        {icon}
        <span className="text-xs">{label}</span>
      </div>
      <p className="mt-1 font-display text-2xl font-bold tabular-nums">{value.toLocaleString("en-IN")}</p>
      {note && <p className="text-[11px] italic text-muted">{note}</p>}
    </Card>
  );
}
