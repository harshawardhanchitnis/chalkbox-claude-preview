import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { bootstrapDemo } from "../demo.bootstrap";
import { useAppStore } from "@/store/app.store";
import { Spinner, InlineError } from "@/components/ui";

export function DemoBootstrapPage() {
  const navigate = useNavigate();
  const setMode = useAppStore((s) => s.setMode);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        await bootstrapDemo();
        if (cancelled) return;
        setMode("demo");
        navigate("/app", { replace: true });
      } catch (err) {
        if (!cancelled) {
          setError(
            err instanceof Error
              ? `Demo data could not be prepared: ${err.message}`
              : "Demo data could not be prepared.",
          );
        }
      }
    })();
    return () => { cancelled = true; };
  }, [navigate, setMode]);

  return (
    <div className="mx-auto flex min-h-dvh max-w-read flex-col items-center justify-center px-6 text-center">
      {error ? (
        <InlineError message={error} onRetry={() => window.location.reload()} />
      ) : (
        <>
          <Spinner className="h-8 w-8 text-primary" />
          <h1 className="mt-4 font-display text-xl font-bold">Preparing the demo</h1>
          <p className="mt-2 max-w-sm text-muted">
            Loading eight sample lesson plans onto this device. They are
            fictional records for a teacher named Anita Sharma, and nothing is
            sent anywhere.
          </p>
        </>
      )}
    </div>
  );
}
