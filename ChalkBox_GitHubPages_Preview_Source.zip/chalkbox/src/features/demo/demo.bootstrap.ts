import { demoDB, resetDemoDatabase } from "@/db/dexie";
import {
  buildDemoPlans, DEMO_COMMUNITY, DEMO_CURRICULUM_SOURCES, DEMO_DATA_VERSION,
  DEMO_NOTIFICATIONS, DEMO_PROFILE, DEMO_REFLECTIONS, DEMO_TEACH_SESSIONS,
} from "@/data/demo/fixtures";

/**
 * Demo bootstrap.
 *
 * Writes the fixtures into the SEPARATE demo IndexedDB database. Production
 * data lives in a different database entirely, so a demo reset can never touch
 * a registered teacher's real work.
 *
 * Reseeding is version-gated: bumping DEMO_DATA_VERSION reseeds on next open,
 * while ordinary edits a judge makes during a demo survive a page reload.
 */
export async function bootstrapDemo(force = false): Promise<void> {
  const marker = await demoDB.kv.get("demo-version");
  const current = marker?.value as number | undefined;
  if (!force && current === DEMO_DATA_VERSION) return;

  if (force || (current !== undefined && current !== DEMO_DATA_VERSION)) {
    await resetDemoDatabase();
  }

  const plans = buildDemoPlans();
  await demoDB.plans.bulkPut(
    plans.map((plan) => ({
      id: plan.id, ownerId: null, title: plan.title,
      grades: plan.brief.grades, subject: plan.brief.subject, status: plan.status,
      outputLanguage: plan.brief.outputLanguage, durationMinutes: plan.brief.durationMinutes,
      updatedAt: plan.updatedAt,
      isFavourite: (plan.isFavourite ? 1 : 0) as 0 | 1,
      isPinnedOffline: (plan.isPinnedOffline ? 1 : 0) as 0 | 1,
      isArchived: (plan.status === "archived" ? 1 : 0) as 0 | 1,
      isDemo: 1 as const, dirty: 0 as const,
      baseVersion: plan.versionNumber, plan,
    })),
  );

  await demoDB.kv.bulkPut([
    { key: "settings", value: DEMO_PROFILE },
    { key: "community", value: DEMO_COMMUNITY },
    { key: "curriculum-sources", value: DEMO_CURRICULUM_SOURCES },
    { key: "notifications", value: DEMO_NOTIFICATIONS },
    { key: "demo-version", value: DEMO_DATA_VERSION },
  ]);

  // Community plan snapshots, so a judge can open and clone a template.
  const template = plans[0];
  await demoDB.kv.bulkPut(
    DEMO_COMMUNITY.map((item) => ({
      key: `community-plan:${item.id}`,
      value: { ...template, id: item.id, title: item.title },
    })),
  );

  // Teach sessions and reflections. Analytics derive from these rows; there is
  // no hard-coded metric anywhere in the product.
  await demoDB.kv.bulkPut(
    DEMO_TEACH_SESSIONS.map((s, i) => ({
      key: `teach:${s.planId}:${1756000000000 + i}`,
      value: {
        id: `demo-teach-${i}`, planId: s.planId, updatedAt: new Date().toISOString(),
        currentStepId: null, completedStepIds: [], elapsedSeconds: 2400,
        attendanceCount: s.attendanceCount, metObjectiveCount: s.metObjectiveCount,
        partiallyMetCount: s.partiallyMetCount, needsSupportCount: s.needsSupportCount,
        engagementRating: s.engagementRating, completedAsPlanned: s.completedAsPlanned,
      },
    })),
  );
  await demoDB.kv.bulkPut(
    DEMO_REFLECTIONS.map((r, i) => ({
      key: `reflection:${r.planId}:${1756000000000 + i}`,
      value: { ...r, privateNotes: undefined },
    })),
  );
  await demoDB.kv.bulkPut(
    [0, 1, 2, 3].map((i) => ({
      key: `event:plan_exported:${1756000000000 + i}`,
      value: { name: "plan_exported", at: new Date().toISOString() },
    })),
  );
}

export async function resetDemo(): Promise<void> {
  await bootstrapDemo(true);
}
