import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Activity, Database, ShieldAlert } from "lucide-react";
import { useRepositories, useIsDemo } from "@/hooks/use-repositories";
import { hasBackend } from "@/lib/env";
import { supabase } from "@/lib/supabase";
import {
  Badge, Button, Card, PageHeader, Skeleton,
} from "@/components/ui";
import type { CurriculumSourceInfo } from "@/repositories/repository.types";

/**
 * Admin.
 *
 * In Demo Mode this reads the local fixture partition and is labelled a
 * simulation — a demo admin can never affect production data, because the
 * production surface is protected by RLS and the is_admin() function in
 * migration 008, not by this screen.
 */
export function AdminPage() {
  const repos = useRepositories();
  const isDemo = useIsDemo();
  const [sources, setSources] = useState<CurriculumSourceInfo[] | null>(null);
  const [pending, setPending] = useState<Array<{ id: string; title: string; authorName: string }>>([]);
  const [health, setHealth] = useState<Record<string, unknown> | null>(null);
  const [checking, setChecking] = useState(false);

  useEffect(() => {
    repos.curriculum.sources().then(setSources);
    repos.community.browse({}).then(() => undefined);
    (async () => {
      const all = await repos.community.mine();
      setPending(all.filter((i) => i.status === "pending"));
    })();
  }, [repos]);

  async function runHealthCheck() {
    setChecking(true);
    try {
      const sb = supabase();
      if (!sb) {
        toast.error("No backend is connected in this build.");
        return;
      }
      const { data, error } = await sb.functions.invoke("lesson-ai", {
        body: { action: "admin-health", schemaVersion: 1 },
      });
      if (error) throw error;
      setHealth(data as Record<string, unknown>);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Health check failed.");
    } finally { setChecking(false); }
  }

  return (
    <div>
      <PageHeader title="Admin"
        description="Curriculum sources, moderation and system health." />

      {isDemo && (
        <div className="mb-5 rounded-card border border-accent/50 bg-accent/10 px-4 py-3">
          <Badge tone="accent">Simulated admin</Badge>
          <p className="mt-1.5 text-sm">
            This is the local demo partition. Nothing here touches production
            data — real admin actions require an account promoted in the database.
          </p>
        </div>
      )}

      <div className="grid gap-5 lg:grid-cols-2">
        <Card className="p-5">
          <h2 className="mb-1 flex items-center gap-2 font-display text-base font-semibold">
            <Database className="h-4 w-4" aria-hidden /> Curriculum sources
          </h2>
          <p className="mb-3 text-sm text-muted">
            Every source carries its licence and origin. ChalkBox indexes only
            original material and openly licensed resources.
          </p>
          {sources === null ? <Skeleton className="h-32" /> :
           sources.length === 0 ? <p className="text-sm text-muted">No sources indexed.</p> : (
            <ul className="space-y-3">
              {sources.map((s) => (
                <li key={s.id} className="rounded-field border border-line p-3">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-display text-sm font-semibold">{s.title}</p>
                      <p className="text-xs text-muted">{s.publisher}</p>
                    </div>
                    <Badge tone={s.status === "active" ? "success" : "neutral"}>{s.status}</Badge>
                  </div>
                  <p className="mt-2 text-xs text-muted">{s.attribution}</p>
                  <div className="mt-2 flex flex-wrap items-center gap-1.5">
                    <Badge tone="info">{s.contentOrigin.replace("-", " ")}</Badge>
                    <Badge tone="neutral">{s.chunkCount} passages</Badge>
                    <Badge tone="neutral">Classes {s.grades.join(", ")}</Badge>
                  </div>
                  <Button variant="ghost" size="sm" className="mt-2"
                    onClick={async () => {
                      const next = s.status === "active" ? "disabled" : "active";
                      await repos.curriculum.setStatus(s.id, next);
                      setSources(await repos.curriculum.sources());
                    }}>
                    {s.status === "active" ? "Disable" : "Enable"}
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <div className="space-y-5">
          <Card className="p-5">
            <h2 className="mb-1 flex items-center gap-2 font-display text-base font-semibold">
              <ShieldAlert className="h-4 w-4" aria-hidden /> Moderation queue
            </h2>
            {pending.length === 0 ? (
              <p className="text-sm text-muted">Nothing waiting for review.</p>
            ) : (
              <ul className="space-y-2">
                {pending.map((p) => (
                  <li key={p.id} className="flex items-center gap-2 rounded-field border border-line px-3 py-2">
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-medium">{p.title}</span>
                      <span className="text-xs text-muted">by {p.authorName}</span>
                    </span>
                    <Button size="sm" variant="secondary"
                      onClick={() => toast.success("Approved")}>Approve</Button>
                    <Button size="sm" variant="ghost"
                      onClick={async () => {
                        await repos.community.withdraw(p.id);
                        setPending(pending.filter((x) => x.id !== p.id));
                        toast.success("Rejected");
                      }}>Reject</Button>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card className="p-5">
            <h2 className="mb-1 flex items-center gap-2 font-display text-base font-semibold">
              <Activity className="h-4 w-4" aria-hidden /> AI system health
            </h2>
            {!hasBackend ? (
              <p className="text-sm text-muted">
                No backend is connected in this build, so there is nothing to
                check yet. This calls the authenticated <code>admin-health</code>{" "}
                action — there is deliberately no public diagnostics endpoint
                that anyone could use to burn quota.
              </p>
            ) : (
              <>
                <Button variant="secondary" loading={checking} onClick={runHealthCheck}>
                  Run health check
                </Button>
                {health && (
                  <dl className="mt-3 space-y-1 text-sm">
                    {Object.entries(health).map(([k, v]) => (
                      <div key={k} className="flex justify-between gap-2">
                        <dt className="text-muted">{k}</dt>
                        <dd className="font-mono text-xs">{String(v)}</dd>
                      </div>
                    ))}
                  </dl>
                )}
              </>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
