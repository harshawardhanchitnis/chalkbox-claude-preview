import { useMemo } from "react";
import { createLocalRepositories } from "@/repositories/local.repository";
import { useAppStore } from "@/store/app.store";
import type { Repositories } from "@/repositories/repository.types";

/**
 * Every screen gets its repositories from here.
 *
 * Demo Mode and production share one interface, so the same components serve
 * both. When the hosted Supabase project is live, the production adapter
 * swaps in here and no screen changes.
 */
export function useRepositories(): Repositories {
  const mode = useAppStore((s) => s.mode);
  return useMemo(() => createLocalRepositories(mode === "demo"), [mode]);
}

export function useIsDemo(): boolean {
  return useAppStore((s) => s.mode) === "demo";
}
