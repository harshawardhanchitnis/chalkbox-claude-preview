import { buildConstraintPlan, type GradeLevel, type LessonPlan, type LessonPlanContent, type PlanBrief } from "@chalkbox/contracts";
import { evaluateReadiness } from "@chalkbox/contracts";

/**
 * Demo fixtures.
 *
 * IMPORTANT: everything here is fictional and is labelled "Demo data" wherever
 * it appears. It exists so a judge can open ChalkBox and use the real product
 * immediately, without an account and without waiting for a model call.
 *
 * Analytics are NOT hard-coded. These records are written into IndexedDB and
 * the same derivation code that serves a real teacher computes the numbers
 * from them. Delete the fixtures and every metric honestly reads zero.
 */

export const DEMO_DATA_VERSION = 3;
export const DEMO_ANCHOR_DATE = "2026-08-24";
export const DEMO_LABEL = "Demo data — fictional records";

export const DEMO_PROFILE = {
  displayName: "Anita Sharma",
  schoolName: "Government Middle School, Rampur",
  district: "Sehore, Madhya Pradesh",
  defaultBoard: "cbse-ncert",
  defaultGrades: [6, 7, 8],
  defaultSubjects: ["science", "mathematics"],
  defaultLanguage: "en-hi" as const,
  defaultDurationMinutes: 40,
  baselinePlanningMinutes: 30,
  availableResources: [
    "Blackboard and chalk", "Coloured chalk", "Notebooks", "Candle",
    "Matchbox", "Glass tumbler", "Stones or pebbles", "Bottle caps",
    "String", "Old newspaper", "Water and a bucket", "Leaves and seeds",
  ],
  theme: "system" as const,
  reducedMotion: false,
  voiceEnabled: true,
  onboardingCompleted: true,
};

function daysAgo(n: number): string {
  const d = new Date(DEMO_ANCHOR_DATE);
  d.setDate(d.getDate() - n);
  return d.toISOString();
}

interface Seed {
  id: string;
  title: string;
  topic: string;
  chapter?: string;
  grades: GradeLevel[];
  subject: PlanBrief["subject"];
  language: PlanBrief["outputLanguage"];
  duration: number;
  status: LessonPlan["status"];
  createdDaysAgo: number;
  favourite?: boolean;
  pinned?: boolean;
  reused?: boolean;
  grounding: LessonPlan["groundingLevel"];
}

/**
 * The hero demonstration is the multigrade candle-and-jar lesson: one glass,
 * one candle, three classes, three depths of question. It is the thing a
 * general-purpose chatbot cannot produce, so it is what the demo opens on.
 */
const SEEDS: Seed[] = [
  { id: "demo-plan-air-burning", title: "Air, Burning and Breathing — one candle, three classes",
    topic: "Air and burning", chapter: "Air Around Us", grades: [6, 7, 8], subject: "science",
    language: "en-hi", duration: 40, status: "ready", createdDaysAgo: 0,
    favourite: true, pinned: true, grounding: "grounded" },
  { id: "demo-plan-separation", title: "Separation of Substances",
    topic: "Separation of substances", chapter: "Separation of Substances", grades: [6], subject: "science",
    language: "en-hi", duration: 40, status: "ready", createdDaysAgo: 1, pinned: true, grounding: "grounded" },
  { id: "demo-plan-fractions", title: "Fractions on a Number Line",
    topic: "Fractions on a number line", grades: [6], subject: "mathematics",
    language: "hi", duration: 35, status: "taught", createdDaysAgo: 6, reused: true, grounding: "partial" },
  { id: "demo-plan-respiration", title: "Respiration in Organisms",
    topic: "Respiration", chapter: "Respiration in Organisms", grades: [7], subject: "science",
    language: "en-hi", duration: 45, status: "taught", createdDaysAgo: 5, grounding: "grounded" },
  { id: "demo-plan-local-government", title: "Understanding Local Government",
    topic: "Panchayat and municipality", grades: [6], subject: "social-science",
    language: "hi", duration: 40, status: "ready", createdDaysAgo: 2, grounding: "ungrounded" },
  { id: "demo-plan-ratio", title: "Ratio Through Everyday Sharing",
    topic: "Ratio and proportion", grades: [7, 8], subject: "mathematics",
    language: "en-hi", duration: 40, status: "taught", createdDaysAgo: 4,
    reused: true, pinned: true, grounding: "partial" },
  { id: "demo-plan-cells", title: "Cell — Structure and Functions",
    topic: "Plant and animal cells", chapter: "Cell - Structure and Functions", grades: [8], subject: "science",
    language: "en", duration: 45, status: "draft", createdDaysAgo: 3, grounding: "grounded" },
  { id: "demo-plan-reading", title: "Finding the Main Idea",
    topic: "Reading comprehension", grades: [7], subject: "english",
    language: "en", duration: 35, status: "archived", createdDaysAgo: 12, grounding: "ungrounded" },
];

function buildContent(seed: Seed): LessonPlanContent {
  const constraint = buildConstraintPlan(seed.duration, seed.grades);
  const multi = seed.grades.length > 1;
  const hi = seed.language === "hi";

  // A lesson needs at least two measurable objectives (see readiness checks),
  // so a single-class plan gets an understand-level and an apply-level goal
  // rather than one per class.
  const objectiveSpecs = multi
    ? seed.grades.slice(0, 3).map((g, i) => ({
        label: hi ? `कक्षा ${g}: ` : `Class ${g}: `,
        level: (i === 0 ? "understand" : "apply") as "understand" | "apply",
      }))
    : [
        { label: "", level: "understand" as const },
        { label: "", level: "apply" as const },
      ];

  const objectives = objectiveSpecs.map((spec, i) => ({
    id: `o${i + 1}`,
    statement: spec.level === "understand"
      ? (hi
          ? `${spec.label}${seed.topic} को दैनिक जीवन के उदाहरण से समझाना।`
          : `${spec.label}explain ${seed.topic} using an everyday example.`)
      : (hi
          ? `${spec.label}${seed.topic} का एक नया उदाहरण स्वयं खोजना।`
          : `${spec.label}find a new example of ${seed.topic} without help.`),
    successCriteria: [
      hi ? "बच्चा अपने शब्दों में एक उदाहरण देता है।" : "The student gives one example in their own words.",
    ],
    cognitiveLevel: spec.level,
  }));

  const materials = [
    { id: "m1", name: hi ? "श्यामपट्ट और चॉक" : "Blackboard and chalk", source: "school" as const },
    { id: "m2", name: hi ? "मोमबत्ती" : "Candle", source: "school" as const },
    { id: "m3", name: hi ? "काँच का गिलास" : "Glass tumbler", source: "school" as const },
  ];

  const timeline = constraint.windows.map((w, i) => {
    const directGrades = Object.entries(w.attention)
      .filter(([, a]) => a === "direct")
      .map(([g]) => Number(g) as GradeLevel);
    return {
      id: `s${i + 1}`,
      order: i,
      kind: i === 0 ? ("hook" as const) : i === constraint.windows.length - 1 ? ("closure" as const) : ("activity" as const),
      title: w.label,
      startMinute: w.startMinute,
      durationMinutes: w.durationMinutes,
      gradeFocus: directGrades.length ? directGrades : seed.grades,
      attention: w.shared || Object.values(w.attention).includes("direct")
        ? ("direct" as const)
        : ("independent" as const),
      teacherActions: [
        hi
          ? "मोमबत्ती जलाइए और उसे गिलास से ढक दीजिए। बच्चों से गिनती करवाइए।"
          : "Light the candle and cover it with the glass. Ask the class to count aloud.",
      ],
      studentActions: [
        hi ? "ध्यान से देखिए और अपनी कॉपी में लिखिए कि क्या हुआ।"
           : "Watch closely and write in your notebook what happened.",
      ],
      materialIds: ["m1", "m2", "m3"],
      objectiveIds: [objectives[Math.min(i, objectives.length - 1)].id],
      checkForUnderstanding: hi ? "लौ क्यों बुझी?" : "Why did the flame go out?",
      boardPrompt: w.shared
        ? (hi ? "हवा = नाइट्रोजन + ऑक्सीजन + अन्य" : "AIR = nitrogen + oxygen + others")
        : undefined,
    };
  });

  return {
    overview: hi
      ? "एक मोमबत्ती और एक गिलास की सहायता से पूरी कक्षा एक साथ प्रयोग देखती है, और हर कक्षा अपने स्तर पर प्रश्न का उत्तर देती है।"
      : `A single shared demonstration anchors ${multi ? "all three classes" : "the class"}, then each group works at its own depth.`,
    curriculumAlignment: [`CBSE/NCERT ${seed.subject}, classes ${seed.grades.join(", ")}`],
    objectives,
    prerequisites: [hi ? "बच्चे जानते हैं कि हवा हर जगह है।" : "Students know air is all around them."],
    vocabulary: [
      { term: hi ? "ऑक्सीजन (oxygen)" : "Oxygen", meaning: hi ? "हवा का वह भाग जो जलने में सहायक है।" : "The part of air that supports burning." },
    ],
    misconceptions: [
      { misconception: hi ? "हवा का कोई भार नहीं होता।" : "Air has no weight.",
        response: hi ? "गुब्बारे की तुलना से दिखाइए।" : "Compare an inflated and a deflated balloon." },
    ],
    materials,
    preparation: [hi ? "मोमबत्ती और गिलास कक्षा से पहले रख लीजिए।" : "Set out the candle and glass before the bell."],
    timeline,
    differentiation: {
      support: [hi ? "जोड़ी बनाकर काम करवाइए।" : "Let students work in pairs."],
      core: [hi ? "अपने शब्दों में एक वाक्य लिखवाइए।" : "One sentence in their own words."],
      extension: [hi ? "बड़ा गिलास लेने पर क्या होगा?" : "Predict what a bigger glass would change."],
      multigrade: multi
        ? {
            anchorActivity: hi
              ? "जलती मोमबत्ती को गिलास से ढकिए। सब मिलकर गिनें कि लौ कितनी देर जलती है।"
              : "Cover a burning candle with a glass. The whole room counts how long the flame lasts.",
            sharedInstruction: [hi ? "सब एक साथ देखें और गिनें।" : "Everyone watches and counts together."],
            tracks: seed.grades.map((g, i) => ({
              grade: g,
              objectiveIds: [objectives[Math.min(i, objectives.length - 1)].id],
              independentTasks: [
                hi ? `कक्षा ${g}: चित्र बनाकर लेबल लगाइए।` : `Class ${g}: draw and label the jar and candle.`,
              ],
              directInstructionWindows: [],
              assessmentPrompt: hi ? "एक वाक्य में कारण लिखिए।" : "Write the reason in one sentence.",
            })),
            peerSupport: [hi ? "बड़ी कक्षा छोटी कक्षा की मदद करे।" : "Older students check younger students' drawings."],
            transitionCues: [hi ? "अब कक्षा 7 अपना काम शुरू करे।" : "Class 7, start your task now."],
          }
        : undefined,
      accessibility: [hi ? "आगे बैठाइए ताकि लौ दिखे।" : "Seat students near the front so the flame is visible."],
      languageScaffolds: [hi ? "मुख्य शब्द श्यामपट्ट पर लिखिए।" : "Write key terms on the board in both languages."],
    },
    assessment: {
      diagnosticQuestions: [],
      formativeChecks: [hi ? "हाथ उठाकर उत्तर लीजिए।" : "Quick hands-up check."],
      exitTicket: [
        { id: "q1", type: "exit-ticket" as const,
          prompt: hi ? "लौ क्यों बुझ गई?" : "Why did the flame go out?",
          correctAnswer: hi ? "गिलास के अंदर की ऑक्सीजन समाप्त हो गई।" : "The oxygen inside the glass was used up.",
          explanation: hi ? "जलने के लिए ऑक्सीजन आवश्यक है।" : "Burning needs oxygen.",
          difficulty: "core" as const, objectiveIds: [objectives[0].id], gradeFocus: seed.grades },
      ],
      questionBank: [],
      rubric: [],
    },
    boardPlan: [
      { id: "b1", order: 0, title: hi ? "हवा में क्या है" : "What is in air",
        content: [hi ? "नाइट्रोजन ~78%" : "Nitrogen ~78%", hi ? "ऑक्सीजन ~21%" : "Oxygen ~21%"] },
    ],
    homeworkOrExtension: [hi ? "घर पर हवा के तीन उपयोग लिखिए।" : "List three uses of air at home."],
    safetyNotes: [
      hi ? "मोमबत्ती केवल शिक्षक जलाएँ। बच्चों को दूर रखें।"
         : "Only the teacher lights the candle. Keep students at arm's length.",
    ],
    inclusionNotes: [],
    reflectionPrompts: [hi ? "कौन-सा भाग सबसे अच्छा चला?" : "Which part worked best?"],
    citations: seed.grounding === "ungrounded" ? [] : [
      { id: "c1", sourceId: "demo-source-1", chunkId: "demo-chunk-1",
        label: `ChalkBox original notes — ${seed.chapter ?? seed.topic}`,
        locator: "Section 1",
        excerpt: "Oxygen is the part of air that supports burning." },
    ],
  };
}

export function buildDemoPlans(): LessonPlan[] {
  return SEEDS.map((seed) => {
    const brief: PlanBrief = {
      board: "cbse-ncert",
      grades: seed.grades,
      subject: seed.subject,
      topic: seed.topic,
      chapter: seed.chapter,
      lessonDate: DEMO_ANCHOR_DATE,
      durationMinutes: seed.duration,
      outputLanguage: seed.language,
      classSize: 42,
      connectivity: "intermittent",
      availableResources: DEMO_PROFILE.availableResources,
      desiredGoals: [],
      learnerNeeds: seed.grades.length > 1 ? ["multigrade", "mixed-ability"] : ["mixed-ability"],
      accessibilityNeeds: [],
    };
    const content = buildContent(seed);
    const constraint = buildConstraintPlan(seed.duration, seed.grades);
    const readiness = evaluateReadiness({
      content, constraint, brief,
      suppliedChunkIds: seed.grounding === "ungrounded" ? [] : ["demo-chunk-1"],
    });

    return {
      id: seed.id,
      ownerId: null,
      originPlanId: seed.reused ? "demo-plan-separation" : null,
      title: seed.title,
      status: seed.status,
      visibility: "private",
      brief,
      content,
      groundingLevel: seed.grounding,
      readiness,
      tags: [seed.subject],
      isFavourite: Boolean(seed.favourite),
      isPinnedOffline: Boolean(seed.pinned),
      schemaVersion: 1,
      versionNumber: 1,
      generationRunId: null,
      lastTaughtAt: seed.status === "taught" ? daysAgo(seed.createdDaysAgo - 1) : null,
      archivedAt: seed.status === "archived" ? daysAgo(seed.createdDaysAgo) : null,
      createdAt: daysAgo(seed.createdDaysAgo),
      updatedAt: daysAgo(Math.max(0, seed.createdDaysAgo - 1)),
    } satisfies LessonPlan;
  });
}

/** Teach sessions the analytics derive aggregate learner outcomes from. */
export const DEMO_TEACH_SESSIONS = [
  { planId: "demo-plan-fractions", attendanceCount: 41, metObjectiveCount: 29, partiallyMetCount: 9, needsSupportCount: 3, engagementRating: 4, completedAsPlanned: true },
  { planId: "demo-plan-respiration", attendanceCount: 38, metObjectiveCount: 31, partiallyMetCount: 5, needsSupportCount: 2, engagementRating: 5, completedAsPlanned: true },
  { planId: "demo-plan-ratio", attendanceCount: 44, metObjectiveCount: 30, partiallyMetCount: 10, needsSupportCount: 4, engagementRating: 4, completedAsPlanned: false },
];

export const DEMO_REFLECTIONS = [
  { planId: "demo-plan-fractions", workedWell: ["Paper folding held attention"],
    challenges: ["Numerator and denominator still confused"],
    changesForNextTime: ["Use folded paper strips from the start"],
    actionItems: ["Prepare folded paper strips"] },
  { planId: "demo-plan-respiration", workedWell: ["Limewater test surprised them"],
    challenges: ["Vocabulary needed bilingual reinforcement"],
    changesForNextTime: ["Add picture-word cards"],
    actionItems: ["Make bilingual vocabulary cards"] },
];

export const DEMO_COMMUNITY = [
  { id: "demo-pub-1", title: "Water Cycle with a Steel Plate", summary: "Condensation shown using a hot pot and a cold steel plate. Class 7 Science.", grades: [7], subject: "science", outputLanguage: "en-hi", authorName: "Meera Joshi", licence: "CC-BY-4.0", status: "approved" as const, cloneCount: 12, createdAt: daysAgo(9), isDemoData: true },
  { id: "demo-pub-2", title: "Panchayat Role Play", summary: "Students act out a gram sabha meeting. Class 6 Social Science.", grades: [6], subject: "social-science", outputLanguage: "hi", authorName: "Imran Khan", licence: "CC-BY-4.0", status: "approved" as const, cloneCount: 7, createdAt: daysAgo(14), isDemoData: true },
  { id: "demo-pub-3", title: "Multigrade Measurement Walk", summary: "Classes 5 to 7 measure the school yard at three levels of precision.", grades: [5, 6, 7], subject: "mathematics", outputLanguage: "en-hi", authorName: "Lakshmi Nair", licence: "CC-BY-4.0", status: "approved" as const, cloneCount: 19, createdAt: daysAgo(11), isDemoData: true },
  { id: "demo-pub-4", title: "Soil Types from the School Yard", summary: "Three soil samples, one comparison table. Class 7 Science.", grades: [7], subject: "science", outputLanguage: "en", authorName: "Meera Joshi", licence: "CC-BY-4.0", status: "approved" as const, cloneCount: 4, createdAt: daysAgo(16), isDemoData: true },
  { id: "demo-pub-5", title: "Shadows Through the Day", summary: "Hourly shadow tracing in the yard. Class 6 Science.", grades: [6], subject: "science", outputLanguage: "hi", authorName: "Imran Khan", licence: "CC-BY-4.0", status: "approved" as const, cloneCount: 9, createdAt: daysAgo(20), isDemoData: true },
  { id: "demo-pub-6", title: "Fraction Wall with Newspaper", summary: "Awaiting moderation.", grades: [6], subject: "mathematics", outputLanguage: "en-hi", authorName: "Meera Joshi", licence: "CC-BY-4.0", status: "pending" as const, cloneCount: 0, createdAt: daysAgo(2), isDemoData: true },
  { id: "demo-pub-7", title: "Simple Circuits with Cells", summary: "Awaiting moderation.", grades: [6], subject: "science", outputLanguage: "en", authorName: "Lakshmi Nair", licence: "CC-BY-4.0", status: "pending" as const, cloneCount: 0, createdAt: daysAgo(1), isDemoData: true },
];

export const DEMO_CURRICULUM_SOURCES = [
  { id: "demo-source-1", title: "ChalkBox Science Notes — Classes 6 to 8", publisher: "ChalkBox / Team HarshLabs", grades: [6, 7, 8], subjects: ["science"], licence: "CC-BY-4.0", attribution: "Original text written for ChalkBox, aligned to the CBSE/NCERT Science syllabus.", contentOrigin: "chalkbox-original", status: "active", chunkCount: 30, indexedAt: daysAgo(7) },
  { id: "demo-source-2", title: "ChalkBox Mathematics Notes — Classes 6 to 8", publisher: "ChalkBox / Team HarshLabs", grades: [6, 7, 8], subjects: ["mathematics"], licence: "CC-BY-4.0", attribution: "Original text written for ChalkBox.", contentOrigin: "chalkbox-original", status: "active", chunkCount: 18, indexedAt: daysAgo(7) },
  { id: "demo-source-3", title: "NCERT Learning Outcomes — Upper Primary", publisher: "NCERT", grades: [6, 7, 8], subjects: ["science", "mathematics"], licence: "Government of India, factual curriculum taxonomy", attribution: "Learning outcome statements, used for curriculum alignment only.", contentOrigin: "open-licensed", status: "active", chunkCount: 0, indexedAt: daysAgo(7) },
  { id: "demo-source-4", title: "Community contributed activities", publisher: "ChalkBox teachers", grades: [5, 6, 7, 8], subjects: ["science", "mathematics", "social-science"], licence: "CC-BY-4.0", attribution: "Contributed by teachers under CC-BY-4.0.", contentOrigin: "open-licensed", status: "active", chunkCount: 12, indexedAt: daysAgo(4) },
  { id: "demo-source-5", title: "Draft: Social Science notes", publisher: "ChalkBox", grades: [6, 7], subjects: ["social-science"], licence: "CC-BY-4.0", attribution: "Original, not yet reviewed.", contentOrigin: "chalkbox-original", status: "disabled", chunkCount: 0, indexedAt: null },
];

export const DEMO_NOTIFICATIONS = [
  { id: "demo-notif-1", type: "system", title: "You are in Demo Mode", message: "Everything here is fictional sample data. Your changes stay on this device and can be reset from Settings.", readAt: null, createdAt: daysAgo(0) },
  { id: "demo-notif-2", type: "publication-approved", title: "Template approved", message: "Your Multigrade Measurement Walk was approved for the community library.", actionUrl: "/app/community", readAt: null, createdAt: daysAgo(3) },
  { id: "demo-notif-3", type: "system", title: "Offline plans ready", message: "Three plans are pinned and will open without internet.", readAt: daysAgo(4), createdAt: daysAgo(4) },
];
