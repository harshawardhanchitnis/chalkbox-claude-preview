import type { LessonPlan, PlanBrief } from "@chalkbox/contracts";
import type { ConflictRecord, TeachDraft, WizardDraft } from "@/db/dexie";

/**
 * Repositories.
 *
 * Screens and hooks talk to this interface and never to Supabase or Dexie
 * directly. That is what lets Demo Mode be a genuine implementation of the
 * product rather than a mocked shell, and what lets the whole application be
 * built and tested before the hosted database exists.
 */

export interface PlanFilters {
  search?: string;
  grades?: number[];
  subject?: string;
  language?: string;
  status?: string;
  favouritesOnly?: boolean;
  offlineOnly?: boolean;
  includeArchived?: boolean;
  sort?: "updated" | "created" | "title" | "lessonDate";
}

export interface PlanRepository {
  list(filters: PlanFilters): Promise<LessonPlan[]>;
  get(id: string): Promise<LessonPlan | null>;
  create(plan: LessonPlan): Promise<LessonPlan>;
  update(id: string, plan: LessonPlan, note?: string): Promise<LessonPlan>;
  duplicate(id: string): Promise<LessonPlan>;
  archive(id: string, archived: boolean): Promise<void>;
  remove(id: string): Promise<void>;
  setFavourite(id: string, value: boolean): Promise<void>;
  setPinnedOffline(id: string, value: boolean): Promise<void>;
  versions(id: string): Promise<Array<{ id: string; versionNumber: number; reason: string; createdAt: string }>>;
  restoreVersion(planId: string, versionId: string): Promise<LessonPlan>;
}

export interface DraftRepository {
  save(draft: WizardDraft): Promise<void>;
  load(): Promise<WizardDraft | null>;
  clear(): Promise<void>;
}

export interface TeachRepository {
  saveDraft(draft: TeachDraft): Promise<void>;
  loadDraft(planId: string): Promise<TeachDraft | null>;
  finish(draft: TeachDraft): Promise<void>;
}

export interface ReflectionInput {
  planId: string;
  teachSessionId?: string;
  workedWell: string[];
  challenges: string[];
  changesForNextTime: string[];
  privateNotes?: string;
  actionItems: string[];
}

export interface ReflectionRepository {
  save(input: ReflectionInput): Promise<void>;
  listForPlan(planId: string): Promise<ReflectionInput[]>;
}

export interface AnalyticsSummary {
  rangeDays: number;
  plansCreated: number;
  plansTaught: number;
  plansReused: number;
  offlinePinnedPlans: number;
  exportCount: number;
  estimatedMinutesSaved: number;
  groundingCoveragePercent: number;
  reflectionCompletionPercent: number;
  learnerOutcomes: { total: number; met: number; partial: number; support: number };
  bySubject: Array<{ subject: string; count: number }>;
  byGrade: Array<{ grade: number; count: number }>;
  byLanguage: Array<{ language: string; count: number }>;
  /** True when these numbers come from prepared demo fixtures, not real work. */
  isDemoData: boolean;
}

export interface AnalyticsRepository {
  summary(rangeDays: number): Promise<AnalyticsSummary>;
  record(name: string, planId?: string, metadata?: Record<string, string | number | boolean>): Promise<void>;
}

export interface CommunityItem {
  id: string;
  title: string;
  summary: string;
  grades: number[];
  subject: string;
  outputLanguage: string;
  authorName: string;
  licence: string;
  status: "pending" | "approved" | "rejected" | "withdrawn";
  cloneCount: number;
  createdAt: string;
  isDemoData: boolean;
}

export interface CommunityRepository {
  browse(filters: { search?: string; subject?: string; grade?: number }): Promise<CommunityItem[]>;
  get(id: string): Promise<{ item: CommunityItem; plan: LessonPlan } | null>;
  clone(id: string): Promise<LessonPlan>;
  submit(planId: string, summary: string): Promise<void>;
  withdraw(publicationId: string): Promise<void>;
  report(publicationId: string, reason: string): Promise<void>;
  mine(): Promise<CommunityItem[]>;
}

export interface CurriculumSourceInfo {
  id: string;
  title: string;
  publisher: string;
  grades: number[];
  subjects: string[];
  licence: string;
  attribution: string;
  contentOrigin: string;
  status: string;
  chunkCount: number;
  indexedAt: string | null;
}

export interface CurriculumRepository {
  sources(): Promise<CurriculumSourceInfo[]>;
  setStatus(id: string, status: string): Promise<void>;
}

export interface NotificationItem {
  id: string;
  type: string;
  title: string;
  message: string;
  actionUrl?: string;
  readAt: string | null;
  createdAt: string;
}

export interface NotificationRepository {
  list(): Promise<NotificationItem[]>;
  markRead(id: string): Promise<void>;
  markAllRead(): Promise<void>;
}

export interface TeacherSettings {
  displayName: string;
  schoolName?: string;
  district?: string;
  defaultBoard: string;
  defaultGrades: number[];
  defaultSubjects: string[];
  defaultLanguage: "en" | "hi" | "en-hi";
  defaultDurationMinutes: number;
  baselinePlanningMinutes: number;
  availableResources: string[];
  theme: "light" | "dark" | "system";
  reducedMotion: boolean;
  voiceEnabled: boolean;
  onboardingCompleted: boolean;
}

export interface SettingsRepository {
  get(): Promise<TeacherSettings | null>;
  save(settings: TeacherSettings): Promise<void>;
}

export interface ShareRepository {
  create(planId: string): Promise<{ url: string; token: string }>;
  listForPlan(planId: string): Promise<Array<{ id: string; url: string; isActive: boolean; createdAt: string }>>;
  revoke(shareId: string): Promise<void>;
}

export interface SyncRepository {
  conflicts(): Promise<ConflictRecord[]>;
  pendingCount(): Promise<number>;
  flush(): Promise<{ pushed: number; conflicts: number; failed: number }>;
}

export interface Repositories {
  mode: "production" | "demo";
  plans: PlanRepository;
  drafts: DraftRepository;
  teach: TeachRepository;
  reflections: ReflectionRepository;
  analytics: AnalyticsRepository;
  community: CommunityRepository;
  curriculum: CurriculumRepository;
  notifications: NotificationRepository;
  settings: SettingsRepository;
  shares: ShareRepository;
  sync: SyncRepository;
}

export type { PlanBrief };
