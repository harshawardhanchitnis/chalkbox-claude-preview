import type { LessonPlan } from "@chalkbox/contracts";
import { dbFor, type CachedPlan, type TeachDraft, type WizardDraft } from "@/db/dexie";
import { enqueue, flushQueue, openConflicts, pendingCount } from "@/db/sync";
import type {
  AnalyticsRepository, AnalyticsSummary, CommunityItem, CommunityRepository,
  CurriculumRepository, DraftRepository, NotificationRepository, PlanFilters,
  PlanRepository, ReflectionInput, ReflectionRepository, Repositories,
  SettingsRepository, ShareRepository, SyncRepository, TeachRepository,
  TeacherSettings,
} from "./repository.types";

/**
 * IndexedDB-backed repositories.
 *
 * Used for Demo Mode, and as the offline mirror for a signed-in teacher. All
 * behaviour here is real: plans genuinely persist, filters genuinely filter,
 * analytics are genuinely derived from the stored records. Nothing is faked.
 */

function toCached(plan: LessonPlan, isDemo: boolean, dirty = true): CachedPlan {
  return {
    id: plan.id,
    ownerId: plan.ownerId,
    title: plan.title,
    grades: plan.brief.grades,
    subject: plan.brief.subject,
    status: plan.status,
    outputLanguage: plan.brief.outputLanguage,
    durationMinutes: plan.brief.durationMinutes,
    updatedAt: plan.updatedAt,
    isFavourite: plan.isFavourite ? 1 : 0,
    isPinnedOffline: plan.isPinnedOffline ? 1 : 0,
    isArchived: plan.status === "archived" ? 1 : 0,
    isDemo: isDemo ? 1 : 0,
    dirty: dirty ? 1 : 0,
    baseVersion: plan.versionNumber,
    plan,
  };
}

class LocalPlanRepository implements PlanRepository {
  constructor(private readonly isDemo: boolean) {}
  private get db() { return dbFor(this.isDemo); }

  async list(filters: PlanFilters): Promise<LessonPlan[]> {
    let rows = await this.db.plans.toArray();

    if (!filters.includeArchived) rows = rows.filter((r) => r.isArchived === 0);
    if (filters.favouritesOnly) rows = rows.filter((r) => r.isFavourite === 1);
    if (filters.offlineOnly) rows = rows.filter((r) => r.isPinnedOffline === 1);
    if (filters.status) rows = rows.filter((r) => r.status === filters.status);
    if (filters.subject) rows = rows.filter((r) => r.subject === filters.subject);
    if (filters.language) rows = rows.filter((r) => r.outputLanguage === filters.language);
    if (filters.grades?.length) {
      rows = rows.filter((r) => r.grades.some((g) => filters.grades!.includes(g)));
    }
    if (filters.search) {
      const q = filters.search.toLowerCase();
      rows = rows.filter(
        (r) =>
          r.title.toLowerCase().includes(q) ||
          r.plan.brief.topic.toLowerCase().includes(q) ||
          r.plan.tags.some((t) => t.toLowerCase().includes(q)),
      );
    }

    const sort = filters.sort ?? "updated";
    rows.sort((a, b) => {
      if (sort === "title") return a.title.localeCompare(b.title);
      if (sort === "created") return b.plan.createdAt.localeCompare(a.plan.createdAt);
      if (sort === "lessonDate") {
        return (b.plan.brief.lessonDate ?? "").localeCompare(a.plan.brief.lessonDate ?? "");
      }
      return b.updatedAt.localeCompare(a.updatedAt);
    });
    return rows.map((r) => r.plan);
  }

  async get(id: string) {
    return (await this.db.plans.get(id))?.plan ?? null;
  }

  async create(plan: LessonPlan) {
    await this.db.plans.put(toCached(plan, this.isDemo));
    if (!this.isDemo) {
      await enqueue(this.isDemo, {
        entityType: "lesson-plan", entityId: plan.id,
        operation: "create", baseVersion: 0, payload: plan,
      });
    }
    return plan;
  }

  async update(id: string, plan: LessonPlan, note?: string) {
    const existing = await this.db.plans.get(id);
    const next: LessonPlan = {
      ...plan,
      versionNumber: (existing?.plan.versionNumber ?? 1) + 1,
      updatedAt: new Date().toISOString(),
    };
    await this.db.plans.put({
      ...toCached(next, this.isDemo),
      baseVersion: existing?.baseVersion ?? next.versionNumber,
    });
    if (!this.isDemo) {
      await enqueue(this.isDemo, {
        entityType: "lesson-plan", entityId: id, operation: "update",
        baseVersion: existing?.baseVersion ?? 0, payload: { plan: next, note },
      });
    }
    return next;
  }

  async duplicate(id: string) {
    const source = await this.get(id);
    if (!source) throw new Error("That plan is not on this device.");
    const copy: LessonPlan = {
      ...source,
      id: crypto.randomUUID(),
      originPlanId: source.id,
      title: `${source.title} (copy)`,
      status: "draft",
      visibility: "private",
      versionNumber: 1,
      isFavourite: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    return this.create(copy);
  }

  async archive(id: string, archived: boolean) {
    const row = await this.db.plans.get(id);
    if (!row) return;
    const plan: LessonPlan = {
      ...row.plan,
      status: archived ? "archived" : "ready",
      archivedAt: archived ? new Date().toISOString() : null,
      updatedAt: new Date().toISOString(),
    };
    await this.db.plans.put({ ...toCached(plan, this.isDemo), isArchived: archived ? 1 : 0 });
  }

  async remove(id: string) {
    await this.db.plans.delete(id);
  }

  async setFavourite(id: string, value: boolean) {
    const row = await this.db.plans.get(id);
    if (!row) return;
    await this.db.plans.put({
      ...row, isFavourite: value ? 1 : 0,
      plan: { ...row.plan, isFavourite: value },
    });
  }

  async setPinnedOffline(id: string, value: boolean) {
    const row = await this.db.plans.get(id);
    if (!row) return;
    await this.db.plans.put({
      ...row, isPinnedOffline: value ? 1 : 0,
      plan: { ...row.plan, isPinnedOffline: value },
    });
  }

  /**
   * Version checkpoints, stored in the kv table.
   * A restore creates a NEW version rather than rewinding history, so a
   * teacher can always get back to what they had before restoring.
   */
  async versions(id: string) {
    const entry = await this.db.kv.get(`versions:${id}`);
    return (entry?.value as Array<{ id: string; versionNumber: number; reason: string; createdAt: string }>) ?? [];
  }

  async restoreVersion(planId: string, versionId: string) {
    const entry = await this.db.kv.get(`snapshot:${versionId}`);
    if (!entry) throw new Error("That version is not stored on this device.");
    const snapshot = entry.value as LessonPlan;
    return this.update(planId, { ...snapshot, id: planId });
  }

  async checkpoint(plan: LessonPlan, reason: string) {
    const versionId = crypto.randomUUID();
    const list = await this.versions(plan.id);
    await this.db.kv.put({ key: `snapshot:${versionId}`, value: plan });
    await this.db.kv.put({
      key: `versions:${plan.id}`,
      value: [
        { id: versionId, versionNumber: plan.versionNumber, reason, createdAt: new Date().toISOString() },
        ...list,
      ].slice(0, 20),
    });
  }
}

class LocalDraftRepository implements DraftRepository {
  constructor(private readonly isDemo: boolean) {}
  async save(draft: WizardDraft) { await dbFor(this.isDemo).drafts.put(draft); }
  async load() {
    const all = await dbFor(this.isDemo).drafts.orderBy("updatedAt").reverse().toArray();
    return all[0] ?? null;
  }
  async clear() { await dbFor(this.isDemo).drafts.clear(); }
}

class LocalTeachRepository implements TeachRepository {
  constructor(private readonly isDemo: boolean) {}
  async saveDraft(draft: TeachDraft) { await dbFor(this.isDemo).teachDrafts.put(draft); }
  async loadDraft(planId: string) {
    const rows = await dbFor(this.isDemo).teachDrafts.where("planId").equals(planId).toArray();
    return rows[0] ?? null;
  }
  async finish(draft: TeachDraft) {
    const db = dbFor(this.isDemo);
    await db.teachDrafts.put(draft);
    const row = await db.plans.get(draft.planId);
    if (row) {
      await db.plans.put({
        ...row, status: "taught",
        plan: { ...row.plan, status: "taught", lastTaughtAt: new Date().toISOString() },
      });
    }
    await db.kv.put({ key: `teach:${draft.planId}:${Date.now()}`, value: draft });
  }
}

class LocalReflectionRepository implements ReflectionRepository {
  constructor(private readonly isDemo: boolean) {}
  async save(input: ReflectionInput) {
    await dbFor(this.isDemo).kv.put({ key: `reflection:${input.planId}:${Date.now()}`, value: input });
  }
  async listForPlan(planId: string) {
    const all = await dbFor(this.isDemo).kv.toArray();
    return all
      .filter((e) => e.key.startsWith(`reflection:${planId}:`))
      .map((e) => e.value as ReflectionInput);
  }
}

/**
 * Analytics derived from the records actually stored on this device.
 *
 * In demo mode the underlying records are prepared fixtures, so `isDemoData`
 * is true and every surface that renders these numbers must label them. There
 * is no hard-coded metric anywhere: delete the fixtures and the numbers go to
 * zero, which is the honest result.
 */
class LocalAnalyticsRepository implements AnalyticsRepository {
  constructor(private readonly isDemo: boolean) {}

  async summary(rangeDays: number): Promise<AnalyticsSummary> {
    const db = dbFor(this.isDemo);
    const cutoff = new Date(Date.now() - rangeDays * 86400000).toISOString();
    const rows = (await db.plans.toArray()).filter((r) => r.plan.createdAt >= cutoff);

    const settings = (await db.kv.get("settings"))?.value as TeacherSettings | undefined;
    const baseline = settings?.baselinePlanningMinutes ?? 30;

    const kv = await db.kv.toArray();
    const teachSessions = kv.filter((e) => e.key.startsWith("teach:")).map((e) => e.value as TeachDraft);
    const reflections = kv.filter((e) => e.key.startsWith("reflection:"));
    const exports = kv.filter((e) => e.key.startsWith("event:plan_exported")).length;

    const tally = (key: keyof TeachDraft) =>
      teachSessions.reduce((sum, s) => sum + (Number(s[key]) || 0), 0);

    const count = <T extends string | number>(items: T[]) => {
      const map = new Map<T, number>();
      items.forEach((i) => map.set(i, (map.get(i) ?? 0) + 1));
      return [...map.entries()];
    };

    const grounded = rows.filter((r) => r.plan.groundingLevel !== "ungrounded").length;

    return {
      rangeDays,
      plansCreated: rows.length,
      plansTaught: rows.filter((r) => r.status === "taught").length,
      plansReused: rows.filter((r) => r.plan.originPlanId).length,
      offlinePinnedPlans: rows.filter((r) => r.isPinnedOffline === 1).length,
      exportCount: exports,
      // Explicitly an ESTIMATE. Labelled as such wherever it is shown.
      estimatedMinutesSaved: Math.max(0, rows.length * (baseline - 2)),
      groundingCoveragePercent: rows.length ? Math.round((grounded / rows.length) * 100) : 0,
      reflectionCompletionPercent: teachSessions.length
        ? Math.round((reflections.length / teachSessions.length) * 100)
        : 0,
      learnerOutcomes: {
        total: tally("attendanceCount"),
        met: tally("metObjectiveCount"),
        partial: tally("partiallyMetCount"),
        support: tally("needsSupportCount"),
      },
      bySubject: count(rows.map((r) => r.subject)).map(([subject, c]) => ({ subject, count: c })),
      byGrade: count(rows.flatMap((r) => r.grades)).map(([grade, c]) => ({ grade, count: c })),
      byLanguage: count(rows.map((r) => r.outputLanguage)).map(([language, c]) => ({ language, count: c })),
      isDemoData: this.isDemo,
    };
  }

  async record(name: string, planId?: string, metadata?: Record<string, string | number | boolean>) {
    await dbFor(this.isDemo).kv.put({
      key: `event:${name}:${Date.now()}`,
      value: { name, planId, metadata, at: new Date().toISOString() },
    });
  }
}

class LocalCommunityRepository implements CommunityRepository {
  constructor(private readonly isDemo: boolean) {}
  private get db() { return dbFor(this.isDemo); }

  async browse(filters: { search?: string; subject?: string; grade?: number }) {
    const entry = await this.db.kv.get("community");
    let items = ((entry?.value as CommunityItem[]) ?? []).filter((i) => i.status === "approved");
    if (filters.subject) items = items.filter((i) => i.subject === filters.subject);
    if (filters.grade) items = items.filter((i) => i.grades.includes(filters.grade!));
    if (filters.search) {
      const q = filters.search.toLowerCase();
      items = items.filter((i) => i.title.toLowerCase().includes(q) || i.summary.toLowerCase().includes(q));
    }
    return items;
  }

  async get(id: string) {
    const items = ((await this.db.kv.get("community"))?.value as CommunityItem[]) ?? [];
    const item = items.find((i) => i.id === id);
    if (!item) return null;
    const snap = await this.db.kv.get(`community-plan:${id}`);
    if (!snap) return null;
    return { item, plan: snap.value as LessonPlan };
  }

  async clone(id: string) {
    const found = await this.get(id);
    if (!found) throw new Error("That template is not available.");
    const copy: LessonPlan = {
      ...found.plan,
      id: crypto.randomUUID(),
      originPlanId: found.plan.id,
      ownerId: null,
      title: found.item.title,
      status: "draft",
      visibility: "private",
      versionNumber: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await this.db.plans.put(toCached(copy, this.isDemo));
    const items = ((await this.db.kv.get("community"))?.value as CommunityItem[]) ?? [];
    await this.db.kv.put({
      key: "community",
      value: items.map((i) => (i.id === id ? { ...i, cloneCount: i.cloneCount + 1 } : i)),
    });
    return copy;
  }

  async submit(planId: string, summary: string) {
    const plan = (await this.db.plans.get(planId))?.plan;
    if (!plan) throw new Error("Plan not found.");
    const items = ((await this.db.kv.get("community"))?.value as CommunityItem[]) ?? [];
    const item: CommunityItem = {
      id: crypto.randomUUID(), title: plan.title, summary,
      grades: plan.brief.grades, subject: plan.brief.subject,
      outputLanguage: plan.brief.outputLanguage, authorName: "You",
      licence: "CC-BY-4.0", status: "pending", cloneCount: 0,
      createdAt: new Date().toISOString(), isDemoData: this.isDemo,
    };
    await this.db.kv.put({ key: "community", value: [item, ...items] });
    await this.db.kv.put({ key: `community-plan:${item.id}`, value: plan });
  }

  async withdraw(publicationId: string) {
    const items = ((await this.db.kv.get("community"))?.value as CommunityItem[]) ?? [];
    await this.db.kv.put({
      key: "community",
      value: items.map((i) => (i.id === publicationId ? { ...i, status: "withdrawn" as const } : i)),
    });
  }

  async report(publicationId: string, reason: string) {
    await this.db.kv.put({ key: `report:${publicationId}:${Date.now()}`, value: { reason } });
  }

  async mine() {
    const items = ((await this.db.kv.get("community"))?.value as CommunityItem[]) ?? [];
    return items.filter((i) => i.authorName === "You");
  }
}

class LocalCurriculumRepository implements CurriculumRepository {
  constructor(private readonly isDemo: boolean) {}
  async sources() {
    const entry = await dbFor(this.isDemo).kv.get("curriculum-sources");
    return (entry?.value as Awaited<ReturnType<CurriculumRepository["sources"]>>) ?? [];
  }
  async setStatus(id: string, status: string) {
    const db = dbFor(this.isDemo);
    const list = ((await db.kv.get("curriculum-sources"))?.value as Array<{ id: string; status: string }>) ?? [];
    await db.kv.put({
      key: "curriculum-sources",
      value: list.map((s) => (s.id === id ? { ...s, status } : s)),
    });
  }
}

class LocalNotificationRepository implements NotificationRepository {
  constructor(private readonly isDemo: boolean) {}
  private get db() { return dbFor(this.isDemo); }
  async list() {
    return ((await this.db.kv.get("notifications"))?.value as Awaited<ReturnType<NotificationRepository["list"]>>) ?? [];
  }
  async markRead(id: string) {
    const list = await this.list();
    await this.db.kv.put({
      key: "notifications",
      value: list.map((n) => (n.id === id ? { ...n, readAt: new Date().toISOString() } : n)),
    });
  }
  async markAllRead() {
    const list = await this.list();
    const now = new Date().toISOString();
    await this.db.kv.put({ key: "notifications", value: list.map((n) => ({ ...n, readAt: n.readAt ?? now })) });
  }
}

class LocalSettingsRepository implements SettingsRepository {
  constructor(private readonly isDemo: boolean) {}
  async get() {
    return ((await dbFor(this.isDemo).kv.get("settings"))?.value as TeacherSettings) ?? null;
  }
  async save(settings: TeacherSettings) {
    await dbFor(this.isDemo).kv.put({ key: "settings", value: settings });
  }
}

/**
 * Local share links.
 *
 * In demo mode a share is a local record only -- there is no server to serve
 * it from, so the dialog says so plainly rather than handing the teacher a URL
 * that will not open.
 */
class LocalShareRepository implements ShareRepository {
  constructor(private readonly isDemo: boolean) {}
  private get db() { return dbFor(this.isDemo); }

  async create(planId: string) {
    const token = crypto.randomUUID().replace(/-/g, "");
    const list = ((await this.db.kv.get(`shares:${planId}`))?.value as Array<{ id: string; url: string; isActive: boolean; createdAt: string }>) ?? [];
    const url = `${window.location.origin}/share/${token}`;
    await this.db.kv.put({
      key: `shares:${planId}`,
      value: [{ id: crypto.randomUUID(), url, isActive: true, createdAt: new Date().toISOString() }, ...list],
    });
    await this.db.kv.put({ key: `share-token:${token}`, value: planId });
    return { url, token };
  }

  async listForPlan(planId: string) {
    return ((await this.db.kv.get(`shares:${planId}`))?.value as Array<{ id: string; url: string; isActive: boolean; createdAt: string }>) ?? [];
  }

  async revoke(shareId: string) {
    const all = await this.db.kv.toArray();
    for (const entry of all.filter((e) => e.key.startsWith("shares:"))) {
      const list = entry.value as Array<{ id: string; isActive: boolean }>;
      if (list.some((s) => s.id === shareId)) {
        await this.db.kv.put({
          key: entry.key,
          value: list.map((s) => (s.id === shareId ? { ...s, isActive: false } : s)),
        });
      }
    }
  }
}

class LocalSyncRepository implements SyncRepository {
  constructor(private readonly isDemo: boolean) {}
  async conflicts() { return openConflicts(this.isDemo); }
  async pendingCount() { return pendingCount(this.isDemo); }
  async flush() {
    // Demo mode is authoritative locally; there is nothing to push.
    if (this.isDemo) return { pushed: 0, conflicts: 0, failed: 0 };
    const result = await flushQueue(this.isDemo, {
      fetchVersion: async () => null,
      push: async () => { throw new Error("No backend configured yet."); },
      fetchPlan: async () => null,
    });
    return { pushed: result.pushed, conflicts: result.conflicts, failed: result.failed };
  }
}

export function createLocalRepositories(isDemo: boolean): Repositories {
  return {
    mode: isDemo ? "demo" : "production",
    plans: new LocalPlanRepository(isDemo),
    drafts: new LocalDraftRepository(isDemo),
    teach: new LocalTeachRepository(isDemo),
    reflections: new LocalReflectionRepository(isDemo),
    analytics: new LocalAnalyticsRepository(isDemo),
    community: new LocalCommunityRepository(isDemo),
    curriculum: new LocalCurriculumRepository(isDemo),
    notifications: new LocalNotificationRepository(isDemo),
    settings: new LocalSettingsRepository(isDemo),
    shares: new LocalShareRepository(isDemo),
    sync: new LocalSyncRepository(isDemo),
  };
}

export { LocalPlanRepository };
