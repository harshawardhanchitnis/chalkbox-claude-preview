import Dexie, { type Table } from "dexie";
import type { LessonPlan, PlanBrief } from "@chalkbox/contracts";

/**
 * Offline store.
 *
 * Every plan is written here the moment it exists, before anything else
 * happens to it. That is what makes ChalkBox usable in a school with no
 * signal: the plan made last night at home is on the phone this morning.
 *
 * Demo data lives in a SEPARATE Dexie database. Resetting the demo drops that
 * database only and can never touch a registered teacher's real work.
 */

export interface CachedPlan {
  id: string;
  ownerId: string | null;
  title: string;
  grades: number[];
  subject: string;
  status: string;
  outputLanguage: string;
  durationMinutes: number;
  updatedAt: string;
  isFavourite: 0 | 1;
  isPinnedOffline: 0 | 1;
  isArchived: 0 | 1;
  isDemo: 0 | 1;
  /** Local edits not yet accepted by the server. */
  dirty: 0 | 1;
  /** Server version this local copy was derived from; drives conflict checks. */
  baseVersion: number;
  plan: LessonPlan;
}

export interface WizardDraft {
  id: string;
  updatedAt: string;
  step: number;
  brief: Partial<PlanBrief>;
}

export type MutationOp = "create" | "update" | "archive" | "delete" | "teach" | "reflect";

export interface OfflineMutation {
  id?: number;
  entityType: "lesson-plan" | "teach-session" | "reflection";
  entityId: string;
  operation: MutationOp;
  baseVersion: number;
  payload: unknown;
  queuedAt: string;
  retryCount: number;
  lastError?: string;
}

export interface ConflictRecord {
  id: string;
  planId: string;
  detectedAt: string;
  localPlan: LessonPlan;
  remotePlan: LessonPlan;
  resolved: 0 | 1;
}

export interface TeachDraft {
  id: string;
  planId: string;
  updatedAt: string;
  currentStepId: string | null;
  completedStepIds: string[];
  elapsedSeconds: number;
  attendanceCount?: number;
  metObjectiveCount?: number;
  partiallyMetCount?: number;
  needsSupportCount?: number;
  engagementRating?: number;
  completedAsPlanned?: boolean;
}

export interface KeyValue { key: string; value: unknown }

class ChalkBoxDB extends Dexie {
  plans!: Table<CachedPlan, string>;
  drafts!: Table<WizardDraft, string>;
  queue!: Table<OfflineMutation, number>;
  conflicts!: Table<ConflictRecord, string>;
  teachDrafts!: Table<TeachDraft, string>;
  kv!: Table<KeyValue, string>;

  constructor(name: string) {
    super(name);
    this.version(1).stores({
      plans: "id, ownerId, updatedAt, subject, status, isFavourite, isPinnedOffline, isArchived, dirty",
      drafts: "id, updatedAt",
      queue: "++id, entityId, queuedAt",
      conflicts: "id, planId, resolved",
      teachDrafts: "id, planId, updatedAt",
      kv: "key",
    });
  }
}

export const liveDB = new ChalkBoxDB("chalkbox");
export const demoDB = new ChalkBoxDB("chalkbox-demo");

export function dbFor(isDemo: boolean): ChalkBoxDB {
  return isDemo ? demoDB : liveDB;
}

/** Drops demo data only. A registered teacher's plans are in a different DB. */
export async function resetDemoDatabase(): Promise<void> {
  await demoDB.delete();
  await demoDB.open();
}

export async function estimateStorage(): Promise<{ usedMB: number; quotaMB: number } | null> {
  if (!navigator.storage?.estimate) return null;
  const { usage = 0, quota = 0 } = await navigator.storage.estimate();
  return { usedMB: +(usage / 1048576).toFixed(1), quotaMB: +(quota / 1048576).toFixed(0) };
}
