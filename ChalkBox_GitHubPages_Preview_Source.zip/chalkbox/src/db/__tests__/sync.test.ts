import { describe, expect, it } from "vitest";
import { isConflict } from "../sync";

/**
 * Conflict detection is the rule that protects a teacher's work, so it is
 * tested on its own, without a database or a network.
 */
describe("offline conflict detection", () => {
  it("reports no conflict when the server has not moved on", () => {
    expect(isConflict(4, 4)).toBe(false);
  });

  it("reports a conflict when the server moved ahead", () => {
    expect(isConflict(4, 7)).toBe(true);
  });

  it("reports a conflict when the server is behind, rather than assuming", () => {
    // A lower remote version means something is wrong; we stop and ask.
    expect(isConflict(7, 4)).toBe(true);
  });

  it("treats a plan that does not exist remotely as safe to create", () => {
    expect(isConflict(0, null)).toBe(false);
    expect(isConflict(5, null)).toBe(false);
  });
});
