import type { LessonPlan } from "@chalkbox/contracts";
import { dbFor, type ConflictRecord, type OfflineMutation } from "./dexie";

/**
 * The offline mutation queue.
 *
 * Rules, in order of importance:
 *
 *  1. Never silently overwrite. If the server moved on since this device last
 *     saw the plan, we stop and record a conflict for the teacher to resolve.
 *  2. Preserve order. Mutations replay oldest-first and the queue halts on the
 *     first failure, so a later edit can never land before an earlier one.
 *  3. Survive a closed tab. Everything lives in IndexedDB, not memory.
 */

export interface PushResult {
  pushed: number;
  conflicts: number;
  failed: number;
  stoppedEarly: boolean;
}

export interface RemoteAdapter {
  /** Current server version of a plan, or null when it does not exist yet. */
  fetchVersion(planId: string): Promise<number | null>;
  push(mutation: OfflineMutation): Promise<void>;
  fetchPlan(planId: string): Promise<LessonPlan | null>;
}

export async function enqueue(
  isDemo: boolean,
  mutation: Omit<OfflineMutation, "id" | "queuedAt" | "retryCount">,
): Promise<void> {
  await dbFor(isDemo).queue.add({
    ...mutation,
    queuedAt: new Date().toISOString(),
    retryCount: 0,
  });
}

export async function pendingCount(isDemo: boolean): Promise<number> {
  return dbFor(isDemo).queue.count();
}

/**
 * Detects whether the server has moved on from the version this device edited.
 * Exported separately so it can be unit-tested without a network.
 */
export function isConflict(baseVersion: number, remoteVersion: number | null): boolean {
  if (remoteVersion === null) return false; // nothing remote to conflict with
  return remoteVersion !== baseVersion;
}

export async function flushQueue(
  isDemo: boolean,
  remote: RemoteAdapter,
): Promise<PushResult> {
  const db = dbFor(isDemo);
  const items = await db.queue.orderBy("queuedAt").toArray();
  const result: PushResult = { pushed: 0, conflicts: 0, failed: 0, stoppedEarly: false };

  for (const item of items) {
    try {
      const remoteVersion = await remote.fetchVersion(item.entityId);

      if (isConflict(item.baseVersion, remoteVersion)) {
        const [localCached, remotePlan] = await Promise.all([
          db.plans.get(item.entityId),
          remote.fetchPlan(item.entityId),
        ]);
        if (localCached && remotePlan) {
          const conflict: ConflictRecord = {
            id: `conflict_${item.entityId}`,
            planId: item.entityId,
            detectedAt: new Date().toISOString(),
            localPlan: localCached.plan,
            remotePlan,
            resolved: 0,
          };
          await db.conflicts.put(conflict);
        }
        // Leave the mutation queued. It is replayed only after the teacher
        // decides; nothing is discarded and nothing is overwritten.
        result.conflicts += 1;
        result.stoppedEarly = true;
        break;
      }

      await remote.push(item);
      if (item.id !== undefined) await db.queue.delete(item.id);

      const cached = await db.plans.get(item.entityId);
      if (cached) {
        await db.plans.put({
          ...cached,
          dirty: 0,
          baseVersion: (remoteVersion ?? cached.baseVersion) + 1,
        });
      }
      result.pushed += 1;
    } catch (err) {
      // Still offline, or the server rejected it. Record and stop so ordering
      // is preserved; the next reconnect resumes from exactly here.
      if (item.id !== undefined) {
        await db.queue.update(item.id, {
          retryCount: item.retryCount + 1,
          lastError: err instanceof Error ? err.message : "unknown",
        });
      }
      result.failed += 1;
      result.stoppedEarly = true;
      break;
    }
  }
  return result;
}

export type ConflictResolution = "keep-local" | "keep-remote" | "keep-both";

export async function resolveConflict(
  isDemo: boolean,
  conflictId: string,
  resolution: ConflictResolution,
  duplicate?: (plan: LessonPlan) => Promise<void>,
): Promise<void> {
  const db = dbFor(isDemo);
  const conflict = await db.conflicts.get(conflictId);
  if (!conflict) return;

  if (resolution === "keep-remote") {
    // Discard local edits: drop the queued mutations for this plan and take
    // the server copy.
    const queued = await db.queue.where("entityId").equals(conflict.planId).toArray();
    await Promise.all(queued.map((q) => (q.id !== undefined ? db.queue.delete(q.id) : undefined)));
    const cached = await db.plans.get(conflict.planId);
    if (cached) {
      await db.plans.put({
        ...cached,
        plan: conflict.remotePlan,
        dirty: 0,
        baseVersion: conflict.remotePlan.versionNumber,
        updatedAt: conflict.remotePlan.updatedAt,
      });
    }
  }

  if (resolution === "keep-local") {
    // Rebase the queued mutations onto the server's current version so the
    // next flush applies cleanly instead of conflicting again.
    const queued = await db.queue.where("entityId").equals(conflict.planId).toArray();
    await Promise.all(
      queued.map((q) =>
        q.id !== undefined
          ? db.queue.update(q.id, { baseVersion: conflict.remotePlan.versionNumber })
          : undefined,
      ),
    );
    const cached = await db.plans.get(conflict.planId);
    if (cached) {
      await db.plans.put({ ...cached, baseVersion: conflict.remotePlan.versionNumber });
    }
  }

  if (resolution === "keep-both" && duplicate) {
    await duplicate(conflict.localPlan);
    const cached = await db.plans.get(conflict.planId);
    if (cached) {
      await db.plans.put({
        ...cached,
        plan: conflict.remotePlan,
        dirty: 0,
        baseVersion: conflict.remotePlan.versionNumber,
      });
    }
    const queued = await db.queue.where("entityId").equals(conflict.planId).toArray();
    await Promise.all(queued.map((q) => (q.id !== undefined ? db.queue.delete(q.id) : undefined)));
  }

  await db.conflicts.put({ ...conflict, resolved: 1 });
}

export async function openConflicts(isDemo: boolean): Promise<ConflictRecord[]> {
  return dbFor(isDemo).conflicts.filter((c) => c.resolved === 0).toArray();
}
