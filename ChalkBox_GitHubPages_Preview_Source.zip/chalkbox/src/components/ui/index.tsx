import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * UI primitives.
 *
 * Deliberately small and hand-written rather than 60 generated files. Every
 * component here is used somewhere in the product; nothing is decorative.
 * Accessibility is built in rather than retrofitted: labels are associated,
 * errors are announced, icon-only controls carry names.
 */

export const Button = React.forwardRef<
  HTMLButtonElement,
  React.ButtonHTMLAttributes<HTMLButtonElement> & {
    variant?: "primary" | "secondary" | "ghost" | "danger";
    size?: "default" | "sm";
    loading?: boolean;
  }
>(({ className, variant = "primary", size = "default", loading, children, disabled, ...props }, ref) => (
  <button
    ref={ref}
    disabled={disabled || loading}
    aria-busy={loading || undefined}
    className={cn(
      variant === "primary" && "btn-primary",
      variant === "secondary" && "btn-secondary",
      variant === "ghost" && "btn-ghost",
      variant === "danger" && "btn-danger",
      size === "sm" && "btn-sm",
      className,
    )}
    {...props}
  >
    {loading && <Spinner className="h-4 w-4" />}
    {children}
  </button>
));
Button.displayName = "Button";

export function Spinner({ className }: { className?: string }) {
  return (
    <svg className={cn("animate-spin", className)} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" opacity="0.25" />
      <path d="M12 2a10 10 0 0 1 10 10" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export const Input = React.forwardRef<
  HTMLInputElement,
  React.InputHTMLAttributes<HTMLInputElement> & { invalid?: boolean }
>(({ className, invalid, ...props }, ref) => (
  <input ref={ref} aria-invalid={invalid || undefined}
    className={cn("field", invalid && "field-error", className)} {...props} />
));
Input.displayName = "Input";

export const Textarea = React.forwardRef<
  HTMLTextAreaElement,
  React.TextareaHTMLAttributes<HTMLTextAreaElement> & { invalid?: boolean }
>(({ className, invalid, ...props }, ref) => (
  <textarea ref={ref} aria-invalid={invalid || undefined}
    className={cn("field min-h-[92px] resize-y", invalid && "field-error", className)} {...props} />
));
Textarea.displayName = "Textarea";

export const Select = React.forwardRef<
  HTMLSelectElement,
  React.SelectHTMLAttributes<HTMLSelectElement>
>(({ className, children, ...props }, ref) => (
  <select ref={ref} className={cn("field", className)} {...props}>{children}</select>
));
Select.displayName = "Select";

export function Field({
  label, hint, error, htmlFor, children, required,
}: {
  label: string; hint?: string; error?: string; htmlFor: string;
  children: React.ReactNode; required?: boolean;
}) {
  const errorId = `${htmlFor}-error`;
  const hintId = `${htmlFor}-hint`;
  return (
    <div>
      <label className="field-label" htmlFor={htmlFor}>
        {label}
        {required && <span className="ml-1 text-danger" aria-hidden>*</span>}
      </label>
      {hint && <p id={hintId} className="mb-1.5 text-sm text-muted">{hint}</p>}
      {React.isValidElement(children)
        ? React.cloneElement(children as React.ReactElement<Record<string, unknown>>, {
            id: htmlFor,
            "aria-describedby": [hint ? hintId : null, error ? errorId : null].filter(Boolean).join(" ") || undefined,
          })
        : children}
      {error && (
        <p id={errorId} role="alert" className="mt-1 text-sm font-medium text-danger">{error}</p>
      )}
    </div>
  );
}

export function Chip({
  active, children, ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { active?: boolean }) {
  return (
    <button type="button" aria-pressed={active} className={active ? "chip-on" : "chip-off"} {...props}>
      {children}
    </button>
  );
}

export function Badge({
  tone = "neutral", children, className,
}: { tone?: "neutral" | "success" | "warning" | "danger" | "info" | "accent"; children: React.ReactNode; className?: string }) {
  const tones = {
    neutral: "bg-line/60 text-ink",
    success: "bg-success/15 text-success",
    warning: "bg-warning/15 text-warning",
    danger: "bg-danger/15 text-danger",
    info: "bg-info/15 text-info",
    accent: "bg-accent/20 text-warning",
  };
  return <span className={cn("badge", tones[tone], className)}>{children}</span>;
}

export function Card({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("card", className)} {...props}>{children}</div>;
}

export function PageHeader({
  title, description, actions,
}: { title: string; description?: string; actions?: React.ReactNode }) {
  return (
    <header className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight sm:text-3xl">{title}</h1>
        {description && <p className="mt-1 max-w-read text-muted">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </header>
  );
}

export function EmptyState({
  title, description, action, icon,
}: { title: string; description?: string; action?: React.ReactNode; icon?: React.ReactNode }) {
  return (
    <div className="card flex flex-col items-center px-6 py-14 text-center">
      {icon && <div className="mb-3 text-muted" aria-hidden>{icon}</div>}
      <h2 className="font-display text-lg font-semibold">{title}</h2>
      {description && <p className="mx-auto mt-1 max-w-sm text-muted">{description}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function InlineError({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="rounded-card border border-danger/40 bg-danger/5 px-4 py-3">
      <p className="text-sm text-danger">{message}</p>
      {onRetry && (
        <Button variant="secondary" size="sm" className="mt-2" onClick={onRetry}>Try again</Button>
      )}
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("skeleton", className)} aria-hidden />;
}

export function PlanSkeleton() {
  return (
    <div className="space-y-3" role="status" aria-label="Loading">
      <Skeleton className="h-8 w-2/3" />
      <Skeleton className="h-4 w-1/2" />
      <Skeleton className="h-40 w-full" />
      <Skeleton className="h-32 w-full" />
      <span className="sr-only">Loading…</span>
    </div>
  );
}

export function Modal({
  open, onClose, title, description, children, footer,
}: {
  open: boolean; onClose: () => void; title: string; description?: string;
  children?: React.ReactNode; footer?: React.ReactNode;
}) {
  const ref = React.useRef<HTMLDivElement>(null);
  const previouslyFocused = React.useRef<Element | null>(null);

  React.useEffect(() => {
    if (!open) return;
    previouslyFocused.current = document.activeElement;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key !== "Tab" || !ref.current) return;
      // Trap focus inside the dialog.
      const focusable = ref.current.querySelectorAll<HTMLElement>(
        'button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])',
      );
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", onKey);
    ref.current?.querySelector<HTMLElement>("button,input,select,textarea")?.focus();
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
      (previouslyFocused.current as HTMLElement | null)?.focus?.();
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-0 sm:items-center sm:p-4">
      <div className="absolute inset-0" onClick={onClose} aria-hidden />
      <div
        ref={ref} role="dialog" aria-modal="true" aria-labelledby="modal-title"
        className="relative w-full max-w-lg rounded-t-panel border border-line bg-surface p-5 shadow-lift sm:rounded-panel"
      >
        <h2 id="modal-title" className="font-display text-lg font-bold">{title}</h2>
        {description && <p className="mt-1 text-sm text-muted">{description}</p>}
        {children && <div className="mt-4">{children}</div>}
        {footer && <div className="mt-5 flex flex-wrap justify-end gap-2">{footer}</div>}
      </div>
    </div>
  );
}

/** Table equivalent for every chart, so data is never colour- or vision-only. */
export function AccessibleChartTable({
  caption, columns, rows,
}: { caption: string; columns: string[]; rows: Array<Array<string | number>> }) {
  return (
    <details className="mt-3">
      <summary className="cursor-pointer text-sm text-muted underline underline-offset-4">
        View this chart as a table
      </summary>
      <table className="mt-2 w-full text-sm">
        <caption className="sr-only">{caption}</caption>
        <thead>
          <tr className="border-b border-line text-left">
            {columns.map((c) => <th key={c} scope="col" className="py-1.5 font-semibold">{c}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-b border-line/60">
              {r.map((cell, j) => <td key={j} className="py-1.5">{cell}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </details>
  );
}
