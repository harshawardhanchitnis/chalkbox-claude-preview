import { NavLink, Outlet, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import {
  BarChart3, BookOpen, Home, Library, Plus, Settings as SettingsIcon,
  Shield, Users, WifiOff,
} from "lucide-react";
import { useAppStore } from "@/store/app.store";
import { useConnectivity } from "@/hooks/use-connectivity";
import { useRepositories } from "@/hooks/use-repositories";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui";

const NAV = [
  { to: "/app", label: "Dashboard", icon: Home, end: true },
  { to: "/app/library", label: "My plans", icon: Library },
  { to: "/app/community", label: "Community", icon: Users },
  { to: "/app/analytics", label: "Impact", icon: BarChart3 },
  { to: "/app/settings", label: "Settings", icon: SettingsIcon },
];

export function AppShell() {
  const online = useConnectivity();
  const mode = useAppStore((s) => s.mode);
  const repos = useRepositories();
  const location = useLocation();
  const [unread, setUnread] = useState(0);
  const [pending, setPending] = useState(0);

  useEffect(() => {
    repos.notifications.list().then((n) => setUnread(n.filter((x) => !x.readAt).length)).catch(() => undefined);
    repos.sync.pendingCount().then(setPending).catch(() => undefined);
  }, [repos, location.pathname]);

  return (
    <div className="min-h-dvh bg-canvas">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-50 focus:rounded focus:bg-primary focus:px-4 focus:py-2 focus:text-white">
        Skip to content
      </a>

      {mode === "demo" && (
        <div className="bg-accent/20 px-4 py-1.5 text-center text-sm text-warning">
          <strong className="font-semibold">Demo Mode</strong> — everything you see is fictional sample data, stored only on this device.
        </div>
      )}

      <div className="mx-auto flex max-w-app">
        {/* Desktop sidebar */}
        <aside className="no-print sticky top-0 hidden h-dvh w-[248px] shrink-0 flex-col border-r border-line bg-surface px-3 py-4 lg:flex">
          <NavLink to="/app" className="mb-6 flex items-center gap-2 px-2">
            <BookOpen className="h-6 w-6 text-primary" aria-hidden />
            <span className="font-display text-lg font-bold">ChalkBox</span>
          </NavLink>

          <NavLink to="/app/plans/new" className="btn-primary mb-4 w-full">
            <Plus className="h-4 w-4" aria-hidden /> New lesson plan
          </NavLink>

          <nav aria-label="Main">
            <ul className="space-y-0.5">
              {NAV.map(({ to, label, icon: Icon, end }) => (
                <li key={to}>
                  <NavLink to={to} end={end} className={({ isActive }) => cn(
                    "flex min-h-[44px] items-center gap-3 rounded-field px-3 text-[15px] transition",
                    isActive ? "bg-primary-soft font-semibold text-primary" : "text-ink hover:bg-primary-soft/60",
                  )}>
                    <Icon className="h-[18px] w-[18px]" aria-hidden />
                    {label}
                    {label === "Community" && unread > 0 && (
                      <Badge tone="info" className="ml-auto">{unread}</Badge>
                    )}
                  </NavLink>
                </li>
              ))}
              <li>
                <NavLink to="/app/admin" className={({ isActive }) => cn(
                  "flex min-h-[44px] items-center gap-3 rounded-field px-3 text-[15px] transition",
                  isActive ? "bg-primary-soft font-semibold text-primary" : "text-muted hover:bg-primary-soft/60",
                )}>
                  <Shield className="h-[18px] w-[18px]" aria-hidden /> Admin
                </NavLink>
              </li>
            </ul>
          </nav>

          <div className="mt-auto space-y-2 px-2 pt-4 text-xs text-muted">
            {!online && (
              <p className="flex items-center gap-1.5 text-warning">
                <WifiOff className="h-3.5 w-3.5" aria-hidden /> Offline — cached plans only
              </p>
            )}
            {pending > 0 && <p>{pending} change{pending === 1 ? "" : "s"} waiting to sync</p>}
            <p>ChalkBox · Team HarshLabs</p>
          </div>
        </aside>

        <div className="min-w-0 flex-1">
          {/* Mobile top bar */}
          <header className="no-print sticky top-0 z-20 flex items-center gap-3 border-b border-line bg-canvas/95 px-4 py-3 backdrop-blur lg:hidden">
            <NavLink to="/app" className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-primary" aria-hidden />
              <span className="font-display text-base font-bold">ChalkBox</span>
            </NavLink>
            {!online && (
              <span className="ml-auto flex items-center gap-1 rounded-full border border-warning/40 px-2 py-0.5 text-xs text-warning">
                <WifiOff className="h-3 w-3" aria-hidden /> Offline
              </span>
            )}
          </header>

          <main id="main" className="px-4 pb-28 pt-5 sm:px-6 lg:pb-12 lg:pt-8">
            <Outlet />
          </main>
        </div>
      </div>

      {/* Mobile bottom navigation */}
      <nav aria-label="Main" className="no-print fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface lg:hidden">
        <ul className="mx-auto flex max-w-md">
          {NAV.slice(0, 3).map(({ to, label, icon: Icon, end }) => (
            <li key={to} className="flex-1">
              <NavLink to={to} end={end} className={({ isActive }) => cn(
                "flex min-h-[56px] flex-col items-center justify-center gap-0.5 text-[11px]",
                isActive ? "font-semibold text-primary" : "text-muted",
              )}>
                <Icon className="h-5 w-5" aria-hidden />
                {label}
              </NavLink>
            </li>
          ))}
          <li className="flex-1">
            <NavLink to="/app/plans/new" className="flex min-h-[56px] flex-col items-center justify-center gap-0.5 text-[11px] font-semibold text-primary">
              <Plus className="h-5 w-5" aria-hidden /> New
            </NavLink>
          </li>
          <li className="flex-1">
            <NavLink to="/app/settings" className={({ isActive }) => cn(
              "flex min-h-[56px] flex-col itemsically justify-center gap-0.5 text-[11px]",
              isActive ? "font-semibold text-primary" : "text-muted",
            )}>
              <SettingsIcon className="h-5 w-5" aria-hidden /> Settings
            </NavLink>
          </li>
        </ul>
      </nav>
    </div>
  );
}
