import { Component, type ErrorInfo, type ReactNode } from "react";
import { useRouteError, isRouteErrorResponse, Link } from "react-router-dom";

export function RouteErrorBoundary() {
  const error = useRouteError();
  const is404 = isRouteErrorResponse(error) && error.status === 404;
  return (
    <div className="mx-auto flex min-h-dvh max-w-read flex-col items-center justify-center px-6 text-center">
      <h1 className="font-display text-3xl font-bold">
        {is404 ? "That page does not exist" : "Something went wrong"}
      </h1>
      <p className="mt-2 text-muted">
        {is404
          ? "The link may be out of date."
          : "The page failed to load. Your saved plans are safe on this device."}
      </p>
      <div className="mt-6 flex gap-3">
        <Link to="/app" className="btn-primary">Go to dashboard</Link>
        <button className="btn-secondary" onClick={() => window.location.reload()}>Reload</button>
      </div>
    </div>
  );
}

interface State { hasError: boolean; message?: string }

export class ErrorBoundary extends Component<{ children: ReactNode }, State> {
  state: State = { hasError: false };
  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message };
  }
  componentDidCatch(error: Error, info: ErrorInfo) {
    // No third-party telemetry by design; console only.
    console.error("ChalkBox error boundary", error, info.componentStack);
  }
  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <div role="alert" className="card m-4 p-6 text-center">
        <h2 className="font-display text-lg font-bold">This section could not load</h2>
        <p className="mt-1 text-sm text-muted">{this.state.message}</p>
        <button className="btn-secondary mt-4" onClick={() => this.setState({ hasError: false })}>
          Try again
        </button>
      </div>
    );
  }
}
