import { create } from "zustand";
import { persist } from "zustand/middleware";

export type AppMode = "production" | "demo";

interface AppState {
  mode: AppMode;
  sidebarOpen: boolean;
  theme: "light" | "dark" | "system";
  online: boolean;
  installPromptDismissed: boolean;
  setMode: (mode: AppMode) => void;
  setSidebarOpen: (open: boolean) => void;
  setTheme: (theme: AppState["theme"]) => void;
  setOnline: (online: boolean) => void;
  dismissInstallPrompt: () => void;
}

/**
 * UI shell state only.
 *
 * Lesson plans deliberately never live here -- they belong to the repository
 * layer and IndexedDB. Persisting a plan into localStorage would break offline
 * correctness and blow the storage quota on a low-end phone.
 */
export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      mode: "demo",
      sidebarOpen: false,
      theme: "system",
      online: typeof navigator === "undefined" ? true : navigator.onLine,
      installPromptDismissed: false,
      setMode: (mode) => set({ mode }),
      setSidebarOpen: (sidebarOpen) => set({ sidebarOpen }),
      setTheme: (theme) => set({ theme }),
      setOnline: (online) => set({ online }),
      dismissInstallPrompt: () => set({ installPromptDismissed: true }),
    }),
    {
      name: "chalkbox-ui",
      // Only small UI preferences are persisted. Never domain data.
      partialize: (s) => ({
        mode: s.mode, theme: s.theme, installPromptDismissed: s.installPromptDismissed,
      }),
    },
  ),
);
