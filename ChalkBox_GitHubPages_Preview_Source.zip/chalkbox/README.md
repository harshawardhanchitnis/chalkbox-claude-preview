# ChalkBox

**Your classroom. Your plan.**

Omnikon National Hackathon 2026 · Team HarshLabs · `Omni_EdTech_7`

A teacher picks their classes in three taps. ChalkBox returns a minute-by-minute,
curriculum-grounded lesson plan — in Hindi or English, using only the materials
that teacher actually has, split across every class sitting in the room, and
available offline on a low-end phone.

---

## What makes it different

Most AI planning tools are a prompt box in front of a language model. ChalkBox
puts three deterministic layers around the model.

**1. A constraint solver runs before any text is generated.**
`packages/contracts/src/constraints.ts` computes the lesson timetable — how the
minutes divide, which class holds the teacher's attention in each window, what
the other classes do while they wait. The model fills that skeleton in; it does
not invent it. The guarantee that one teacher cannot instruct two classes at
once is arithmetic, not a hope that the model remembered. *10 unit tests across
60 duration/class combinations.*

**2. Generation is grounded in a real curriculum corpus.**
Hybrid retrieval (pgvector + Postgres full-text, fused with Reciprocal Rank
Fusion) pulls actual passages, and every plan carries citations the teacher can
open. A plan that cites nothing is labelled **ungrounded** rather than passed off
as sourced.

**3. Eight checks run before the teacher sees anything.**
Placeholders, timing, single-teacher attention, materials, objectives,
multigrade coverage, output script and citation integrity. A plan that fails
gets one repair pass; if it still fails, the teacher is told what is wrong
rather than shown a plausible-looking lesson.

Everything is offline-first. Plans are written to IndexedDB the moment they
exist; edits queue while offline and never silently overwrite on reconnect.

---

## Architecture

```
Teacher (React 19 PWA, IndexedDB)
      │
      ▼
Supabase Edge Function `lesson-ai`   ← the only place the Gemini key exists
      │
      ├──► constraint solver          deterministic skeleton
      ├──► hybrid retrieval           pgvector + full-text, RRF fused
      ├──► Gemini structured output   JSON against the shared Zod contract
      └──► readiness checks           8 deterministic validators
                    │
            one repair pass on failure
                    │
        Supabase Postgres (RLS) + IndexedDB mirror
```

The plan object (`packages/contracts/src/lesson-plan.schema.ts`) is the centre
of the system. The model emits exactly that shape, the validators check it,
Postgres stores it as JSONB, and the editor renders it. Contracts live in a
shared workspace package so the browser and the Deno edge runtime cannot drift.

---

## Running it

Requires **Node 22** and **pnpm 10**. Docker is not needed.

```bash
pnpm install
pnpm dev            # http://localhost:5173
```

Open `/demo` and the whole product works immediately against IndexedDB —
plans, editing, Teach Mode, print, offline. No account, no backend, no keys.

```bash
pnpm typecheck      # tsc, both projects
pnpm test           # 37 unit tests
pnpm build          # production build to dist/
pnpm e2e            # Playwright against the built app
```

### Connecting the backend

See `docs/DEPLOYMENT.md`. In short: run `supabase/migrations/001` … `009` in
order, deploy `supabase/functions/lesson-ai`, then set two public variables:

```
VITE_SUPABASE_URL=
VITE_SUPABASE_PUBLISHABLE_KEY=
```

The Gemini key is **never** a `VITE_` variable. It lives in Supabase Edge
Function secrets and is read only inside the Deno runtime.

---

## Security and privacy

- **No student data anywhere.** No student accounts, no per-student rows. Teach
  sessions record aggregate counts, with a database CHECK constraint that the
  tallies can never exceed attendance.
- **RLS on every table** (`008_rls_policies.sql`). Frontend guards are UX only.
- **`generation_runs` is revoked from `authenticated`**, so a browser cannot
  forge records to reset its own daily AI quota.
- **`plan_shares` is never publicly selectable.** Public reads go through the
  `get_shared_plan()` SECURITY DEFINER function, so share tokens cannot be
  enumerated. Only a hash of each token is stored.
- **Shares and publications point at immutable version snapshots**, so editing a
  plan cannot silently change what a public link shows.
- **No third-party tracking.** No analytics pixel, no behavioural SDK. Metrics
  are derived from the teacher's own records.
- CI fails the build if a secret-shaped string appears in `dist/`.

---

## Curriculum and copyright

ChalkBox is **CBSE/NCERT-aligned**, not a copy of NCERT textbooks.

Curriculum *taxonomy* — class, subject, unit, chapter, learning outcomes — is
factual and is used for alignment. The retrievable passages themselves are
original ChalkBox instructional text or openly licensed material. Every source
row carries its licence, attribution and `content_origin`
(`chalkbox-original` / `open-licensed` / `user-provided`), and the admin screen
shows all three.

---

## Layout

```
packages/contracts/src/
  lesson-plan.schema.ts   the canonical plan contract (Zod)
  constraints.ts          the multigrade constraint solver
  readiness.ts            the eight deterministic checks
supabase/
  migrations/             001–009, the canonical database definition
  functions/lesson-ai/    the single AI gateway
src/
  repositories/           one interface, local + production adapters
  db/sync.ts              offline mutation queue and conflict detection
  features/plans/         wizard, editor, timeline arithmetic, lesson rail
  features/teach/         full-screen classroom mode
  features/export/        printable plan (print CSS, not a PDF library)
```

---

## Status

Code complete and locally verified. **Not yet integration-verified** against the
hosted Supabase project — see `INTEGRATION_STATUS.md` for exactly what remains
and what was actually run.

MIT.
