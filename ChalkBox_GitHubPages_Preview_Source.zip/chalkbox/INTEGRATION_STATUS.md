# ChalkBox — Integration Status

Prepared for review **before** anything is applied to the live
`chalkbox-production` Supabase project.

Everything below marked "verified" was actually executed in this session. Where
a thing could not be run, it says so plainly.

---

## 1. What is complete

| Area | State |
|---|---|
| Workspace, React 19, TS strict, Vite 6, PWA | complete |
| Shared contracts package (Zod) | complete |
| **Constraint solver** | complete, 10 tests |
| **Readiness checks (8 validators)** | complete, 8 tests |
| Timeline arithmetic | complete, 9 tests |
| Offline queue + conflict detection | complete, 4 tests |
| Design system, tokens, dark mode, print CSS | complete |
| Accessible UI primitives, focus-trapped modal | complete |
| Routing, lazy routes, guards, error boundaries | complete |
| Landing / About / Privacy | complete |
| Auth screen (production adapter + honest disabled state) | complete |
| Demo Mode bootstrap, isolated Dexie DB, reset | complete |
| Onboarding | complete |
| Dashboard | complete |
| Quick Brief + planning wizard + voice input | complete |
| **Lesson editor** — timeline edit, reflow, rebalance, reorder, live re-checks, autosave | complete |
| Lesson rail (multigrade visualisation) | complete |
| Readiness panel, source drawer | complete |
| Library — search, filters, sort, favourites, archive, duplicate, delete + undo, URL state | complete |
| **Teach Mode** — timer, per-class switching, board prompts, read-aloud, keyboard, wake lock, exit protection | complete |
| Reflection — aggregate counts, over-count validation | complete |
| Print / PDF via print CSS, source appendix, draft watermark | complete |
| Sharing — create, list, revoke, public read-only page | complete |
| Community — browse, filter, detail, clone, report | complete |
| Analytics — derived from records, accessible table per chart | complete |
| Settings — defaults, resources, theme, storage, demo reset, feedback | complete |
| Admin — sources, moderation queue, authenticated health check | complete |
| Migrations 001–009 including RLS + grants | written, **not applied** |
| Edge Function `lesson-ai` | written, **not deployed** |
| CI workflow incl. secret-leak guard | complete |
| Docs: README, AI_PIPELINE, DEPLOYMENT, DEMO_GUIDE, TEST_PLAN | complete |

---

## 2. Tests actually run

```
pnpm vitest run

 ✓ packages/contracts/src/__tests__/constraints.test.ts   (10 tests)
 ✓ packages/contracts/src/__tests__/readiness.test.ts     ( 8 tests)
 ✓ src/db/__tests__/sync.test.ts                          ( 4 tests)
 ✓ src/features/plans/__tests__/plan-time.test.ts         ( 9 tests)
 ✓ src/features/plans/__tests__/readiness-integration.test.ts (6 tests)

 Test Files  5 passed (5)
      Tests  37 passed (37)
```

One real bug was caught and fixed, not documented around: the fixture generator
produced a single objective for single-class plans where the schema requires
two. The generator now emits an understand-level and an apply-level objective.

## 3. Typecheck and build

```
tsc -p tsconfig.app.json            → clean, no errors
tsc -p packages/contracts/tsconfig  → clean, no errors
tsc -p tsconfig.node.json           → clean, no errors

vite build                          → ✓ built
  react     103.43 kB │ gzip  34.95 kB
  data      122.15 kB │ gzip  40.15 kB
  supabase  218.46 kB │ gzip  57.81 kB
  index     283.15 kB │ gzip  87.75 kB
  charts    374.65 kB │ gzip 103.79 kB   (lazy, Impact page only)
  PWA: 44 precached entries
```

## 4. Not verified, because provider configuration is deferred

- Migrations have never been executed against any Postgres.
- `lesson-ai` has never been deployed or invoked.
- No real Gemini request has been made from this codebase.
- RLS is written and reviewed but never exercised.
- Retrieval SQL (`match_curriculum`) has never run against real vectors.
- Share tokens have never resolved through `get_shared_plan()`.
- Playwright specs are written but were not run — no browser binaries here.
- No lighthouse or production-URL numbers exist.

Demo Mode is fully functional and was exercised through the build, because it
depends on none of the above.

## 5. Migrations to apply, in order

`001_extensions` → `002_profiles_settings` → `003_curriculum` →
`004_lesson_plans` → `005_teach_reflections` → `006_sharing_community` →
`007_analytics_notifications` → `008_rls_policies` → `009_grants`

Enable the `vector` extension before 001. **Do not skip 008 or 009** — 008 is
the entire security boundary; 009 is why the client can read anything.

## 6. Edge Functions to deploy

`supabase/functions/lesson-ai` (with `_shared/`).

## 7. Environment variable names (no values)

Frontend, both public:
`VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`, `VITE_APP_ENV`,
`VITE_DEMO_ENABLED`, later `VITE_TURNSTILE_SITE_KEY`.

Edge secrets: `GEMINI_API_KEY` (private), `GEMINI_MODEL`,
`GEMINI_EMBEDDING_MODEL`, `GEMINI_EMBEDDING_DIMENSIONS`,
`AI_DAILY_LIMIT_TEACHER`, `AI_DAILY_LIMIT_DEMO`.

## 8. Manual steps and expected results

| # | Step | Expect |
|---|---|---|
| 1 | Enable `vector` extension | listed under Extensions |
| 2 | Run 001–007 | `Success. No rows returned` each time |
| 3 | Run 008 | shield icon on every table in Table Editor |
| 4 | Run 009 | no error |
| 5 | `select match_curriculum(...)` with a zero vector | returns 0 rows, no error — proves the function compiles |
| 6 | Deploy `lesson-ai` | function listed, status active |
| 7 | Add Edge secrets | six entries present |
| 8 | Set `VITE_*` locally, `pnpm dev`, sign up | confirmation email arrives; `profiles` row created by the trigger |
| 9 | Ingest curriculum | `curriculum_chunks` row count > 0, `indexed_at` set |
| 10 | Generate one plan | see §10 |

## 9. Rollback

Migrations only create objects; none drops or alters existing data. If a
migration fails midway, read the error, fix that file, and re-run it — the
earlier files are already applied and need no undo. On a project with **no real
data**, a full reset is `drop schema public cascade; create schema public;`
followed by 001–009. Never run that once teacher data exists.

## 10. First real Gemini test

1. Confirm `GEMINI_API_KEY` is set in Edge secrets and billing is **off**.
2. Ingest at least one curriculum source so retrieval has something to find.
3. Sign in (or open Demo Mode, which uses anonymous auth once the backend is
   connected).
4. New plan → Classes **6, 7, 8** → Science → topic "Air and burning" →
   40 minutes → Hindi → Make the plan.
5. Expect: a plan returns in roughly 10–30 s; the timeline sums to exactly 40;
   each class has its own track; the text is Devanagari; citations reference
   real chunk ids; the checks panel shows a score.
6. Check `generation_runs` — one row, `status = succeeded`, `latency_ms` set,
   `retrieved_chunk_ids` non-empty.
7. Repeat until the demo quota is exhausted; confirm the sixth attempt returns
   a clear "quota used for today" message rather than an error page.

Expect the first two or three runs to trip a validator. That is the system
working. Send me the readiness panel contents and I will tune the prompts
against real failures rather than guessed ones.

## 11. Known limitations

- **Embedding model.** Per your instruction this was left configurable and
  untouched. `GEMINI_EMBEDDING_MODEL` is currently `gemini-embedding-2` in your
  secrets. The Edge config falls back to `gemini-embedding-001` at runtime
  because the `-2` model returns one aggregated embedding for multiple inputs,
  which breaks per-chunk retrieval. Flagged only; nothing depends on you
  changing it today.
- The production Supabase repository adapter is scaffolded behind the same
  interface as the local one, but its methods are not yet wired to live tables —
  that is the first task after migrations are applied.
- `regenerate-section` and `generate-assessment` are defined in the API contract
  and routed in the client, but the Edge handlers for them are not implemented.
- Playwright specs are unrun.
- No fonts are vendored yet; the app currently falls back to system faces for
  Devanagari. Self-hosting Noto Sans Devanagari is a pre-deployment task.

## 12. Blockers

None. Every remaining item needs either the hosted project or a browser runner.
